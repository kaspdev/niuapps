plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

val releaseStorePath = System.getenv("NIU_RELEASE_STORE_FILE")
val releaseSigningReady = !releaseStorePath.isNullOrBlank() &&
    !System.getenv("NIU_RELEASE_STORE_PASSWORD").isNullOrBlank() &&
    !System.getenv("NIU_RELEASE_KEY_ALIAS").isNullOrBlank() &&
    !System.getenv("NIU_RELEASE_KEY_PASSWORD").isNullOrBlank()
// R8 is opt-in: it can take several minutes on modest machines. Enable with -PNIU_ENABLE_R8=true.
val enableR8 = providers.gradleProperty("NIU_ENABLE_R8").orElse("false").get().toBoolean()

android {
    namespace = "com.niu.fxstudio"
    compileSdk = 35
    flavorDimensions += "distribution"
    productFlavors {
        create("full") {
            dimension = "distribution"
            buildConfigField("boolean", "PROTECTED_TOOLS_ENABLED", "true")
            buildConfigField("boolean", "IS_USER_BUILD", "false")
        }
        create("user") {
            dimension = "distribution"
            applicationIdSuffix = ".user"
            versionNameSuffix = "-user"
            buildConfigField("boolean", "PROTECTED_TOOLS_ENABLED", "true")
            buildConfigField("boolean", "IS_USER_BUILD", "true")
        }
    }
    defaultConfig {
        val adminPublicKey = providers.gradleProperty("NIU_ADMIN_PUBLIC_KEY").orElse("").get()
        buildConfigField("String", "ADMIN_PUBLIC_KEY", "\"${adminPublicKey}\"")
        applicationId = "com.niu.fxstudio"
        minSdk = 26
        targetSdk = 35
        versionCode = 132
        versionName = "1.3.2"
    }
    buildFeatures {
        compose = true
        // Required for generated BuildConfig.VERSION_NAME / VERSION_CODE.
        buildConfig = true
    }
    signingConfigs {
        if (releaseSigningReady) {
            create("release") {
                storeFile = file(releaseStorePath!!)
                storePassword = System.getenv("NIU_RELEASE_STORE_PASSWORD")
                keyAlias = System.getenv("NIU_RELEASE_KEY_ALIAS")
                keyPassword = System.getenv("NIU_RELEASE_KEY_PASSWORD")
            }
        }
    }
    buildTypes {
        getByName("release") {
            isMinifyEnabled = enableR8
            isShrinkResources = enableR8
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            if (releaseSigningReady) signingConfig = signingConfigs.getByName("release")
        }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation(project(":niu-sdk"))
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.activity:activity-compose:1.10.0")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.biometric:biometric:1.1.0")
    implementation("androidx.fragment:fragment-ktx:1.8.5")
    implementation("com.google.android.gms:play-services-code-scanner:16.1.0")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    debugImplementation("androidx.compose.ui:ui-tooling")
    testImplementation("junit:junit:4.13.2")
}
