package com.niu.fxstudio.admin

import android.content.Context
import android.content.Intent

/** Full-distribution entry point for the embedded administrator console. */
object AdminConsoleEntry {
    fun open(context: Context) {
        context.startActivity(Intent(context, AdminActivity::class.java))
    }
}
