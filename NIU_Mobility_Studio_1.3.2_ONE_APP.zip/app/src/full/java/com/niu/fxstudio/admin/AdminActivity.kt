package com.niu.fxstudio.admin

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import android.widget.*
import android.app.AlertDialog
import android.text.InputType
import android.net.Uri
import java.net.HttpURLConnection
import java.net.URL
import java.security.KeyPairGenerator
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import java.security.KeyStore
import java.security.Signature
import java.util.UUID
import java.util.concurrent.TimeUnit

/** Offline administrator. The signing private key never leaves Android Keystore. */
class AdminActivity : Activity() {
    private val alias = "niu.mobility.admin.signing.v1"
    private lateinit var status: TextView
    private lateinit var publicKey: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 32, 32, 32) }
        root.addView(TextView(this).apply { text = "NIU MOBILITY ADMIN\nПодписание разрешений защищённых инструментов"; textSize = 20f })
        status = TextView(this).apply { text = "Ключ подписи ещё не создан" }; root.addView(status)
        val create = Button(this).apply { text = "Создать / проверить ключ администратора"; setOnClickListener { ensureKey(); showPublicKey() } }; root.addView(create)
        publicKey = TextView(this).apply { textSize = 10f }; root.addView(publicKey)
        val installId = EditText(this).apply { hint = "Installation ID из пользовательского приложения" }; root.addView(installId)
        val days = EditText(this).apply { hint = "Срок действия, дней (например 30)"; setText("30"); inputType = 2 }; root.addView(days)
        val grantIdView = TextView(this).apply { textSize = 11f; text = "ID последнего разрешения появится здесь" }; root.addView(grantIdView)
        root.addView(Button(this).apply { text = "Подписать разрешение и поделиться"; setOnClickListener {
            requireAdminPin {
            runCatching {
                ensureKey()
                val id = installId.text.toString().trim(); require(id.matches(Regex("[A-Fa-f0-9-]{36}"))) { "Некорректный Installation ID" }
                val duration = days.text.toString().toLong().coerceIn(1, 365)
                val grantId = UUID.randomUUID().toString()
                val payload = listOf("NIU-GRANT-1", id, (System.currentTimeMillis() + TimeUnit.DAYS.toMillis(duration)).toString(), "protected_tools", grantId).joinToString("\n").toByteArray()
                val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
                val signer = Signature.getInstance("SHA256withECDSA").apply { initSign(ks.getKey(alias, null) as java.security.PrivateKey); update(payload) }
                val token = b64(payload) + "." + b64(signer.sign())
                grantIdView.text = "ID разрешения для последующего отзыва: $grantId"
                getSharedPreferences("admin_state", MODE_PRIVATE).edit().putStringSet("issued_ids", getSharedPreferences("admin_state", MODE_PRIVATE).getStringSet("issued_ids", emptySet())!!.toMutableSet().apply { add(grantId) }).apply()
                val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, token)
                startActivity(Intent.createChooser(send, "Передать подписанное разрешение"))
                status.text = "Разрешение подписано. Частный ключ не экспортировался."
            }.onFailure { status.text = "Ошибка: ${it.message}" }
            }
        } })
        val revokeId = EditText(this).apply { hint = "UUID разрешения для отзыва" }; root.addView(revokeId)
        root.addView(Button(this).apply { text = "Отозвать разрешение и поделиться списком"; setOnClickListener {
            requireAdminPin {
            runCatching {
                ensureKey()
                val id = revokeId.text.toString().trim()
                require(id.matches(Regex("[A-Fa-f0-9-]{36}"))) { "Некорректный UUID разрешения" }
                val prefs = getSharedPreferences("admin_state", MODE_PRIVATE)
                val revoked = (prefs.getStringSet("revoked_ids", emptySet()) ?: emptySet()).toMutableSet()
                revoked.add(id)
                prefs.edit().putStringSet("revoked_ids", revoked).apply()
                val payload = (listOf("NIU-REVOKE-1") + revoked.sorted()).joinToString("\n").toByteArray()
                val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
                val signer = Signature.getInstance("SHA256withECDSA").apply { initSign(ks.getKey(alias, null) as java.security.PrivateKey); update(payload) }
                val token = b64(payload) + "." + b64(signer.sign())
                val share = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, token)
                startActivity(Intent.createChooser(share, "Передать список отзыва"))
                status.text = "Список отзыва подписан. На устройстве доступ закроется после импорта списка."
            }.onFailure { status.text = "Ошибка отзыва: ${it.message}" }
            }
        } })
        root.addView(TextView(this).apply { text = "СБОРКА USER APK ИЗ АДМИН-ПРИЛОЖЕНИЯ"; textSize = 18f })
        val owner = EditText(this).apply { hint = "GitHub владелец / организация"; setSingleLine(true) }; root.addView(owner)
        val repo = EditText(this).apply { hint = "Имя GitHub-репозитория"; setSingleLine(true) }; root.addView(repo)
        val branch = EditText(this).apply { hint = "Ветка (обычно main)"; setText("main"); setSingleLine(true) }; root.addView(branch)
        val workflowToken = EditText(this).apply { hint = "GitHub token (fine-grained: Actions: Read and write)"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD; setSingleLine(true) }; root.addView(workflowToken)
        val buildStatus = TextView(this).apply { text = "Сборка запускается на GitHub Actions; токен не сохраняется." }; root.addView(buildStatus)
        root.addView(Button(this).apply { text = "Собрать пользовательский APK"; setOnClickListener {
            val o = owner.text.toString().trim(); val r = repo.text.toString().trim(); val ref = branch.text.toString().trim().ifBlank { "main" }; val token = workflowToken.text.toString().trim()
            if (!o.matches(Regex("[A-Za-z0-9_.-]+")) || !r.matches(Regex("[A-Za-z0-9_.-]+")) || token.isBlank()) { buildStatus.text = "Укажите владельца, репозиторий и GitHub token."; return@setOnClickListener }
            buildStatus.text = "Отправка запроса на сборку…"
            Thread {
                try {
                    val endpoint = URL("https://api.github.com/repos/$o/$r/actions/workflows/android-build.yml/dispatches")
                    val connection = (endpoint.openConnection() as HttpURLConnection).apply {
                        requestMethod = "POST"; connectTimeout = 15000; readTimeout = 15000; doOutput = true
                        setRequestProperty("Accept", "application/vnd.github+json")
                        setRequestProperty("Authorization", "Bearer $token")
                        setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
                        setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    }
                    connection.outputStream.use {
                        val body = org.json.JSONObject()
                            .put("ref", ref)
                            .put("inputs", org.json.JSONObject().put("build_target", "user"))
                        it.write(body.toString().toByteArray(Charsets.UTF_8))
                    }
                    val code = connection.responseCode
                    connection.disconnect()
                    runOnUiThread {
                        workflowToken.text?.clear()
                        if (code == 204) {
                            buildStatus.text = "Сборка запущена. Откройте GitHub Actions для статуса и скачивания APK."
                            val browser = Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/$o/$r/actions/workflows/android-build.yml"))
                            startActivity(browser)
                        } else buildStatus.text = "GitHub вернул HTTP $code. Проверьте token, права Actions: write, репозиторий и имя workflow."
                    }
                } catch (e: Exception) { runOnUiThread { workflowToken.text?.clear(); buildStatus.text = "Не удалось запустить сборку: ${e.message}" } }
            }.start()
        } })
        root.addView(TextView(this).apply { text = "Требуется Fine-grained GitHub token только с доступом к нужному репозиторию и разрешением Actions: Read and write. Токен используется только в памяти, не записывается в настройки и очищается после запроса. По запросу из этой консоли GitHub Actions собирает только пользовательский APK; исходный проект остаётся единым. При push в main/master CI проверяет обе конфигурации."; textSize = 12f })
        root.addView(TextView(this).apply { text = "ВАЖНО: после создания ключа скопируйте открытый ключ и задайте NIU_ADMIN_PUBLIC_KEY при сборке пользовательского APK. Сохраните данные приложения Admin: приватный ключ находится в Android Keystore. Офлайн-отзыв применяется на устройстве после импорта подписанного списка отзыва."; textSize = 12f })
        setContentView(ScrollView(this).apply { addView(root) })
    }
    private fun requireAdminPin(action: () -> Unit) {
        val prefs = getSharedPreferences("admin_state", MODE_PRIVATE)
        val saltText = prefs.getString("pin_salt", null)
        val storedHash = prefs.getString("pin_hash", null)
        val firstSetup = saltText.isNullOrBlank() || storedHash.isNullOrBlank()
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 8, 24, 0) }
        val pin = EditText(this).apply { hint = if (firstSetup) "Новый PIN (не менее 8 символов)" else "PIN администратора"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD }
        panel.addView(pin)
        val confirm = if (firstSetup) EditText(this).apply { hint = "Повторите PIN"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD } else null
        if (confirm != null) panel.addView(confirm)
        AlertDialog.Builder(this).setTitle(if (firstSetup) "Создать PIN администратора" else "Подтвердить администратора")
            .setMessage("PIN требуется для каждой операции выдачи или отзыва разрешения.")
            .setView(panel).setNegativeButton("Отмена", null).setPositiveButton(if (firstSetup) "Создать и продолжить" else "Подтвердить") { _, _ ->
                val entered = pin.text.toString()
                if (firstSetup) {
                    if (entered.length < 8 || entered != confirm?.text?.toString()) { status.text = "PIN должен содержать не менее 8 символов; значения должны совпадать."; return@setPositiveButton }
                    val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
                    prefs.edit().putString("pin_salt", Base64.encodeToString(salt, Base64.NO_WRAP)).putString("pin_hash", derivePinHash(entered, salt)).apply()
                    action()
                } else {
                    val salt = Base64.decode(saltText, Base64.DEFAULT)
                    if (derivePinHash(entered, salt) == storedHash) action() else status.text = "Неверный PIN администратора."
                }
            }.show()
    }

    private fun derivePinHash(pin: String, salt: ByteArray): String {
        val spec = PBEKeySpec(pin.toCharArray(), salt, 210_000, 256)
        return try { Base64.encodeToString(SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded, Base64.NO_WRAP) }
        finally { spec.clearPassword() }
    }

    private fun ensureKey() {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        if (ks.containsAlias(alias)) return
        val gen = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_EC, "AndroidKeyStore")
        gen.initialize(KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_SIGN or KeyProperties.PURPOSE_VERIFY).setAlgorithmParameterSpec(java.security.spec.ECGenParameterSpec("secp256r1")).setDigests(KeyProperties.DIGEST_SHA256) .setUserAuthenticationRequired(false).build())
        gen.generateKeyPair()
    }
    private fun showPublicKey() {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val cert = ks.getCertificate(alias) ?: error("Сертификат ключа не найден")
        val encoded = Base64.encodeToString(cert.publicKey.encoded, Base64.NO_WRAP)
        publicKey.text = "ОТКРЫТЫЙ КЛЮЧ (NIU_ADMIN_PUBLIC_KEY):\n$encoded"
        status.text = "Ключ администратора готов · ECDSA P-256 · Android Keystore"
    }
    private fun b64(bytes: ByteArray) = Base64.encodeToString(bytes, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
}
