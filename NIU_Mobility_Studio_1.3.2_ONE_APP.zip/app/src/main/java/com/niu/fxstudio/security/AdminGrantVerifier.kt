package com.niu.fxstudio.security

import android.content.Context
import android.util.Base64
import java.security.KeyFactory
import java.security.Signature
import java.security.spec.X509EncodedKeySpec
import java.util.UUID

/** Verifies administrator-signed, device-bound, expiring grants. No embedded private key. */
object AdminGrantVerifier {
    private const val PREFS = "niu_admin_grant"
    private const val GRANT = "grant"
    private const val INSTALL_ID = "install_id"
    private const val REVOKED_IDS = "revoked_ids"

    fun installationId(context: Context): String {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return p.getString(INSTALL_ID, null) ?: UUID.randomUUID().toString().also {
            p.edit().putString(INSTALL_ID, it).apply()
        }
    }

    /** Grant format: base64url(payload UTF-8).base64url(ASN.1 ECDSA signature). */
    fun importGrant(context: Context, encoded: String, pinnedPublicKeyBase64: String): Boolean {
        val parts = encoded.trim().split('.')
        if (parts.size != 2 || pinnedPublicKeyBase64.isBlank()) return false
        return runCatching {
            val payload = Base64.decode(parts[0], Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
            val signatureBytes = Base64.decode(parts[1], Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
            val publicBytes = Base64.decode(pinnedPublicKeyBase64, Base64.DEFAULT)
            val key = KeyFactory.getInstance("EC").generatePublic(X509EncodedKeySpec(publicBytes))
            val verifier = Signature.getInstance("SHA256withECDSA")
            verifier.initVerify(key); verifier.update(payload)
            if (!verifier.verify(signatureBytes)) return false
            val fields = payload.toString(Charsets.UTF_8).split('\n')
            require(fields.size == 5 && fields[0] == "NIU-GRANT-1")
            require(fields[1] == installationId(context))
            val expires = fields[2].toLong()
            require(System.currentTimeMillis() < expires)
            require(fields[3].split(',').contains("protected_tools"))
            require(fields[4].matches(Regex("[A-Fa-f0-9-]{36}")))
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            require(fields[4] !in (prefs.getStringSet(REVOKED_IDS, emptySet()) ?: emptySet()))
            prefs.edit().putString(GRANT, encoded.trim()).apply()
            true
        }.getOrDefault(false)
    }

    fun isAuthorized(context: Context, pinnedPublicKeyBase64: String): Boolean {
        val grant = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(GRANT, null) ?: return false
        val parts = grant.split('.')
        if (parts.size != 2 || pinnedPublicKeyBase64.isBlank()) return false
        return runCatching {
            val payload = Base64.decode(parts[0], Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
            val sig = Base64.decode(parts[1], Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
            val key = KeyFactory.getInstance("EC").generatePublic(X509EncodedKeySpec(Base64.decode(pinnedPublicKeyBase64, Base64.DEFAULT)))
            Signature.getInstance("SHA256withECDSA").run { initVerify(key); update(payload); verify(sig) } &&
                payload.toString(Charsets.UTF_8).let { p ->
                    val f = p.split('\n'); f.size == 5 && f[0] == "NIU-GRANT-1" && f[1] == installationId(context) &&
                        System.currentTimeMillis() < f[2].toLong() && "protected_tools" in f[3].split(',') &&
                        f[4] !in (context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getStringSet(REVOKED_IDS, emptySet()) ?: emptySet())
                }
        }.getOrDefault(false)
    }

    /** Imports a signed offline revocation list. Existing offline grants are rejected after import. */
    fun importRevocationList(context: Context, encoded: String, pinnedPublicKeyBase64: String): Boolean {
        val parts = encoded.trim().split('.')
        if (parts.size != 2 || pinnedPublicKeyBase64.isBlank()) return false
        return runCatching {
            val payload = Base64.decode(parts[0], Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
            val signatureBytes = Base64.decode(parts[1], Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
            val key = KeyFactory.getInstance("EC").generatePublic(X509EncodedKeySpec(Base64.decode(pinnedPublicKeyBase64, Base64.DEFAULT)))
            val verifier = Signature.getInstance("SHA256withECDSA").apply { initVerify(key); update(payload) }
            require(verifier.verify(signatureBytes))
            val lines = payload.toString(Charsets.UTF_8).split('\n')
            require(lines.isNotEmpty() && lines[0] == "NIU-REVOKE-1" && lines.size <= 10001)
            val ids = lines.drop(1).filter { it.isNotBlank() }
            require(ids.all { it.matches(Regex("[A-Fa-f0-9-]{36}")) })
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val merged = (prefs.getStringSet(REVOKED_IDS, emptySet()) ?: emptySet()).toMutableSet().apply { addAll(ids) }
            prefs.edit().putStringSet(REVOKED_IDS, merged).apply()
            val current = prefs.getString(GRANT, null)
            if (current != null) {
                val currentPayload = Base64.decode(current.substringBefore('.'), Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING).toString(Charsets.UTF_8)
                val grantId = currentPayload.split('\n').getOrNull(4)
                if (grantId in merged) prefs.edit().remove(GRANT).apply()
            }
            true
        }.getOrDefault(false)
    }

    fun revoke(context: Context) { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(GRANT).apply() }
}
