package com.niu.fxstudio.security

import org.json.JSONObject
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.atomic.AtomicBoolean

/** Small authenticated HTTP control endpoint. Bound to loopback by default; LAN mode is explicit. */
class LocalControlServer(
    private val port: Int,
    private val accessToken: String,
    private val allowLan: Boolean,
    private val onNotify: (String) -> Unit,
    private val onEvent: (String) -> Unit
) {
    private val running = AtomicBoolean(false)
    @Volatile private var server: ServerSocket? = null
    val isRunning get() = running.get()

    fun start() {
        require(port in 1024..65535) { "Порт должен быть в диапазоне 1024–65535" }
        require(accessToken.length >= 24) { "Ключ локального API должен быть не короче 24 символов" }
        if (!running.compareAndSet(false, true)) return
        Thread({
            try {
                val bind = if (allowLan) InetAddress.getByName("0.0.0.0") else InetAddress.getByName("127.0.0.1")
                ServerSocket(port, 16, bind).use { socket ->
                    server = socket
                    onEvent("Локальный API запущен: ${if (allowLan) "LAN" else "localhost"}:$port")
                    while (running.get()) {
                        val client = socket.accept()
                        Thread({ handle(client) }, "niu-local-api-client").apply { isDaemon = true; start() }
                    }
                }
            } catch (e: Exception) {
                if (running.get()) onEvent("Local API: ${e.message?.take(160)}")
            } finally { running.set(false); server = null; onEvent("Локальный API остановлен") }
        }, "niu-local-api").apply { isDaemon = true; start() }
    }

    private fun handle(socket: Socket) {
        socket.use { client ->
            client.soTimeout = 5000
            val input = client.getInputStream().buffered()
            val output = client.getOutputStream().bufferedWriter(Charsets.UTF_8)
            try {
                val request = readHttpLine(input, 2048).orEmpty().split(" ")
                val method = request.getOrNull(0).orEmpty()
                val path = request.getOrNull(1).orEmpty()
                var auth = ""
                var contentLength = 0
                var headerCount = 0
                while (true) {
                    val line = readHttpLine(input, 4096) ?: break
                    if (line.isEmpty()) break
                    headerCount++
                    if (headerCount > 40) throw IllegalArgumentException("Too many headers")
                    if (line.startsWith("Authorization:", true)) auth = line.substringAfter(':').trim()
                    if (line.startsWith("Content-Length:", true)) contentLength = line.substringAfter(':').trim().toIntOrNull() ?: 0
                }
                if (auth != "Bearer $accessToken") { respond(output, 401, "{\"error\":\"unauthorized\"}"); return }
                when {
                    method == "GET" && path == "/health" -> respond(output, 200, JSONObject().put("ok", true).put("service", "niu-mobility-local-api").toString())
                    method == "POST" && path == "/notify" -> {
                        if (contentLength !in 1..8192) { respond(output, 413, "{\"error\":\"invalid_body_size\"}"); return }
                        val body = ByteArray(contentLength)
                        var read = 0
                        while (read < contentLength) {
                            val n = input.read(body, read, contentLength - read)
                            if (n < 0) break
                            read += n
                        }
                        if (read != contentLength) { respond(output, 400, "{\"error\":\"incomplete_body\"}"); return }
                        val message = JSONObject(String(body, Charsets.UTF_8)).optString("message").take(1000)
                        if (message.isBlank()) respond(output, 400, "{\"error\":\"message_required\"}")
                        else { onNotify(message); respond(output, 202, "{\"accepted\":true}") }
                    }
                    else -> respond(output, 404, "{\"error\":\"not_found\"}")
                }
            } catch (_: Exception) { runCatching { respond(output, 400, "{\"error\":\"bad_request\"}") } }
        }
    }

    private fun readHttpLine(input: java.io.InputStream, maxBytes: Int): String? {
        val bytes = java.io.ByteArrayOutputStream()
        while (true) {
            val value = input.read()
            if (value < 0) return if (bytes.size() == 0) null else bytes.toString("ISO-8859-1")
            if (value == 10) break
            if (value != 13) {
                if (bytes.size() >= maxBytes) throw IllegalArgumentException("HTTP line too long")
                bytes.write(value)
            }
        }
        return bytes.toString("ISO-8859-1")
    }

    private fun respond(out: java.io.BufferedWriter, code: Int, body: String) {
        val status = when (code) { 200 -> "OK"; 202 -> "Accepted"; 400 -> "Bad Request"; 401 -> "Unauthorized"; 413 -> "Payload Too Large"; else -> "Not Found" }
        out.write("HTTP/1.1 $code $status\r\nContent-Type: application/json; charset=utf-8\r\nCache-Control: no-store\r\nConnection: close\r\nContent-Length: ${body.toByteArray(Charsets.UTF_8).size}\r\n\r\n$body")
        out.flush()
    }

    fun stop() { running.set(false); runCatching { server?.close() } }
}
