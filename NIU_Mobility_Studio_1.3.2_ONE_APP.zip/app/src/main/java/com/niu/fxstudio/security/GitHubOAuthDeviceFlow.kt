package com.niu.fxstudio.security

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** OAuth Device Authorization Grant for a user-configured GitHub OAuth App. */
object GitHubOAuthDeviceFlow {
    data class DeviceSession(
        val deviceCode: String,
        val userCode: String,
        val verificationUri: String,
        val expiresIn: Int,
        val interval: Int
    )

    sealed class PollResult {
        data class Authorized(val accessToken: String, val scope: String) : PollResult()
        data object Pending : PollResult()
        data object SlowDown : PollResult()
        data object Expired : PollResult()
        data class Failed(val message: String) : PollResult()
    }

    private fun postForm(endpoint: String, fields: Map<String, String>): JSONObject {
        val body = fields.entries.joinToString("&") {
            URLEncoder.encode(it.key, "UTF-8") + "=" + URLEncoder.encode(it.value, "UTF-8")
        }
        val connection = URL(endpoint).openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "POST"
            connection.connectTimeout = 20_000
            connection.readTimeout = 30_000
            connection.doOutput = true
            connection.setRequestProperty("Accept", "application/json")
            connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
            connection.setRequestProperty("User-Agent", "NIU-Mobility-Studio-Android")
            connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val payload = stream?.use { it.readBytes().toString(Charsets.UTF_8) }.orEmpty()
            if (payload.isBlank()) error("GitHub OAuth HTTP $code")
            return JSONObject(payload)
        } finally { connection.disconnect() }
    }

    fun begin(clientId: String): DeviceSession {
        require(clientId.matches(Regex("[A-Za-z0-9]{20}"))) { "Проверьте Client ID OAuth App GitHub (20 символов)" }
        val json = postForm("https://github.com/login/device/code", mapOf("client_id" to clientId, "scope" to "repo workflow read:user"))
        if (json.has("error")) error(json.optString("error_description", json.optString("error")))
        return DeviceSession(
            deviceCode = json.getString("device_code"),
            userCode = json.getString("user_code"),
            verificationUri = json.optString("verification_uri", "https://github.com/login/device"),
            expiresIn = json.optInt("expires_in", 900),
            interval = json.optInt("interval", 5)
        )
    }

    fun poll(clientId: String, deviceCode: String): PollResult {
        val json = postForm("https://github.com/login/oauth/access_token", mapOf(
            "client_id" to clientId,
            "device_code" to deviceCode,
            "grant_type" to "urn:ietf:params:oauth:grant-type:device_code"
        ))
        val error = json.optString("error")
        return when (error) {
            "" -> {
                val token = json.optString("access_token")
                if (token.isBlank()) PollResult.Failed("GitHub не вернул access token")
                else PollResult.Authorized(token, json.optString("scope"))
            }
            "authorization_pending" -> PollResult.Pending
            "slow_down" -> PollResult.SlowDown
            "expired_token" -> PollResult.Expired
            "access_denied" -> PollResult.Failed("Авторизация отклонена пользователем")
            else -> PollResult.Failed(json.optString("error_description", error))
        }
    }
}
