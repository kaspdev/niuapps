package com.niu.fxstudio.security

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Optional bridge to an operator-owned HTTPS AI backend.
 * Contract: POST JSON {"message": "...", "context": {"source":"telegram","logs":[...]}}
 * Response: {"reply":"..."}.
 * The backend URL is configurable; no provider key is embedded in the APK.
 */
object TelegramAiAssistant {
    fun respond(endpoint: String, bearerToken: String?, message: String, recentLogs: List<String>): String {
        require(endpoint.startsWith("https://", ignoreCase = true)) {
            "Для AI-чата нужен HTTPS backend. Локальный HTTP endpoint не принимается."
        }
        require(message.isNotBlank() && message.length <= 3500) { "Сообщение пустое или слишком длинное" }
        val url = URL(endpoint)
        require(url.host.isNotBlank()) { "Некорректный адрес AI backend" }
        val payload = JSONObject()
            .put("message", message)
            .put("context", JSONObject()
                .put("source", "telegram")
                .put("product", "NIU Mobility Studio")
                .put("logs", JSONArray(recentLogs.takeLast(80).map(::sanitize))))
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 12_000
            readTimeout = 45_000
            doOutput = true
            setRequestProperty("Accept", "application/json")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            if (!bearerToken.isNullOrBlank()) setRequestProperty("Authorization", "Bearer $bearerToken")
        }
        try {
            connection.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw IllegalStateException("AI backend HTTP $code: ${body.take(300)}")
            val reply = JSONObject(body).optString("reply").trim()
            require(reply.isNotBlank()) { "AI backend не вернул поле reply" }
            return reply.take(3900)
        } finally {
            connection.disconnect()
        }
    }

    private fun sanitize(line: String): String = line
        .replace(Regex("(?i)(token|authorization|password|cookie|api[_-]?key)(\\s*[=:]\\s*)[^,; ]+"), "$1$2[REDACTED]")
        .take(700)
}
