package com.niu.fxstudio.security

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** HTTPS-only provider adapter. The API key is supplied at call time and is never persisted here. */
object AiCodeEditor {
    data class EditResult(val explanation: String, val updatedSource: String)

    fun proposeEdit(provider: String, apiKey: String, instruction: String, path: String, source: String): EditResult {
        require(apiKey.isNotBlank()) { "Сначала сохраните API-ключ провайдера" }
        require(instruction.isNotBlank()) { "Опишите изменение" }
        require(source.length <= 120_000) { "Файл слишком большой для одного AI-запроса (лимит 120 000 символов)" }
        val system = "Ты — инженерный агент NIU Mobility Studio. Верни ТОЛЬКО JSON-объект без Markdown: {\"explanation\":string,\"updated_source\":string}. " +
            "Измени только предоставленный файл. Сохрани совместимость Android/Kotlin, импорты и форматирование. Не выдумывай API и не удаляй функциональность без необходимости. " +
            "Не добавляй секреты, токены, shell-команды, загрузчики кода или обходы разрешений. Если задача неясна, верни исходный код без изменений и объясни почему."
        val user = "Путь файла: $path\nЗадача: $instruction\n\nТЕКУЩИЙ ИСХОДНЫЙ КОД:\n$source"
        val raw = when (provider.lowercase()) {
            "gemini" -> callGemini(apiKey, system, user)
            "anthropic" -> callAnthropic(apiKey, system, user)
            else -> callOpenAi(apiKey, system, user)
        }
        val jsonText = raw.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val parsed = runCatching { JSONObject(jsonText) }.getOrElse { throw IllegalStateException("AI вернул некорректный JSON: ${raw.take(500)}") }
        val updated = parsed.optString("updated_source", "")
        require(updated.isNotEmpty() || source.isEmpty()) { "AI не вернул updated_source" }
        require(updated.length <= 200_000) { "Ответ AI превышает безопасный лимит" }
        return EditResult(parsed.optString("explanation", "Изменение подготовлено"), updated)
    }

    private fun post(url: String, headers: Map<String, String>, body: JSONObject): String {
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20_000
            readTimeout = 90_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            headers.forEach { (k, v) -> setRequestProperty(k, v) }
        }
        try {
            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val response = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw IllegalStateException("AI HTTP $code: ${response.take(900)}")
            return response
        } finally { connection.disconnect() }
    }

    private fun callOpenAi(key: String, system: String, user: String): String {
        val body = JSONObject().put("model", "gpt-4o-mini").put("temperature", 0.1)
            .put("response_format", JSONObject().put("type", "json_object"))
            .put("messages", JSONArray().put(JSONObject().put("role", "system").put("content", system)).put(JSONObject().put("role", "user").put("content", user)))
        val result = JSONObject(post("https://api.openai.com/v1/chat/completions", mapOf("Authorization" to "Bearer $key"), body))
        return result.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
    }

    private fun callGemini(key: String, system: String, user: String): String {
        val body = JSONObject().put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json").put("temperature", 0.1))
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", user)))))
        val result = JSONObject(post("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent?key=$key", emptyMap(), body))
        return result.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
    }

    private fun callAnthropic(key: String, system: String, user: String): String {
        val body = JSONObject().put("model", "claude-haiku-4-5-20251001").put("max_tokens", 12000).put("temperature", 0.1)
            .put("system", system).put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", user)))
        val result = JSONObject(post("https://api.anthropic.com/v1/messages", mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"), body))
        return result.getJSONArray("content").getJSONObject(0).getString("text")
    }
}
