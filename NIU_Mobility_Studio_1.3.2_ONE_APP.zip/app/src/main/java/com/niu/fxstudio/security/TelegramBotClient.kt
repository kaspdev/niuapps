package com.niu.fxstudio.security

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.net.ConnectException
import java.net.URL
import java.util.concurrent.atomic.AtomicBoolean

/** Telegram Bot API client. Never logs the token or full request URL. */
class TelegramBotClient(
    private val token: String,
    private val onLog: (String) -> Unit = {}
) {
    data class BotInfo(val id: Long, val username: String, val firstName: String)
    data class PollCallbacks(
        val onMessage: (chatId: String, text: String) -> String?,
        val onButton: (chatId: String, data: String) -> String?,
        val onMessageWithUser: ((chatId: String, userId: String, text: String) -> String?)? = null,
        val onButtonWithUser: ((chatId: String, userId: String, data: String) -> String?)? = null
    )

    private val base get() = "https://api.telegram.org/bot$token/"

    private fun request(method: String, payload: JSONObject? = null, timeoutMs: Int = 15_000): JSONObject {
        val started = System.currentTimeMillis()
        var connection: HttpURLConnection? = null
        onLog("HTTP → $method${if (payload == null) " GET" else " POST"}")
        try {
            connection = (URL(base + method).openConnection() as HttpURLConnection).apply {
                requestMethod = if (payload == null) "GET" else "POST"
                connectTimeout = timeoutMs
                readTimeout = timeoutMs
                setRequestProperty("Accept", "application/json")
                if (payload != null) {
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                }
            }
            if (payload != null) connection.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            val json = JSONObject(body.ifBlank { "{}" })
            val elapsed = System.currentTimeMillis() - started
            if (code !in 200..299 || !json.optBoolean("ok", false)) {
                val description = json.optString("description", "HTTP $code")
                val retryAfter = json.optJSONObject("parameters")?.optLong("retry_after", 0L)?.takeIf { it > 0L }
                onLog("HTTP ERROR $method · HTTP $code · ${elapsed}ms · retryAfter=${retryAfter ?: "not-provided"}s · ${description.take(220)}")
                throw TelegramApiException(code, description, retryAfter)
            }
            onLog("HTTP ✓ $method · HTTP $code · ${elapsed}ms")
            return json
        } catch (e: Exception) {
            if (e !is TelegramApiException) {
                val kind = when (e) {
                    is UnknownHostException -> "DNS: не удалось разрешить api.telegram.org"
                    is SocketTimeoutException -> "TIMEOUT: превышено время ожидания Telegram API"
                    is ConnectException -> "CONNECT: соединение с api.telegram.org:443 не установлено"
                    else -> "NETWORK: ${e.javaClass.simpleName}: ${e.message ?: "ошибка соединения"}"
                }
                onLog("HTTP ERROR $method · $kind · ${System.currentTimeMillis() - started}ms")
            }
            throw e
        } finally { connection?.disconnect() }
    }

    class TelegramApiException(
        val httpCode: Int,
        description: String,
        val retryAfterSeconds: Long? = null
    ) : IllegalStateException("Telegram API HTTP $httpCode: $description")

    fun getMe(): BotInfo {
        val user = request("getMe").getJSONObject("result")
        return BotInfo(user.getLong("id"), user.optString("username"), user.optString("first_name"))
    }

    fun sendMessage(chatId: String, text: String, keyboard: JSONArray? = null): Boolean {
        require(chatId.isNotBlank()) { "Укажите Chat ID" }
        require(text.isNotBlank() && text.length <= 4096) { "Сообщение должно содержать 1–4096 символов" }
        val body = JSONObject().put("chat_id", chatId).put("text", text).put("disable_web_page_preview", true)
        if (keyboard != null && keyboard.length() > 0) body.put("reply_markup", JSONObject().put("inline_keyboard", keyboard))
        request("sendMessage", body)
        return true
    }

    fun sendMenu(chatId: String, buttons: List<Pair<String, String>>) {
        val rows = JSONArray()
        buttons.chunked(2).forEach { chunk ->
            val row = JSONArray()
            chunk.forEach { (label, command) -> row.put(JSONObject().put("text", label.take(40)).put("callback_data", command.take(64))) }
            rows.put(row)
        }
        sendMessage(chatId, "Панель NIU Mobility Studio\nВыберите действие:", rows)
    }

    fun answerCallbackQuery(callbackId: String, text: String) {
        request("answerCallbackQuery", JSONObject().put("callback_query_id", callbackId).put("text", text.take(180)))
    }

    fun setCommands() {
        val commands = JSONArray()
        listOf(
            "start" to "Открыть панель NIU",
            "help" to "Все команды бота",
            "menu" to "Кнопочное меню NIU",
            "role" to "Моя роль и Telegram ID",
            "status" to "Состояние приложения и бота",
            "vehicle" to "Активный профиль транспорта",
            "models" to "Поддерживаемые линейки NIU",
            "ble" to "Подсказка по Bluetooth BLE",
            "nfc" to "Состояние NFC",
            "diagnostics" to "Сводка ошибок диагностики",
            "cloud" to "Статус NIU Cloud",
            "service" to "Обслуживание и поездки",
            "logs" to "Последние события бота (админ)",
            "errors" to "Ошибки бота (админ)",
            "users" to "Списки ролей (админ)",
            "grantadmin" to "Назначить администратора",
            "revokeadmin" to "Снять права администратора",
            "grantuser" to "Добавить обычного пользователя",
            "revokeuser" to "Удалить обычного пользователя",
            "analyze" to "AI-анализ журнала",
            "ai" to "Задать вопрос AI",
            "fix" to "Предложить безопасное исправление",
            "ping" to "Проверить связь с Telegram",
            "version" to "Версия NIU Mobility Studio"
        ).forEach { (command, description) -> commands.put(JSONObject().put("command", command).put("description", description)) }
        request("setMyCommands", JSONObject().put("commands", commands))
    }

    private fun ensureWebhookIsNotConfigured() {
        val info = request("getWebhookInfo").getJSONObject("result")
        if (info.optString("url").isNotBlank()) {
            throw IllegalStateException("Для бота настроен Webhook. Удалите его через Bot API или BotFather, затем повторите запуск Long Polling.")
        }
    }

    fun poll(
        allowedChatIds: Set<String>,
        running: AtomicBoolean,
        onEvent: (String) -> Unit,
        callbacks: PollCallbacks
    ) {
        var offset = 0L
        ensureWebhookIsNotConfigured()
        onEvent("Long Polling: соединение установлено; ожидание обновлений")
        var failures = 0
        while (running.get()) {
            try {
                val updates = request("getUpdates", JSONObject()
                    .put("offset", offset).put("timeout", 25)
                    .put("allowed_updates", JSONArray().put("message").put("callback_query")), 35_000)
                    .optJSONArray("result") ?: JSONArray()
                failures = 0
                for (i in 0 until updates.length()) {
                    val update = updates.getJSONObject(i)
                    offset = maxOf(offset, update.optLong("update_id") + 1)
                    val callback = update.optJSONObject("callback_query")
                    if (callback != null) {
                        val message = callback.optJSONObject("message")
                        val chatId = message?.optJSONObject("chat")?.optLong("id")?.toString() ?: continue
                        if (allowedChatIds.isNotEmpty() && chatId !in allowedChatIds) {
                            onEvent("SECURITY: отклонён callback от chat_id=${chatId.take(3)}***")
                            continue
                        }
                        val userId = callback.optJSONObject("from")?.optLong("id")?.toString().orEmpty()
                        val data = callback.optString("data")
                        onEvent("UPDATE callback_query · chat=${chatId.take(3)}*** · user=${userId.take(3)}*** · data=${data.take(60)}")
                        val reply = callbacks.onButtonWithUser?.invoke(chatId, userId, data) ?: callbacks.onButton(chatId, data)
                        answerCallbackQuery(callback.optString("id"), if (reply == null) "Готово" else reply.take(180))
                        if (!reply.isNullOrBlank()) sendMessage(chatId, reply)
                        continue
                    }
                    val message = update.optJSONObject("message") ?: continue
                    val chat = message.optJSONObject("chat") ?: continue
                    val chatId = chat.optLong("id").toString()
                    val userId = message.optJSONObject("from")?.optLong("id")?.toString().orEmpty()
                    val text = message.optString("text").trim()
                    if (allowedChatIds.isNotEmpty() && chatId !in allowedChatIds) {
                        onEvent("SECURITY: отклонено сообщение от chat_id=${chatId.take(3)}***")
                        continue
                    }
                    onEvent("UPDATE message · chat=${chatId.take(3)}*** · chars=${text.length} · ${text.substringBefore(' ').take(32)}")
                    val reply = callbacks.onMessageWithUser?.invoke(chatId, userId, text) ?: callbacks.onMessage(chatId, text)
                    if (!reply.isNullOrBlank()) sendMessage(chatId, reply)
                }
            } catch (e: InterruptedException) {
                Thread.currentThread().interrupt(); break
            } catch (e: Exception) {
                if (running.get()) {
                    failures++
                    val apiRetry = (e as? TelegramApiException)?.retryAfterSeconds?.let { it * 1000L }
                    val exponential = (1500L * (1L shl failures.coerceAtMost(5))).coerceAtMost(30_000L)
                    val delay = (apiRetry ?: exponential).coerceIn(1_000L, 120_000L)
                    val category = when (e) {
                        is UnknownHostException -> "DNS"
                        is SocketTimeoutException -> "TIMEOUT"
                        is ConnectException -> "CONNECT"
                        is TelegramApiException -> "API-${e.httpCode}"
                        else -> e.javaClass.simpleName
                    }
                    onEvent("POLL ERROR #$failures · category=$category · ${e.message?.take(220) ?: e.javaClass.simpleName}; retryIn=${delay / 1000}s")
                    try { Thread.sleep(delay) } catch (_: InterruptedException) { Thread.currentThread().interrupt(); break }
                }
            }
        }
        onEvent("Long Polling остановлен")
    }
}
