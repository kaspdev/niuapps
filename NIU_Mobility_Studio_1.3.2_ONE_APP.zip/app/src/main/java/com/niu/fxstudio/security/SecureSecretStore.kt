package com.niu.fxstudio.security

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import android.util.Base64

/** Small encrypted-at-rest store for user supplied provider credentials. Keys never leave Android Keystore. */
class SecureSecretStore(private val preferences: android.content.SharedPreferences) {
    private val alias = "niu_fx_studio_secrets_v1"
    private val transformation = "AES/GCM/NoPadding"

    fun put(name: String, value: String) {
        require(name.matches(Regex("[A-Za-z0-9_.-]{1,80}"))) { "Invalid secret name" }
        if (value.isBlank()) { remove(name); return }
        val cipher = Cipher.getInstance(transformation)
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        val encrypted = cipher.doFinal(value.toByteArray(StandardCharsets.UTF_8))
        val packed = cipher.iv + encrypted
        check(preferences.edit().putString(name, Base64.encodeToString(packed, Base64.NO_WRAP)).commit()) {
            "Unable to persist encrypted secret"
        }
    }

    /** Returns null only when the key is absent; decryption errors remain visible to callers. */
    fun getOrThrow(name: String): String? {
        val encoded = preferences.getString(name, null) ?: return null
        val packed = Base64.decode(encoded, Base64.NO_WRAP)
        require(packed.size > 12) { "Encrypted value is truncated" }
        val iv = packed.copyOfRange(0, 12)
        val payload = packed.copyOfRange(12, packed.size)
        val cipher = Cipher.getInstance(transformation)
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, iv))
        return String(cipher.doFinal(payload), StandardCharsets.UTF_8)
    }

    /** Compatibility accessor for non-UI background callers. Prefer getOrThrow in settings UI. */
    fun get(name: String): String? = runCatching { getOrThrow(name) }.getOrNull()

    fun remove(name: String) { preferences.edit().remove(name).apply() }
    fun contains(name: String): Boolean = preferences.contains(name)

    private fun getOrCreateKey(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(alias, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }
}
