package com.niu.fxstudio.feature.workspace.domain

/** Persistable UI session metadata. Project source files remain in user-selected storage, not in a database. */
data class WorkspaceSession(
    val lastRoute: Int = 0,
    val lastProjectUri: String? = null,
    val editorSplitEnabled: Boolean = true,
    val terminalExpanded: Boolean = false
) {
    fun normalized(): WorkspaceSession = copy(lastRoute = lastRoute.coerceIn(0, 13))
}
