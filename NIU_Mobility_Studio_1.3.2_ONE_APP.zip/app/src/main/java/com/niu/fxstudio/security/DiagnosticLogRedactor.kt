package com.niu.fxstudio.security

/** Redacts credentials and common personal/device identifiers before logs leave the device. */
object DiagnosticLogRedactor {
    private val assignment = Regex(
        "(?i)([\\\"']?(?:password|passwd|pwd|pwd[_-]?md5|password[_-]?md5|password[_-]?hash|token|access[_-]?token|refresh[_-]?token|id[_-]?token|authorization|auth[_-]?token|x[_-]?auth[_-]?token|cookie|set-cookie|x-jg-sign|sign|x[_-]?api[_-]?key|api[_-]?key|client[_-]?secret|secret|session[_-]?key|session[_-]?token|account|email|phone|vin|serial|sn|ble[_-]?address|mac[_-]?address|user[_-]?id|chat[_-]?id|username|login)[\\\"']?\\s*[:=]\\s*)(\\\"[^\\\"]*\\\"|'[^']*'|[^,;\\s&}]+)"
    )
    private val queryValue = Regex(
        "(?i)([?&](?:password|passwd|pwd|token|access[_-]?token|refresh[_-]?token|authorization|auth[_-]?token|x[_-]?auth[_-]?token|x[_-]?api[_-]?key|api[_-]?key|client[_-]?secret|sign)=)[^&#\\s]+"
    )
    private val authorization = Regex("(?i)(authorization\\s*[:=]\\s*)(?:(?:Bearer|Basic)\\s+)?[^\\s,;]+")
    private val cookieHeader = Regex("(?i)(set-cookie|cookie)\\s*[:=]\\s*[^\\r\\n]+")
    private val bearer = Regex("(?i)\\bBearer\\s+[^\\s,;]+")
    private val basic = Regex("(?i)\\bBasic\\s+[A-Za-z0-9+/=]{8,}")
    private val githubToken = Regex("(?i)\\bgh[pousr]_[A-Za-z0-9_]{10,}\\b")
    private val telegramToken = Regex("\\b\\d{5,}:[A-Za-z0-9_-]{20,}\\b")
    private val jwt = Regex("\\beyJ[A-Za-z0-9_-]{8,}\\.[A-Za-z0-9_-]{8,}\\.[A-Za-z0-9_-]{8,}\\b")
    private val email = Regex("(?i)\\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,}\\b")
    private val macAddress = Regex("(?i)\\b(?:[0-9a-f]{2}:){5}[0-9a-f]{2}\\b")

    fun redact(input: String): String = input
        // Remove complete auth/cookie header values before generic key/value redaction.
        .replace(authorization, "$1[REDACTED]")
        .replace(cookieHeader, "$1: [REDACTED]")
        .replace(bearer, "Bearer [REDACTED]")
        .replace(basic, "Basic [REDACTED]")
        .replace(assignment, "$1[REDACTED]")
        .replace(queryValue, "$1[REDACTED]")
        .replace(githubToken, "[REDACTED_GITHUB_TOKEN]")
        .replace(telegramToken, "[REDACTED_TELEGRAM_TOKEN]")
        .replace(jwt, "[REDACTED_JWT]")
        .replace(email, "[REDACTED_EMAIL]")
        .replace(macAddress, "[REDACTED_DEVICE_ADDRESS]")
}
