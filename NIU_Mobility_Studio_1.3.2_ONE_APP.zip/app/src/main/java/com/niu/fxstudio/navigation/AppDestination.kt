package com.niu.fxstudio.navigation

/** Stable route identifiers. The numeric legacy tab mapping is retained for 0.10.x compatibility. */
enum class AppDestination(val legacyTab: Int, val title: String) {
    WORKSPACE(0, "Workspace"),
    CONTROL(1, "Пульт"),
    PROFILE(2, "Профиль"),
    SETTINGS(3, "Инструменты"),
    CONNECTION(7, "Связь"),
    BLE(4, "BLE Explorer"),
    NFC(5, "NFC"),
    DIAGNOSTICS(6, "Диагностика"),
    DISPLAY(8, "Дисплей"),
    MUSIC(9, "Музыка"),
    SOUND(10, "Звуки"),
    ABOUT(11, "О приложении"),
    AI(12, "AI Assistant"),
    CODE_WORKSPACE(13, "Code Workspace"),
    TELEGRAM(16, "Telegram и локальный сервер");

    companion object {
        fun fromLegacyTab(tab: Int): AppDestination = entries.firstOrNull { it.legacyTab == tab } ?: WORKSPACE
    }
}
