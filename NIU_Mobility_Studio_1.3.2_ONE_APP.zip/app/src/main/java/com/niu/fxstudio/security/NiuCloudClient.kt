package com.niu.fxstudio.security

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import java.nio.ByteBuffer
import java.nio.CharBuffer
import java.nio.charset.StandardCharsets
import java.util.UUID
import javax.net.ssl.HttpsURLConnection

/**
 * NIU cloud compatibility client using the reverse-engineered NIU v3 OAuth contract
 * and the documented vehicle-list endpoint. This is not an official NIU SDK.
 * The password is MD5-hashed locally, sent only as a digest over TLS, and never persisted.
 */
class NiuCloudClient(
    private val region: Region,
    private val trace: (String) -> Unit = {},
    private val captureResponseDetails: Boolean = false
) {
    enum class Region(val accountBase: String, val apiBase: String) {
        GLOBAL("https://account.niu.com/", "https://app-api.niu.com/"),
        CHINA("https://account-fk.niu.com/", "https://app-api-fk.niu.com/")
    }

    companion object {
        // OAuth contract corroborated by the maintained evcc NIU integration.
        // The password is MD5-hashed locally; only the digest is sent over TLS.
        private const val OAUTH_APP_ID = "niu_8xt1afu6"
        const val CLIENT_USER_AGENT = "NIU-Mobility-Studio/1.2.5 (Android)"
    }

    data class Vehicle(
        val serial: String, val name: String, val model: String, val vin: String,
        val productType: String = "", val vehicleTypeId: String = "", val brand: String = "",
        val specialEdition: String = "", val engineNo: String = "", val isDoubleBattery: Boolean? = null
    ) {
        /** Server-supplied identity fields; user nickname is deliberately excluded. */
        fun serverIdentityText(): String = listOf(model, productType, vehicleTypeId, brand, specialEdition)
            .filter(String::isNotBlank).joinToString(" | ")
    }

    data class BatterySnapshot(
        val compartment: String,
        val bmsId: String = "",
        val connected: Boolean? = null,
        val chargePercent: Double? = null,
        val temperatureC: Double? = null,
        val chargeCycles: String = "",
        val healthGrade: String = "",
        val faultCount: Int? = null
    )

    data class TelemetrySnapshot(
        val serial: String,
        val fetchedAtEpochMs: Long,
        val vehicleConnected: Boolean? = null,
        val charging: Boolean? = null,
        val lockStatus: Int? = null,
        val speedKmh: Double? = null,
        val estimatedRangeKm: Double? = null,
        val totalMileageKm: Double? = null,
        val controllerBatteryPercent: Double? = null,
        val gpsSignal: Int? = null,
        val gsmSignal: Int? = null,
        val infoTimestampEpochMs: Long? = null,
        val batteries: List<BatterySnapshot> = emptyList(),
        val sourceStates: Map<String, String> = emptyMap(),
        val warnings: List<String> = emptyList()
    )

    fun login(account: String, password: CharArray): String {
        require(account.isNotBlank() && password.isNotEmpty()) { "Введите логин и пароль NIU" }
        val authStarted = System.nanoTime()
        val authTraceId = UUID.randomUUID().toString().take(8)
        trace("AUTH[$authTraceId] stage=START · profile=niu-oauth-v3 · region=${region.name} · host=${URL(region.accountBase).host} · account=${maskAccount(account)} · accountType=${if (account.contains('@')) "email" else "username-or-phone"}")

        // NIU FK OAuth contract: account, app_id, grant_type, MD5(password), scope.
        // countryCode belongs to the legacy appv2 phone-login form, not this OAuth contract.
        trace("AUTH[$authTraceId] stage=PASSWORD_PREPARE · algorithm=MD5-hex · passwordProvided=true")
        val digest = md5Hex(password)
        trace("AUTH[$authTraceId] stage=PASSWORD_READY · digestLength=${digest.length} · digestValue=REDACTED")
        val oauthParameters = linkedMapOf(
            "account" to account,
            "app_id" to OAUTH_APP_ID,
            "grant_type" to "password",
            "password" to digest,
            "scope" to "base"
        )
        val query = oauthParameters.entries.joinToString("&") { "${encode(it.key)}=${encode(it.value)}" }
        val endpoint = URL(region.accountBase + "v3/api/oauth2/token?" + query)
        trace("AUTH[$authTraceId] stage=REQUEST_READY · profile=legacy-get · method=GET · endpoint=/v3/api/oauth2/token · queryKeys=[account,app_id,grant_type,password,scope] · accountValue=REDACTED · password=MD5(REDACTED) · appId=$OAUTH_APP_ID · grantType=password · scope=base · countryCode=omitted")
        val json = try {
            request(endpoint, "GET", "", null, "login", authTraceId)
        } catch (legacyError: Exception) {
            val isCompatibilityRejection = legacyError.message.orEmpty().contains("outdated", ignoreCase = true)
            if (!isCompatibilityRejection) throw legacyError

            // Experimental transport compatibility check only. The app ID and OAuth
            // parameters remain unchanged; no official-client identity is spoofed.
            // NIU's POST/form contract is not publicly confirmed, so this is a
            // diagnostic fallback and the legacy GET remains the primary path.
            trace("AUTH[$authTraceId] stage=EXPERIMENTAL_RETRY · profile=post-form · reason=server-rejected-legacy-get-as-outdated · appIdUnchanged=true · credentialValues=REDACTED")
            val postEndpoint = URL(region.accountBase + "v3/api/oauth2/token")
            try {
                request(postEndpoint, "POST", form(oauthParameters), null, "login-post-form", authTraceId)
            } catch (postError: Exception) {
                trace("AUTH[$authTraceId] stage=EXPERIMENTAL_RETRY_FAILED · getError=${safeText(legacyError.message.orEmpty()).take(160)} · postError=${safeText(postError.message.orEmpty()).take(160)}")
                throw IllegalStateException(
                    "NIU отклонил оба варианта OAuth-запроса. GET: ${safeText(legacyError.message.orEmpty()).take(120)}; POST/form: ${safeText(postError.message.orEmpty()).take(120)}",
                    postError
                )
            }
        }
        val data = json.optJSONObject("data")
        val tokenValue = data?.opt("token")
        val token = when (tokenValue) {
            is String -> tokenValue
            is JSONObject -> tokenValue.optString("access_token")
                .ifBlank { tokenValue.optString("accessToken") }
                .ifBlank { tokenValue.optString("token") }
                .ifBlank { tokenValue.optString("value") }
            else -> data?.optString("access_token").orEmpty()
                .ifBlank { data?.optString("accessToken").orEmpty() }
                .ifBlank { json.optString("access_token") }
                .ifBlank { json.optString("accessToken") }
        }
        if (token.isBlank()) {
            val description = data?.optString("desc").orEmpty()
                .ifBlank { json.optString("desc") }
                .ifBlank { json.optString("error_description") }
                .ifBlank { json.optString("message") }
            trace("AUTH[$authTraceId] stage=REJECTED · elapsedMs=${(System.nanoTime() - authStarted) / 1_000_000} · tokenPresent=false · desc=${safeText(description)} · response=${summarizeJson(json.toString())}")
            throw IllegalStateException(description.ifBlank { "NIU OAuth не вернул access_token" })
        }
        trace("AUTH[$authTraceId] stage=TOKEN_RECEIVED · elapsedMs=${(System.nanoTime() - authStarted) / 1_000_000} · tokenPresent=true · tokenValue=REDACTED")
        return token
    }

    /**
     * Read-only NIU Cloud telemetry. Endpoint paths and response fields are based on
     * public reverse-engineered NIU API documentation; availability varies by model/region.
     * Each endpoint is isolated so one unsupported endpoint does not discard other data.
     */
    fun fetchTelemetry(token: String, serial: String): TelemetrySnapshot {
        require(token.isNotBlank()) { "NIU Cloud session отсутствует" }
        require(serial.isNotBlank()) { "Не выбран серийный номер скутера" }
        val states = linkedMapOf<String, String>()
        val warnings = mutableListOf<String>()
        var motor = JSONObject()
        var battery = JSONObject()
        var health = JSONObject()
        var tally = JSONObject()

        fun getData(label: String, path: String): JSONObject? = try {
            val url = URL(region.apiBase + path + "?sn=" + encode(serial))
            val response = request(url, "GET", "", token, "telemetry-$label")
            val data = response.optJSONObject("data")
            if (data == null || data.length() == 0) {
                states[label] = "EMPTY"
                warnings += "$label: Cloud не вернул данные"
                null
            } else {
                states[label] = "OK"
                data
            }
        } catch (e: Exception) {
            states[label] = "ERROR"
            warnings += "$label: ${safeText(e.message.orEmpty()).take(140)}"
            trace("TELEMETRY endpoint=$label failed · ${e.javaClass.simpleName} · ${safeText(e.message.orEmpty()).take(160)}")
            null
        }

        motor = getData("motor", "v3/motor_data/index_info") ?: JSONObject()
        battery = getData("battery", "v3/motor_data/battery_info") ?: JSONObject()
        health = getData("battery_health", "v3/motor_data/battery_info/health") ?: JSONObject()

        // Historical API documents this as POST with SN in form body.
        tally = try {
            val response = request(URL(region.apiBase + "motoinfo/overallTally"), "POST", form(mapOf("sn" to serial, "token" to token)), token, "telemetry-mileage")
            response.optJSONObject("data") ?: JSONObject().also { states["mileage"] = "EMPTY" }
        } catch (e: Exception) {
            states["mileage"] = "ERROR"
            warnings += "mileage: ${safeText(e.message.orEmpty()).take(140)}"
            JSONObject()
        }
        if (tally.length() > 0) states["mileage"] = "OK"

        val motorBatteries = motor.optJSONObject("batteries")
        val batteryBatteries = battery.optJSONObject("batteries")
        val healthBatteries = health.optJSONObject("batteries")
        val compartments = listOf("compartmentA" to "A", "compartmentB" to "B")
        val parsedBatteries = compartments.mapNotNull { (key, label) ->
            val b = batteryBatteries?.optJSONObject(key) ?: motorBatteries?.optJSONObject(key)
            if (b == null) return@mapNotNull null
            val h = healthBatteries?.optJSONObject(key)
            val faults = h?.optJSONArray("faults")
            BatterySnapshot(
                compartment = label,
                bmsId = b.optString("bmsId").take(48),
                connected = b.opt("isConnected") as? Boolean,
                chargePercent = b.numberOrNull("batteryCharging"),
                temperatureC = b.numberOrNull("temperature"),
                chargeCycles = b.optString("chargedTimes").take(24),
                healthGrade = b.optString("gradeBattery").ifBlank { h?.optString("gradeBattery").orEmpty() }.take(24),
                faultCount = faults?.length()
            )
        }
        if (parsedBatteries.isEmpty() && states["battery"] == "OK") warnings += "battery: ответ получен, но compartments A/B отсутствуют или имеют неизвестную структуру"

        return TelemetrySnapshot(
            serial = serial,
            fetchedAtEpochMs = System.currentTimeMillis(),
            vehicleConnected = motor.opt("isConnected") as? Boolean,
            charging = (motor.optIntOrNull("isCharging") ?: battery.optIntOrNull("isCharging"))?.let { it != 0 },
            lockStatus = motor.optIntOrNull("lockStatus"),
            speedKmh = motor.numberOrNull("nowSpeed"),
            estimatedRangeKm = (motor.numberOrNull("estimatedMileage") ?: battery.numberOrNull("estimatedMileage")),
            totalMileageKm = tally.numberOrNull("totalMileage"),
            controllerBatteryPercent = motor.numberOrNull("centreCtrlBattery") ?: battery.numberOrNull("centreCtrlBattery"),
            gpsSignal = motor.optIntOrNull("gps"),
            gsmSignal = motor.optIntOrNull("gsm"),
            infoTimestampEpochMs = motor.optLongOrNull("infoTimestamp"),
            batteries = parsedBatteries,
            sourceStates = states.toMap(),
            warnings = warnings.toList()
        )
    }

    private fun JSONObject.numberOrNull(key: String): Double? = when (val value = opt(key)) {
        is Number -> value.toDouble().takeIf { it.isFinite() }
        is String -> value.toDoubleOrNull()?.takeIf { it.isFinite() }
        else -> null
    }

    private fun JSONObject.optIntOrNull(key: String): Int? = when (val value = opt(key)) {
        is Number -> value.toInt()
        is String -> value.toIntOrNull()
        else -> null
    }

    private fun JSONObject.optLongOrNull(key: String): Long? = when (val value = opt(key)) {
        is Number -> value.toLong()
        is String -> value.toLongOrNull()
        else -> null
    }

    private fun md5Hex(chars: CharArray): String {
        val encoded: ByteBuffer = StandardCharsets.UTF_8.newEncoder().encode(CharBuffer.wrap(chars))
        val bytes = ByteArray(encoded.remaining())
        encoded.get(bytes)
        return try {
            MessageDigest.getInstance("MD5").digest(bytes)
                .joinToString("") { "%02x".format(it) }
        } finally {
            bytes.fill(0)
        }
    }

    fun listVehicles(token: String): List<Vehicle> {
        trace("VEHICLES list started · region=${region.name} · session=present")
        val json = request(URL(region.apiBase + "motoinfo/list"), "POST", form(mapOf("masterOnly" to "0")), token, "vehicle-list")
        val data = json.optJSONArray("data") ?: throw IllegalStateException(json.optString("desc", "NIU не вернул список устройств"))
        val result = buildList {
            for (i in 0 until data.length()) {
                val row = data.optJSONObject(i) ?: continue
                val sn = row.optString("sn").trim()
                if (sn.isNotBlank()) add(Vehicle(
                    serial = sn,
                    name = row.optString("name").ifBlank { row.optString("type").ifBlank { "NIU $sn" } },
                    model = row.optString("type"),
                    vin = row.optString("frameNo"),
                    productType = row.optString("productType"),
                    vehicleTypeId = row.optString("vehicleTypeId"),
                    brand = row.optString("brand"),
                    specialEdition = row.optString("specialEdition"),
                    engineNo = row.optString("engineNo"),
                    isDoubleBattery = if (row.has("isDoubleBattery") && !row.isNull("isDoubleBattery")) row.optBoolean("isDoubleBattery") else null
                ))
            }
        }
        trace("VEHICLES list parsed · count=${result.size} · serials=${if (captureResponseDetails) result.joinToString { maskSerial(it.serial) } else "hidden"} · serverModelFields=${result.joinToString { listOf(it.model, it.productType, it.vehicleTypeId, it.brand, it.specialEdition).filter(String::isNotBlank).joinToString("/").take(80).ifBlank { "unknown" } }} · VIN/frameNo=${result.count { it.vin.isNotBlank() }} present · engineNo=${result.count { it.engineNo.isNotBlank() }} present")
        return result
    }

    private fun request(url: URL, method: String, body: String, token: String?, operation: String, parentTraceId: String = UUID.randomUUID().toString().take(8)): JSONObject {
        val started = System.nanoTime()
        val requestId = UUID.randomUUID().toString().take(8)
        val safeUrl = "${url.protocol}://${url.host}${url.path}"
        val formKeys = body.split('&').mapNotNull { it.substringBefore('=').takeIf(String::isNotBlank) }
        val queryParts = url.query.orEmpty().split('&').filter(String::isNotBlank)
        val queryKeys = queryParts.map { it.substringBefore('=') }
        val parameterKeys = (queryKeys + formKeys).distinct().joinToString(",")
        val bodyBytes = body.toByteArray(Charsets.UTF_8).size
        trace("HTTP[$requestId] → BEGIN · parent=$parentTraceId · op=$operation · method=$method · url=$safeUrl · host=${url.host} · port=${if (url.port > 0) url.port else if (url.protocol == "https") 443 else 80} · queryKeys=[$parameterKeys] · queryParamCount=${queryParts.size} · formBytes=$bodyBytes · tokenHeader=${!token.isNullOrBlank()} · connectTimeoutMs=15000 · readTimeoutMs=20000")
        if (captureResponseDetails) {
            val queryMeta = queryParts.joinToString(",") { part ->
                val key = part.substringBefore('=')
                val value = part.substringAfter('=', "")
                if (key.lowercase() in setOf("account", "password", "token", "access_token", "refresh_token", "sign", "x-jg-sign")) {
                    "$key(value=REDACTED)"
                } else {
                    val decodedLength = runCatching { java.net.URLDecoder.decode(value, "UTF-8").length }.getOrDefault(-1)
                    "$key(valueLength=$decodedLength)"
                }
            }
            trace("HTTP[$requestId] request metadata · query=[$queryMeta] · requestBody=not-logged · secretValues=REDACTED")
        }
        val connection = try {
            (url.openConnection() as HttpURLConnection).apply {
                requestMethod = method
                connectTimeout = 15_000
                readTimeout = 20_000
                doOutput = method != "GET"
                if (method != "GET") setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
                setRequestProperty("Accept", "application/json")
                setRequestProperty("User-Agent", CLIENT_USER_AGENT)
                setRequestProperty("Accept-Language", "en-US,en;q=0.9")
                if (!token.isNullOrBlank()) setRequestProperty("token", token)
            }
        } catch (e: Exception) {
            trace("HTTP[$requestId] CONNECTION SETUP ERROR · op=$operation · exception=${e.javaClass.name}: ${safeText(e.message.orEmpty())}")
            throw e
        }
        return try {
            if (method != "GET") {
                connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            trace("HTTP[$requestId] connection established · requestProperties=[Accept,User-Agent,Accept-Language${if (method != "GET") ",Content-Type" else ""}${if (!token.isNullOrBlank()) ",token" else ""}] · redirectFollowing=${connection.instanceFollowRedirects}")
            val status = connection.responseCode
            val stream = if (status in 200..299) connection.inputStream else connection.errorStream
            val response = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            val elapsedMs = (System.nanoTime() - started) / 1_000_000
            val responseBytes = response.toByteArray(Charsets.UTF_8).size
            trace("HTTP[$requestId] ← HEADERS · status=$status · op=$operation · elapsedMs=$elapsedMs · responseBytes=$responseBytes · contentType=${safeText(connection.contentType ?: "unknown")} · server=${safeText(connection.getHeaderField("Server") ?: "unknown")}")
            val headerNames = connection.headerFields.keys.filterNotNull().map { it.lowercase() }.distinct().sorted()
            trace("HTTP[$requestId] response header names=[${headerNames.joinToString(",")}]")
            val safeHeaderValues = listOf("Date", "Server", "Content-Type", "Via", "X-Request-Id", "X-Trace-Id", "Trace-Id")
                .mapNotNull { name -> connection.getHeaderField(name)?.let { "$name=${safeText(it).take(160)}" } }
            if (safeHeaderValues.isNotEmpty()) trace("HTTP[$requestId] response safe headers · ${safeHeaderValues.joinToString(" · ")}")
            if (connection is HttpsURLConnection) {
                val tls = runCatching { "protocol=TLS-negotiated · cipher=${connection.cipherSuite}" }.getOrDefault("TLS details unavailable")
                trace("HTTP[$requestId] TLS · $tls")
            }
            if (captureResponseDetails) trace("HTTP[$requestId] response structure · op=$operation · ${summarizeJson(response)}")
            val json = try {
                if (response.isBlank()) JSONObject() else JSONObject(response)
            } catch (e: Exception) {
                trace("HTTP[$requestId] PARSE ERROR · op=$operation · status=$status · exception=${e.javaClass.simpleName} · message=${safeText(e.message.orEmpty())} · bodyChars=${response.length} · bodyContent=NOT_LOGGED")
                if (status !in 200..299) throw IllegalStateException("NIU cloud HTTP $status · ответ сервера не JSON")
                throw e
            }
            if (status !in 200..299) {
                val serverDescription = json.optString("desc").ifBlank { json.optString("message") }
                trace("HTTP[$requestId] HTTP ERROR · op=$operation · status=$status · desc=${safeText(serverDescription)} · response=${summarizeJson(response)}")
                val detail = safeText(serverDescription).ifBlank { "сервер не передал описание ошибки" }
                throw IllegalStateException("NIU cloud HTTP $status: $detail")
            }
            val dataObject = json.optJSONObject("data")
            val apiStatus = json.opt("status") ?: json.opt("code") ?: json.opt("retCode")
            val serverDescription = json.optString("desc")
                .ifBlank { json.optString("message") }
                .ifBlank { json.optString("error_description") }
                .ifBlank { json.optString("error") }
                .ifBlank { dataObject?.optString("desc").orEmpty() }
                .ifBlank { dataObject?.optString("message").orEmpty() }
                .ifBlank { dataObject?.optString("error_description").orEmpty() }
            // NIU often returns HTTP 200 with an application-level status=400.
            // Classify the known compatibility response before generic API errors.
            if (operation == "login" && serverDescription.contains("outdated", true)) {
                val traceId = json.optString("trace").take(120)
                val apiStatusText = when (apiStatus) {
                    is Number, is String -> apiStatus.toString()
                    else -> "not-provided"
                }
                val dataKeys = dataObject?.let { data ->
                    data.keys().asSequence().toList().sorted().joinToString(",").take(240)
                }.orEmpty()
                // Keep the server's actual diagnostic text. Never log request values,
                // credentials, access tokens, or the raw response body.
                trace("AUTH[$parentTraceId] VERSION REJECTED · requestId=$requestId · apiStatus=$apiStatusText · desc=${safeText(serverDescription).take(240)} · serverTrace=${safeText(traceId)} · dataKeys=[$dataKeys] · credentialValidation=not-reached-or-not-confirmed · clientSignature=not-implemented")
                throw IllegalStateException(
                    "NIU отклонил OAuth-клиент как устаревший: ${safeText(serverDescription).take(180)}. " +
                        "Пароль этим ответом не проверен; см. NIU CLOUD log для server trace."
                )
            }
            if (json.has("status")) {
                val statusCode = when (apiStatus) {
                    is Number -> apiStatus.toInt()
                    is String -> apiStatus.toIntOrNull()
                    else -> null
                }
                val oauthTokenPresent = operation == "login" && dataObject?.opt("token") != null
                if (statusCode != null && statusCode !in listOf(0, 1, 200) && !oauthTokenPresent) {
                    trace("HTTP[$requestId] API ERROR · op=$operation · apiStatus=$apiStatus · desc=${safeText(serverDescription)} · response=${summarizeJson(response)}")
                    throw IllegalStateException(serverDescription.ifBlank { "NIU cloud отклонил запрос (status=$apiStatus)" })
                }
            }
            val successValue = json.opt("success")
            if (successValue == false) {
                val errorCode = json.opt("code") ?: json.opt("retCode") ?: apiStatus ?: "unknown"
                trace("HTTP[$requestId] API ERROR · op=$operation · success=false · code=$errorCode · desc=${safeText(serverDescription)} · response=${summarizeJson(response)}")
                throw IllegalStateException(serverDescription.ifBlank { "NIU cloud отклонил запрос (code=$errorCode)" })
            }
            trace("HTTP[$requestId] API OK · op=$operation · apiStatus=${json.opt("status") ?: "not-provided"} · elapsedMs=${(System.nanoTime() - started) / 1_000_000}")
            json
        } catch (e: Exception) {
            val elapsedMs = (System.nanoTime() - started) / 1_000_000
            trace("HTTP[$requestId] EXCEPTION · op=$operation · exception=${e.javaClass.name} · elapsedMs=$elapsedMs · message=${safeText(e.message.orEmpty())}")
            var cause = e.cause
            var causeDepth = 0
            while (cause != null && causeDepth < 4) {
                trace("HTTP[$requestId] CAUSE[$causeDepth] · ${cause.javaClass.name}: ${safeText(cause.message.orEmpty())}")
                cause = cause.cause
                causeDepth++
            }
            e.stackTrace.take(16).forEach { trace("HTTP[$requestId] STACK · $it") }
            throw e
        } finally { connection.disconnect() }
    }

    private fun form(values: Map<String, String>): String = values.entries
        .filter { it.value.isNotEmpty() }
        .joinToString("&") { "${encode(it.key)}=${encode(it.value)}" }

    private fun encode(value: String) = URLEncoder.encode(value, "UTF-8")

    private fun maskAccount(value: String): String = when {
        value.contains('@') -> value.substringBefore('@').take(1) + "•••@" + value.substringAfter('@')
        value.length > 4 -> value.take(2) + "••••" + value.takeLast(2)
        else -> "••••"
    }

    private fun maskSerial(value: String): String = if (value.length > 6) value.take(3) + "••••" + value.takeLast(3) else "••••"

    private fun safeText(value: String): String = value
        .replace(Regex("(?i)([\"']?(?:account|token|password|access_token|refresh_token|authorization|cookie|x-jg-sign|sign)[\"']?\\s*[:=]\\s*)[\"']?[^,}\\s\"']+[\"']?"), "$1[REDACTED]")
        .replace(Regex("(?i)Bearer\\s+[^\\s]+"), "Bearer [REDACTED]")
        .replace(Regex("(?i)gh[pousr]_[A-Za-z0-9_]{10,}"), "[REDACTED_TOKEN]")
        .replace(Regex("(?i)([?&](?:account|password|token|access_token|refresh_token|authorization|sign|x-jg-sign)=)[^&\\s]+"), "$1[REDACTED]")

    private fun summarizeJson(raw: String): String = runCatching {
        val json = JSONObject(raw)
        val shape = mutableListOf<String>()
        fun walk(value: Any?, path: String, depth: Int) {
            if (shape.size >= 80 || depth > 5) return
            when (value) {
                is JSONObject -> {
                    val iterator = value.keys()
                    while (iterator.hasNext() && shape.size < 80) {
                        val key = iterator.next()
                        val child = value.opt(key)
                        val childPath = if (path.isBlank()) key else "$path.$key"
                        val type = when (child) {
                            JSONObject.NULL -> "null"
                            is JSONObject -> "object"
                            is org.json.JSONArray -> "array(${child.length()})"
                            is String -> "string"
                            is Number -> "number"
                            is Boolean -> "boolean"
                            else -> "other"
                        }
                        shape += "$childPath:$type"
                        if (child is JSONObject) walk(child, childPath, depth + 1)
                        if (child is org.json.JSONArray && child.length() > 0) walk(child.opt(0), "$childPath[0]", depth + 1)
                    }
                }
                is org.json.JSONArray -> if (value.length() > 0) walk(value.opt(0), "$path[0]", depth + 1)
            }
        }
        walk(json, "", 0)
        "jsonShape=${shape.joinToString("; ")}"
    }.getOrElse { "non-JSON body (${raw.length} chars)" }
}
