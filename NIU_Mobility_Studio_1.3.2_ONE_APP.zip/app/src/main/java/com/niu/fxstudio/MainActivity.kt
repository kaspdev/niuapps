package com.niu.fxstudio

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.nfc.tech.Ndef
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothProfile
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import java.util.UUID
import java.util.Locale
import java.io.File
import java.nio.ByteBuffer
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.pm.PackageManager
import android.content.Intent
import android.content.Context
import android.content.ClipData
import android.content.ClipboardManager
import android.widget.Toast
import android.net.Uri
import android.graphics.BitmapFactory
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.MediaExtractor
import android.media.MediaMuxer
import android.media.MediaFormat
import android.media.MediaCodec
import android.os.Handler
import android.os.Looper
import android.os.Build
import android.os.Bundle
import androidx.fragment.app.FragmentActivity
import androidx.biometric.BiometricPrompt
import androidx.biometric.BiometricManager
import android.content.DialogInterface
import androidx.activity.compose.BackHandler
import androidx.activity.enableEdgeToEdge
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image as ComposeImage
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.DirectionsBike
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.niu.fxstudio.security.AdminGrantVerifier
import com.niu.fxstudio.security.SecureSecretStore
import com.niu.fxstudio.security.GitHubBuildClient
import com.niu.fxstudio.security.GitHubOAuthDeviceFlow
import com.niu.fxstudio.security.NiuCloudClient
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import com.niu.sdk.bridge.CloudEcuBridge
import com.niu.sdk.bridge.CloudVehicleIdentity
import com.niu.sdk.bridge.BleVehicleIdentity
import com.niu.sdk.commands.NiuCommandRegistry
import com.niu.sdk.commands.NiuCommandTestSimulator
import com.niu.sdk.profile.NiuModelCatalog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.util.concurrent.atomic.AtomicBoolean
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import androidx.core.content.ContextCompat

private object AppAppearance {
    var selected by mutableStateOf("CURRENT")
    val isTelegramStyle: Boolean get() = selected == "TELEGRAM"
    val ink: Color get() = if (isTelegramStyle) Color(0xFF17212B) else Color(0xFF101010)
    val panel: Color get() = if (isTelegramStyle) Color(0xFF232E3C) else Color(0xFF1D1D1D)
    val panel2: Color get() = if (isTelegramStyle) Color(0xFF2B3A4D) else Color(0xFF292929)
    val accent: Color get() = if (isTelegramStyle) Color(0xFF55A7E8) else Color(0xFFE53935)
    val muted: Color get() = if (isTelegramStyle) Color(0xFF9AAFC2) else Color(0xFFA5A5A5)
}
private val Ink get() = AppAppearance.ink
private val Panel get() = AppAppearance.panel
private val Panel2 get() = AppAppearance.panel2
private val Lime get() = AppAppearance.accent
private val Muted get() = AppAppearance.muted


private fun formatTelegramConsoleLine(raw: String): String {
    val cleaned = raw.replace("\\n", " · ").replace("\r", " ").trim()
    val full = Regex("^(\\d{4}-\\d{2}-\\d{2} )?(\\d{2}:\\d{2}:\\d{2})(?:\\.\\d{3})?\\s+\\[(INFO|WARN|ERROR)\\](?:\\[([^]]+)\\])?\\s*(.*)$", RegexOption.IGNORE_CASE)
    val match = full.matchEntire(cleaned)
    if (match != null) {
        val time = match.groupValues[2]
        val level = match.groupValues[3].uppercase(Locale.ROOT)
        val category = match.groupValues[4].takeIf { it.isNotBlank() } ?: "TELEGRAM"
        val message = match.groupValues[5].replace(Regex("(?i)LEGACY IMPORT\\s*·?\\s*"), "").take(240)
        return "$time  $level  $category  $message"
    }
    val simple = Regex("^(\\d{2}:\\d{2}:\\d{2})\\s+\\[(INFO|WARN|ERROR)\\]\\s*(.*)$", RegexOption.IGNORE_CASE).matchEntire(cleaned)
    if (simple != null) return "${simple.groupValues[1]}  ${simple.groupValues[2].uppercase(Locale.ROOT)}  TELEGRAM  ${simple.groupValues[3].take(240)}"
    return cleaned.removePrefix("LEGACY IMPORT · ").take(280)
}

private fun formatTelegramLogDigest(lines: List<String>, title: String): String {
    if (lines.isEmpty()) return "$title\n\nЗаписей пока нет."
    return (listOf(title, "") + lines.map(::formatTelegramConsoleLine)).joinToString("\n").take(3900)
}

private data class HelpContent(val title: String, val description: String)

private data class SavedNiuVehicle(
    val serial: String, val name: String, val familyId: String, val model: String,
    val vin: String = "", val bleAddress: String = "", val cloudLinked: Boolean = false
)

class MainActivity : FragmentActivity(), NfcAdapter.ReaderCallback {
    private val nfcAdapter: NfcAdapter? by lazy { NfcAdapter.getDefaultAdapter(this) }
    private var nfcStatus by mutableStateOf("Поднесите карту к телефону")
    private var nfcReport by mutableStateOf("Карта ещё не считана")
    private var nfcLastReadAt by mutableStateOf<String?>(null)
    private val devices = mutableStateListOf<BluetoothDevice>()
    private val logs = mutableStateListOf<String>()
    private val signalByAddress = mutableStateMapOf<String, Int>()
    private val savedVehicles = mutableStateListOf<SavedNiuVehicle>()
    private var activeVehicleSerial by mutableStateOf("")
    private var showVehicleEditor by mutableStateOf(false)
    private var editingVehicleSerial by mutableStateOf("")
    private var vehicleNameInput by mutableStateOf("")
    private var vehicleSerialInput by mutableStateOf("")
    private var vehicleVinInput by mutableStateOf("")
    private var vehicleEditorMessage by mutableStateOf("")
    private var showNiuCloudLogin by mutableStateOf(false)
    // One-shot bridge: dialogs may be composed outside FxApp local navigation scope.
    private var cloudJournalNavigationRequest by mutableStateOf(false)
    private var niuCloudAccount by mutableStateOf("")
    private var niuCloudPassword by mutableStateOf("")
    private var niuCloudRegion by mutableStateOf("GLOBAL")
    private var niuCloudStatus by mutableStateOf("Не подключено")
    private var niuCloudVerboseTrace by mutableStateOf(false)
    private var niuCloudVehicles = mutableStateListOf<NiuCloudClient.Vehicle>()
    private var niuCloudTelemetry by mutableStateOf<NiuCloudClient.TelemetrySnapshot?>(null)
    private var niuCloudTelemetryStatus by mutableStateOf("Данные ещё не запрашивались")
    private var niuCloudTelemetryLoading by mutableStateOf(false)
    private val mainHandler = Handler(Looper.getMainLooper())
    private val scanTimeout = Runnable { stopScan(); addLog("Поиск завершён · найдено устройств: ${devices.size}") }
    private var gatt: BluetoothGatt? = null
    private var pendingExportText: String = ""
    private var pendingLogExportText: String = ""
    private var showMdpasteConfirm by mutableStateOf(false)
    private var activeHelp by mutableStateOf<HelpContent?>(null)
    private var pendingReadmeExportText: String = ""
    private var pendingReadmeExportName: String = "README.md"
    private var logFilter by mutableStateOf("Все")
    private var persistentLoggingEnabled by mutableStateOf(true)
    private var logAutoScrollEnabled by mutableStateOf(true)
    private var selectedNiuFamily by mutableStateOf("fx")
    private var selectedNiuModel by mutableStateOf("FX 风速版")
    private var editorFileUri by mutableStateOf<Uri?>(null)
    private var editorFileName by mutableStateOf("Новый файл")
    private var editorText by mutableStateOf("// NIU Mobility Studio 1.0.0\n// Откройте исходный файл проекта для редактирования.\n")
    private var editorDirty by mutableStateOf(false)
    private var editorStatus by mutableStateOf("Файл не открыт")
    private var pendingEditorSave: String = ""
    private var telegramPollingThread: Thread? = null
    private var telegramPollingFlag: AtomicBoolean? = null
    private var localControlServer: com.niu.fxstudio.security.LocalControlServer? = null
    private var wallpaperUri by mutableStateOf<Uri?>(null)
    private var wallpaperBitmap by mutableStateOf<android.graphics.Bitmap?>(null)
    private var wallpaperAccent by mutableIntStateOf(0)
    private var wallpaperZoom by mutableFloatStateOf(1f)
    private var wallpaperSaved by mutableStateOf(false)
    private var musicUri by mutableStateOf<Uri?>(null)
    private val musicUris = mutableStateListOf<Uri>()
    private var musicIndex by mutableIntStateOf(0)
    private var musicTitle by mutableStateOf("Треки не выбраны")
    private var musicPlaying by mutableStateOf(false)
    private var musicVolume by mutableFloatStateOf(0.8f)
    private var audioOutputSummary by mutableStateOf("Аудиовыход ещё не проверен")
    private var soundUri by mutableStateOf<Uri?>(null)
    private var soundTitle by mutableStateOf("Звук не выбран")
    private var soundTheme by mutableStateOf("STANDARD")
    private var soundEvent by mutableStateOf("ALARM")
    private var soundTrigger by mutableStateOf("ONCE")
    private var mediaPlayer: MediaPlayer? = null
    private var loadedAudioUri: Uri? = null
    private var loadedAudioIsMusic = false
    private var referenceFileName by mutableStateOf<String?>(null)
    private var referenceRawText by mutableStateOf("")
    private val referenceCharacteristics = mutableStateMapOf<String, ReferenceCharacteristic>()
    private data class ReferenceCharacteristic(val properties: String, val value: String?)
    private val characteristicRows = mutableStateListOf<CharacteristicEntry>()
    private val characteristicValues = mutableStateMapOf<String, String>()
    private val notifyStates = mutableStateMapOf<String, Boolean>()
    private var readAllRunning = false
    private var readAllRemaining = 0
    private var lastBleWriteUuid by mutableStateOf<String?>(null)
    private var lastBleWriteHex by mutableStateOf("")
    private data class BleExchange(val id: Long, val uuid: String, val startedAt: Long, var rxCount: Int = 0)
    private data class BleCommandResult(val id: Long, val uuid: String, val payload: String, val state: String, val detail: String, val updatedAt: Long)
    private val bleCommandResults = mutableStateListOf<BleCommandResult>()
    private var activeBleExchange: BleExchange? = null

    private fun recordBleCommandFailure(uuid: String, payload: String, detail: String) {
        val id = ++bleExchangeSequence
        bleCommandResults.add(0, BleCommandResult(id, uuid, payload, "ERROR", detail, System.currentTimeMillis()))
        while (bleCommandResults.size > 20) bleCommandResults.removeAt(bleCommandResults.lastIndex)
        addLog("BLE COMMAND #$id ERROR · $detail · uuid=$uuid · TX=$payload")
    }

    private fun updateBleCommandResult(id: Long, state: String, detail: String) {
        val index = bleCommandResults.indexOfFirst { it.id == id }
        if (index >= 0) {
            val old = bleCommandResults[index]
            bleCommandResults[index] = old.copy(state = state, detail = detail, updatedAt = System.currentTimeMillis())
        }
    }
    private var bleExchangeSequence = 0L
    private val bleResponseTimeout = Runnable {
        val exchange = activeBleExchange ?: return@Runnable
        val elapsed = System.currentTimeMillis() - exchange.startedAt
        if (exchange.rxCount == 0) {
            addLog("BLE EXCHANGE #${exchange.id} TIMEOUT · TX=${exchange.uuid} · ${elapsed}ms · RX не получен; ECU_ACK_NOT_CONFIRMED")
            updateBleCommandResult(exchange.id, "TIMEOUT", "Ошибка: скутер не прислал ответ за 5 секунд")
        } else {
            addLog("BLE EXCHANGE #${exchange.id} WINDOW CLOSED · TX=${exchange.uuid} · RX candidates=${exchange.rxCount}; protocol ACK still unverified")
            updateBleCommandResult(exchange.id, "RX_RECEIVED", "Ответ получен (${exchange.rxCount} пакет.), выполнение команды протоколом не подтверждено")
        }
        activeBleExchange = null
    }

    // Android GATT permits only one outstanding ATT operation per connection.
    private data class PendingGattOperation(
        val label: String,
        val start: () -> Boolean,
        val onComplete: (Int) -> Unit = {}
    )
    private val gattOperationQueue = ArrayDeque<PendingGattOperation>()
    private var activeGattOperation: PendingGattOperation? = null
    private val gattQueueAdvance = Runnable { runNextGattOperation() }
    private val gattOperationTimeout = Runnable {
        val operation = activeGattOperation
        if (operation != null) {
            addLog("GATT timeout · ${operation.label}; queue stopped and connection closed")
            activeGattOperation = null
            gattOperationQueue.clear()
            readAllRunning = false
            readAllRemaining = 0
            val timedOutGatt = gatt
            gatt = null
            connectionState = "Ошибка GATT · timeout"
            connectedName = null
            connectedAddress = null
            serviceRows = emptyList()
            characteristicRows.clear()
            notifyStates.clear()
            runCatching { timedOutGatt?.disconnect() }
            runCatching { timedOutGatt?.close() }
        }
    }

    private data class CharacteristicEntry(
        val serviceUuid: String,
        val uuid: String,
        val properties: Int,
        val descriptors: List<String>
    )
    private var connectedName by mutableStateOf<String?>(null)
    private var connectedAddress by mutableStateOf<String?>(null)
    private var connectionState by mutableStateOf("Не подключено")
    private var serviceRows by mutableStateOf(listOf<String>())
    private var scanning by mutableStateOf(false)
    // A single guarded retry handles Android SCAN_FAILED_ALREADY_STARTED without a retry loop.
    private var bleScanRetryUsed = false
    private var findMode by mutableStateOf(false)
    private var findStatus by mutableStateOf("Ожидание поиска")
    private var findRssi by mutableStateOf<Int?>(null)
    private val knownNiuAddresses = setOf(
        "54:88:FE:54:F8:E1", // ранее обнаруженный NIU Link F8E1
        "54:88:FE:54:8B:2A"  // адрес из актуального отчёта NIU Link 8B2A
    )
    private val findTimeout = Runnable {
        stopScan()
        if (findRssi == null) findStatus = "NIU Link не обнаружен · проверьте питание и расстояние"
        else findStatus = "Поиск завершён · сигнал сохранён"
        addLog("FIND scan завершён · ${findStatus}")
    }
    private val adapter: BluetoothAdapter? get() = BluetoothAdapter.getDefaultAdapter()

    private val openEditorFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            }
            runCatching {
                val loaded = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                    ?: error("Не удалось открыть файл")
                editorFileUri = uri
                editorFileName = uri.lastPathSegment?.substringAfterLast('/')?.take(100) ?: "project-file"
                editorText = loaded
                editorDirty = false
                editorStatus = "Открыт: $editorFileName · ${loaded.length} символов"
                addLog("WORKSPACE: открыт файл $editorFileName")
            }.onFailure { editorStatus = "Ошибка открытия: ${it.message}"; addLog("WORKSPACE open error: ${it.message}") }
        }
    }

    private val createEditorFile = registerForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) {
            runCatching {
                contentResolver.openOutputStream(uri, "wt")?.bufferedWriter(Charsets.UTF_8)?.use { it.write(pendingEditorSave) }
                    ?: error("Не удалось записать файл")
                editorFileUri = uri
                editorFileName = uri.lastPathSegment?.substringAfterLast('/') ?: "project-file"
                editorText = pendingEditorSave
                editorDirty = false
                editorStatus = "Сохранено как: $editorFileName"
                addLog("WORKSPACE: файл сохранён как $editorFileName")
            }.onFailure { editorStatus = "Ошибка сохранения: ${it.message}"; addLog("WORKSPACE save error: ${it.message}") }
        }
    }

    private val exportLogsDocument = registerForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri != null) runCatching {
            contentResolver.openOutputStream(uri, "wt")?.bufferedWriter(Charsets.UTF_8)?.use { it.write(pendingLogExportText) }
                ?: error("Не удалось сохранить журнал")
            addLog("LOG EXPORT: сохранено ${uri.lastPathSegment?.substringAfterLast('/') ?: "file"}")
        }.onFailure { addLog("LOG EXPORT ERROR: ${it.message}") }
    }

    private val exportReadmeDocument = registerForActivityResult(ActivityResultContracts.CreateDocument("text/markdown")) { uri ->
        if (uri != null) runCatching {
            contentResolver.openOutputStream(uri, "wt")?.bufferedWriter(Charsets.UTF_8)?.use { it.write(pendingReadmeExportText) }
                ?: error("Не удалось сохранить документацию")
            addLog("README EXPORT: ${pendingReadmeExportName} сохранён")
        }.onFailure { addLog("README EXPORT ERROR: ${it.message}") }
        else addLog("README EXPORT: пользователь отменил сохранение")
    }

    private val createWorkspaceBackup = registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) {
            runCatching {
                val output = contentResolver.openOutputStream(uri) ?: error("Не удалось открыть архив для записи")
                ZipOutputStream(output).use { zip ->
                    zip.putNextEntry(ZipEntry(editorFileName.ifBlank { "workspace.txt" }))
                    zip.write(editorText.toByteArray(Charsets.UTF_8))
                    zip.closeEntry()
                    zip.putNextEntry(ZipEntry("NIU_FX_STUDIO_BACKUP_INFO.txt"))
                    zip.write(("NIU Mobility Studio 1.0.7\nCreated: ${System.currentTimeMillis()}\nSource: currently opened document only\n").toByteArray())
                    zip.closeEntry()
                }
                editorStatus = "Резервная копия текущего файла создана"
                addLog("WORKSPACE: ZIP backup exported")
            }.onFailure { editorStatus = "Ошибка backup: ${it.message}"; addLog("WORKSPACE backup error: ${it.message}") }
        }
    }

    private val importSourceProject = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runCatching {
            val target = File(filesDir, "niu-workspace").apply { mkdirs() }
            var files = 0
            var totalBytes = 0L
            contentResolver.openInputStream(uri)?.use { input ->
                java.util.zip.ZipInputStream(input).use { zip ->
                    while (true) {
                        val entry = zip.nextEntry ?: break
                        if (!entry.isDirectory) {
                            val name = entry.name.replace('\\', '/')
                            require(!name.startsWith('/') && name.split('/').none { it == ".." || it.isBlank() }) { "Недопустимый путь в ZIP" }
                            val out = File(target, name)
                            require(out.canonicalPath.startsWith(target.canonicalPath + File.separator)) { "Выход за пределы workspace" }
                            out.parentFile?.mkdirs()
                            out.outputStream().use { output ->
                                val buffer = ByteArray(8192)
                                while (true) {
                                    val count = zip.read(buffer)
                                    if (count < 0) break
                                    totalBytes += count
                                    require(totalBytes <= 80L * 1024L * 1024L) { "Архив превышает лимит 80 МБ" }
                                    output.write(buffer, 0, count)
                                }
                            }
                            files++
                            require(files <= 5000) { "Слишком много файлов в архиве" }
                        }
                        zip.closeEntry()
                    }
                }
            } ?: error("Не удалось прочитать ZIP")
            // Archives exported by Android Studio commonly contain one wrapper directory.
            // Flatten NIU_Mobility_Studio so Gradle files and the CI workflow land at workspace root.
            val wrappedRoot = File(target, "NIU_Mobility_Studio")
            if (File(wrappedRoot, "settings.gradle.kts").isFile) {
                wrappedRoot.listFiles()?.forEach { source ->
                    val destination = File(target, source.name)
                    if (destination.exists()) destination.deleteRecursively()
                    if (!source.renameTo(destination)) {
                        if (source.isDirectory) source.copyRecursively(destination, overwrite = true)
                        else source.copyTo(destination, overwrite = true)
                        source.deleteRecursively()
                    }
                }
                wrappedRoot.deleteRecursively()
            }
            addLog("IDE: импортирован исходный проект · файлов $files · ${totalBytes / 1024} КБ")
            editorStatus = "Импортировано файлов: $files. Обновите дерево проекта."
        }.onFailure { editorStatus = "Ошибка импорта проекта: ${it.message}"; addLog("IDE import error: ${it.message}") }
    }

    private val exportSourceProject = registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) runCatching {
            val root = File(filesDir, "niu-workspace")
            val output = contentResolver.openOutputStream(uri) ?: error("Не удалось создать ZIP")
            var count = 0
            ZipOutputStream(output).use { zip ->
                root.walkTopDown().filter { it.isFile }.forEach { file ->
                    val relative = file.relativeTo(root).invariantSeparatorsPath
                    require(!relative.startsWith("../")) { "Недопустимый путь" }
                    zip.putNextEntry(ZipEntry(relative))
                    file.inputStream().use { it.copyTo(zip) }
                    zip.closeEntry(); count++
                }
                zip.putNextEntry(ZipEntry("NIU_FX_STUDIO_EXPORT_INFO.txt"))
                zip.write("NIU Mobility Studio 1.0.7 source workspace export\nFiles: $count\n".toByteArray())
                zip.closeEntry()
            }
            editorStatus = "Экспортирован исходный проект: $count файлов"
            addLog("IDE: source project ZIP exported · $count files")
        }.onFailure { editorStatus = "Ошибка экспорта: ${it.message}"; addLog("IDE export error: ${it.message}") }
    }

    private val openReferenceFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                val text = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                importReferenceText(text, uri.lastPathSegment ?: "reference.txt")
            } catch (e: Exception) { addLog("Ошибка импорта эталона: ${e.message}") }
        }
    }

    private val createTextFile = registerForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) {
            try {
                contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(pendingExportText) }
                addLog("TXT-файл сохранён")
            } catch (e: Exception) { addLog("Ошибка сохранения TXT: ${e.message}") }
        } else addLog("Сохранение TXT отменено")
    }

    private val openWallpaper = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            runCatching {
                val bitmap = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                if (bitmap != null) {
                    wallpaperUri = uri
                    wallpaperBitmap = bitmap
                    wallpaperSaved = false
                    addLog("DISPLAY: изображение выбрано локально · ${bitmap.width}x${bitmap.height}; передача на приборку пока не активирована")
                } else addLog("DISPLAY: не удалось декодировать изображение")
            }.onFailure { addLog("DISPLAY image error: ${it.message}") }
        }
    }

    private val openMusic = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            musicUris.clear()
            uris.forEach { uri ->
                runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                musicUris.add(uri)
            }
            musicIndex = 0
            musicUri = musicUris.first()
            musicTitle = musicUri?.lastPathSegment?.substringAfterLast('/')?.take(48) ?: "Выбранный аудиофайл"
            prepareAudio(musicUri!!, start = false, isMusic = true)
            addLog("MUSIC: выбрано треков: ${musicUris.size} · Android media audio route")
        }
    }

    private val openSound = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            val mime = contentResolver.getType(uri).orEmpty()
            if (mime.startsWith("video/")) {
                soundTitle = "Извлечение аудио из видео…"
                Thread {
                    val extracted = extractAudioFromVideo(uri)
                    runOnUiThread {
                        if (extracted != null) {
                            soundUri = extracted
                            soundTitle = "Аудио из видео · ${uri.lastPathSegment?.takeLast(30) ?: "видеофайл"}"
                            prepareAudio(extracted, start = false)
                            addLog("SOUND: аудиодорожка извлечена из видео и готова к предпрослушиванию")
                        } else {
                            soundTitle = "Не удалось извлечь аудиодорожку"
                            addLog("SOUND: в видео не найдена совместимая аудиодорожка")
                        }
                    }
                }.start()
            } else {
                soundUri = uri
                soundTitle = uri.lastPathSegment?.substringAfterLast('/')?.take(48) ?: "Собственный звук"
                prepareAudio(uri, start = false)
                addLog("SOUND: аудиофайл выбран для локального предпрослушивания; загрузка в скутер пока не реализована")
            }
        }
    }

    private fun extractAudioFromVideo(source: Uri): Uri? {
        val extractor = MediaExtractor()
        var muxer: MediaMuxer? = null
        var output: File? = null
        return try {
            extractor.setDataSource(this, source, null)
            val audioIndex = (0 until extractor.trackCount).firstOrNull { index ->
                extractor.getTrackFormat(index).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true
            } ?: return null
            extractor.selectTrack(audioIndex)
            val format = extractor.getTrackFormat(audioIndex)
            val outputFile = File(filesDir, "fx_sound_${System.currentTimeMillis()}.m4a")
            output = outputFile
            val currentMuxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            muxer = currentMuxer
            val outputTrack = currentMuxer.addTrack(format)
            currentMuxer.start()
            val buffer = ByteBuffer.allocate(1024 * 1024)
            val info = MediaCodec.BufferInfo()
            while (true) {
                buffer.clear()
                val size = extractor.readSampleData(buffer, 0)
                if (size < 0) break
                info.offset = 0
                info.size = size
                info.presentationTimeUs = extractor.sampleTime
                info.flags = extractor.sampleFlags
                currentMuxer.writeSampleData(outputTrack, buffer, info)
                extractor.advance()
            }
            currentMuxer.stop()
            Uri.fromFile(outputFile)
        } catch (_: Exception) {
            output?.delete()
            null
        } finally {
            runCatching { extractor.release() }
            runCatching { muxer?.release() }
        }
    }

    private fun prepareAudio(uri: Uri, start: Boolean, isMusic: Boolean = false) {
        musicPlaying = false
        runCatching {
            mediaPlayer?.release()
            mediaPlayer = null
            loadedAudioUri = null
            val player = MediaPlayer()
            player.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            player.setDataSource(this, uri)
            player.setVolume(musicVolume, musicVolume)
            player.setOnCompletionListener {
                if (loadedAudioIsMusic && musicUris.size > 1) playMusicAt((musicIndex + 1) % musicUris.size, start = true)
                else musicPlaying = false
            }
            player.setOnErrorListener { _, what, extra -> musicPlaying = false; addLog("AUDIO playback error · $what/$extra"); true }
            player.prepare()
            mediaPlayer = player
            loadedAudioUri = uri
            loadedAudioIsMusic = isMusic
            if (start) { player.start(); musicPlaying = true }
        }.onFailure { musicPlaying = false; addLog("AUDIO prepare error: ${it.message}") }
    }

    private fun toggleMusicPlayback() {
        val player = mediaPlayer
        val selectedMusic = musicUri ?: run { addLog("MUSIC: сначала выберите аудиофайл"); return }
        if (player == null || loadedAudioUri != selectedMusic) {
            prepareAudio(selectedMusic, start = true, isMusic = true)
            return
        }
        runCatching {
            if (player.isPlaying) { player.pause(); musicPlaying = false }
            else { player.start(); musicPlaying = true }
        }.onFailure { addLog("MUSIC control error: ${it.message}") }
    }

    private fun playMusicAt(index: Int, start: Boolean) {
        if (musicUris.isEmpty()) return
        musicIndex = ((index % musicUris.size) + musicUris.size) % musicUris.size
        musicUri = musicUris[musicIndex]
        musicTitle = musicUri?.lastPathSegment?.substringAfterLast('/')?.take(48) ?: "Трек ${musicIndex + 1}"
        musicUri?.let { prepareAudio(it, start = start, isMusic = true) }
    }

    private fun nextMusic() { if (musicUris.isNotEmpty()) playMusicAt(musicIndex + 1, start = true) }
    private fun previousMusic() { if (musicUris.isNotEmpty()) playMusicAt(musicIndex - 1, start = true) }

    private fun refreshAudioOutputs() {
        val audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        val outputs = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS).filter { it.isSink }
        val rows = outputs.map { device ->
            val kind = when (device.type) {
                android.media.AudioDeviceInfo.TYPE_BLUETOOTH_A2DP -> "Bluetooth A2DP"
                android.media.AudioDeviceInfo.TYPE_BLE_HEADSET -> "Bluetooth LE Audio headset"
                android.media.AudioDeviceInfo.TYPE_BLE_SPEAKER -> "Bluetooth LE Audio speaker"
                android.media.AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> "Динамик телефона"
                android.media.AudioDeviceInfo.TYPE_WIRED_HEADPHONES, android.media.AudioDeviceInfo.TYPE_WIRED_HEADSET -> "Проводные наушники"
                else -> "Audio type ${device.type}"
            }
            "$kind · ${device.productName}"
        }
        audioOutputSummary = rows.joinToString("\n").ifBlank { "Android не сообщил активные аудиовыходы" }
        addLog("AUDIO OUTPUTS: ${rows.joinToString("; ").ifBlank { "none" }}")
    }

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        if (result.values.all { it }) {
            if (findMode) startFindScan() else startScan()
        } else addLog("Не выданы разрешения Bluetooth")
    }

    override fun onTagDiscovered(tag: Tag) {
        val techs = tag.techList.map { it.substringAfterLast('.') }.distinct()
        var ndefState = "NDEF: отсутствует или недоступен"
        var recordLines = mutableListOf<String>()
        var capacity = "неизвестна"
        var writable = "неизвестно"
        try {
            val ndef = Ndef.get(tag)
            if (ndef != null) {
                ndef.connect()
                capacity = "${ndef.maxSize} bytes"
                writable = if (ndef.isWritable) "да" else "нет"
                val message = ndef.cachedNdefMessage
                if (message != null) {
                    ndefState = "NDEF: ${message.records.size} record(s)"
                    message.records.forEachIndexed { index, record ->
                        val type = runCatching { String(record.type, Charsets.UTF_8).ifBlank { "(empty)" } }.getOrDefault("(binary)")
                        // Store record metadata only. Do not export UID, raw payload, keys or access tokens.
                        recordLines.add("Record[$index]: TNF=${record.tnf}, TYPE=$type, PAYLOAD_LENGTH=${record.payload.size} bytes")
                    }
                } else ndefState = "NDEF: пустая карта"
                ndef.close()
            }
        } catch (e: Exception) {
            ndefState = "NDEF read error: ${e.javaClass.simpleName}"
        }
        val report = buildString {
            appendLine("NIU Mobility Studio · NFC CARD INSPECTION")
            appendLine("Time: ${java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US).format(java.util.Date())}")
            appendLine("Technologies: ${techs.joinToString().ifBlank { "unknown" }}")
            appendLine(ndefState)
            appendLine("Capacity: $capacity")
            appendLine("Writable: $writable")
            recordLines.forEach { appendLine(it) }
            appendLine("\nSecurity: UID, secure-sector contents, cryptographic keys and access credentials are intentionally not extracted or stored.")
            appendLine("This is a read-only technical inspection, not a cloned or reusable access credential.")
        }
        runOnUiThread {
            nfcStatus = if (ndefState.startsWith("NDEF: ")) "Карта обнаружена · ${techs.firstOrNull() ?: "NFC"}" else "Карта обнаружена · требуется проверка"
            nfcReport = report
            nfcLastReadAt = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())
            addLog("NFC tag detected · ${techs.joinToString()} · UID/секреты не сохранялись")
        }
    }

    @Suppress("DEPRECATION")
    override fun onResume() {
        super.onResume()
        try {
            nfcAdapter?.enableReaderMode(this, this,
                NfcAdapter.FLAG_READER_NFC_A or NfcAdapter.FLAG_READER_NFC_B or
                    NfcAdapter.FLAG_READER_NFC_F or NfcAdapter.FLAG_READER_NFC_V,
                null)
            if (nfcAdapter == null) nfcStatus = "На телефоне нет NFC"
        } catch (e: Exception) { nfcStatus = "Не удалось включить NFC: ${e.message}" }
    }

    override fun onPause() {
        try { nfcAdapter?.disableReaderMode(this) } catch (_: Exception) {}
        super.onPause()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        persistentLoggingEnabled = getSharedPreferences("niu_diagnostics", MODE_PRIVATE).getBoolean("persistent_logging", true)
        getSharedPreferences("niu_cloud_logs", MODE_PRIVATE).edit().clear().apply()
        SecureSecretStore(getSharedPreferences("niu_secure_secrets", MODE_PRIVATE)).remove("cloud_log_credential")
        restoreEventLog()
        niuCloudVerboseTrace = getSharedPreferences("niu_cloud", MODE_PRIVATE).getBoolean("verbose_trace", false)
        addLog("APP START · version=${BuildConfig.VERSION_NAME} · Android ${Build.VERSION.SDK_INT} · cloudTrace=$niuCloudVerboseTrace")
        val previousHandler = Thread.getDefaultUncaughtExceptionHandler()
        getSharedPreferences("niu_crash_log", MODE_PRIVATE).getString("last_crash", null)?.let { crash ->
            addLog("PREVIOUS FATAL CRASH\n$crash")
        }
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            val details = buildString {
                append("FATAL ${thread.name}: ${error.javaClass.name}: ${error.message}\n")
                error.stackTrace.take(80).forEach { append("  at $it\n") }
                error.cause?.let { append("Caused by: ${it.javaClass.name}: ${it.message}\n") }
            }
            getSharedPreferences("niu_crash_log", MODE_PRIVATE).edit()
                .putString("last_crash", redactLogSecrets(details)).putLong("last_crash_at", System.currentTimeMillis()).apply()
            previousHandler?.uncaughtException(thread, error)
        }
        AppAppearance.selected = getSharedPreferences("app_appearance", MODE_PRIVATE).getString("theme", "CURRENT") ?: "CURRENT"
        val prefs = getSharedPreferences("fx_display", MODE_PRIVATE)
        wallpaperAccent = prefs.getInt("accent", 0).coerceIn(0, 5)
        wallpaperZoom = prefs.getFloat("zoom", 1f).coerceIn(1f, 2.5f)
        val soundPrefs = getSharedPreferences("fx_sound", MODE_PRIVATE)
        soundTheme = soundPrefs.getString("theme", "Вариант 1") ?: "Вариант 1"
        soundEvent = soundPrefs.getString("event", "ALARM") ?: "ALARM"
        soundTrigger = soundPrefs.getString("trigger", "ONCE") ?: "ONCE"
        soundPrefs.getString("custom_uri", null)?.let { saved -> soundUri = Uri.parse(saved); soundTitle = "Сохранённый аудиофайл" }
        prefs.getString("wallpaper_uri", null)?.let { saved ->
            runCatching {
                val uri = Uri.parse(saved)
                val bitmap = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                if (bitmap != null) { wallpaperUri = uri; wallpaperBitmap = bitmap; wallpaperSaved = true }
            }
        }
        restoreSavedVehicles()
        niuCloudRegion = getSharedPreferences("niu_cloud", MODE_PRIVATE).getString("region", "CHINA") ?: "CHINA"
        if (!SecureSecretStore(getSharedPreferences("niu_secure_secrets", MODE_PRIVATE)).get("niu_cloud_session_token").isNullOrBlank()) {
            niuCloudStatus = "Сессия сохранена · нажмите NIU Cloud для синхронизации"
        }
        setContent { FxApp() }
    }

    private fun restoreSavedVehicles() {
        runCatching {
            val raw = getSharedPreferences("niu_saved_vehicles", MODE_PRIVATE).getString("vehicles", "[]") ?: "[]"
            val array = org.json.JSONArray(raw)
            for (i in 0 until array.length()) {
                val o = array.getJSONObject(i)
                val sn = o.optString("serial").trim()
                if (sn.isNotBlank()) savedVehicles.add(SavedNiuVehicle(
                    serial = sn, name = o.optString("name", "NIU $sn"), familyId = o.optString("familyId", "other"),
                    model = o.optString("model", "Неизвестная модель"), vin = o.optString("vin"),
                    bleAddress = o.optString("bleAddress"), cloudLinked = o.optBoolean("cloudLinked")
                ))
            }
            activeVehicleSerial = getSharedPreferences("niu_saved_vehicles", MODE_PRIVATE).getString("active", "") ?: ""
        }.onFailure { addLog("VEHICLE STORE restore error: ${it.message}") }
    }

    private fun persistSavedVehicles() {
        val array = org.json.JSONArray()
        savedVehicles.forEach { v -> array.put(org.json.JSONObject().put("serial", v.serial).put("name", v.name)
            .put("familyId", v.familyId).put("model", v.model).put("vin", v.vin)
            .put("bleAddress", v.bleAddress).put("cloudLinked", v.cloudLinked)) }
        getSharedPreferences("niu_saved_vehicles", MODE_PRIVATE).edit()
            .putString("vehicles", array.toString()).putString("active", activeVehicleSerial).apply()
    }

    private fun saveVehicle(serialRaw: String, nameRaw: String, vin: String = "", address: String = "", family: String = selectedNiuFamily, model: String = selectedNiuModel, cloud: Boolean = false) {
        val serial = serialRaw.trim().uppercase()
        require(serial.length in 6..32 && serial.all { it.isLetterOrDigit() || it == '-' }) { "Серийный номер должен содержать 6–32 буквы/цифры" }
        val old = savedVehicles.indexOfFirst { it.serial.equals(serial, true) }
        val previous: SavedNiuVehicle? = if (old >= 0) savedVehicles[old] else null
        val vehicle = SavedNiuVehicle(serial, nameRaw.trim().ifBlank { previous?.name ?: "$model · ${serial.takeLast(4)}" },
            family.ifBlank { previous?.familyId ?: "other" }, model.ifBlank { previous?.model ?: "Неизвестная модель" },
            vin.ifBlank { previous?.vin.orEmpty() }, address.ifBlank { previous?.bleAddress.orEmpty() }, cloud || previous?.cloudLinked == true)
        if (old >= 0) savedVehicles[old] = vehicle else savedVehicles.add(vehicle)
        activeVehicleSerial = serial
        selectedNiuFamily = vehicle.familyId
        selectedNiuModel = vehicle.model
        persistSavedVehicles()
        val maskedSn = if (vehicle.serial.length > 6) "${vehicle.serial.take(3)}••••${vehicle.serial.takeLast(3)}" else "••••"
        addLog("VEHICLE saved · ${vehicle.name} · SN=$maskedSn · BLE=${vehicle.bleAddress.ifBlank { "not linked" }}")
    }


    /** Keep a user-confirmed local family when Cloud's generic type label conflicts.
     * Server metadata is retained for diagnostics; it must not silently overwrite a manually selected FX profile. */
    private fun resolveCloudFamily(vehicle: NiuCloudClient.Vehicle): Pair<String, String> {
        val existing = savedVehicles.firstOrNull { it.serial.equals(vehicle.serial, true) }
        val serverText = vehicle.serverIdentityText()
        // Prefer product/type identifiers over generic display type and never classify by owner nickname.
        val prioritizedServerFields = listOf(vehicle.productType, vehicle.vehicleTypeId, vehicle.specialEdition, vehicle.model, vehicle.brand)
        val detected = prioritizedServerFields.firstNotNullOfOrNull { field ->
            field.takeIf { it.isNotBlank() }?.let(NiuModelCatalog::detect)
        }
        val hasSpecificFxMarker = listOf(vehicle.productType, vehicle.vehicleTypeId, vehicle.specialEdition)
            .any { it.contains("fx", true) || it.contains("风速", true) }
        val preserveFx = existing?.familyId == "fx" && detected?.id != "fx" && !hasSpecificFxMarker
        val family = if (preserveFx) "fx" else detected?.id ?: existing?.familyId ?: "other"
        val model = when {
            preserveFx -> existing?.model ?: "FX"
            detected?.id == "fx" -> vehicle.productType.ifBlank { vehicle.model.ifBlank { "FX" } }
            vehicle.model.isNotBlank() -> vehicle.model
            else -> existing?.model ?: "NIU"
        }
        addLog("NIU CLOUD identity · serial=${vehicle.serial.take(3)}••••${vehicle.serial.takeLast(3)} · serverFields=${serverText.take(100)} · selected=$family · preservedManualFx=$preserveFx · VIN=${if (vehicle.vin.isNotBlank()) "present" else "missing"}")
        return family to model
    }

    private fun parseNiuSerialFromQr(raw: String): String? {
        val text = raw.trim()
        val explicit = Regex("(?i)(?:SN|S/N|SERIAL(?:\\s*NUMBER)?)[\\s:=_-]*([A-Z0-9-]{6,32})").find(text)?.groupValues?.get(1)
        if (explicit != null) return explicit.uppercase()
        val json = runCatching { org.json.JSONObject(text).optString("sn").takeIf { it.isNotBlank() } }.getOrNull()
        if (json != null) return json.uppercase()
        return Regex("(?<![A-Z0-9])([A-Z0-9]{10,24})(?![A-Z0-9])").find(text.uppercase())?.groupValues?.get(1)
    }

    private fun scanVehicleQr() {
        runCatching {
            GmsBarcodeScanning.getClient(this).startScan()
                .addOnSuccessListener { barcode ->
                    val raw = barcode.rawValue.orEmpty()
                    val serial = parseNiuSerialFromQr(raw)
                    if (serial == null) {
                        vehicleEditorMessage = "QR считан, но серийный номер не распознан. Проверьте наклейку или введите SN вручную."
                        addLog("QR: barcode read but SN not recognized")
                    } else {
                        vehicleSerialInput = serial
                        vehicleEditorMessage = "SN распознан. Укажите название и сохраните устройство."
                        addLog("QR: NIU serial extracted · ${serial.take(3)}••••${serial.takeLast(3)}")
                    }
                }
                .addOnFailureListener { error ->
                    val detail = error.message?.take(180) ?: error.javaClass.simpleName
                    vehicleEditorMessage = "Сканирование QR не удалось ($detail). Проверьте Google Play Services и введите серийный номер вручную."
                    addLog("QR scanner error: ${error.javaClass.simpleName}: $detail · manual serial entry remains available")
                }
        }.onFailure { vehicleEditorMessage = "Не удалось запустить сканер: ${it.message}"; addLog("QR start error: ${it.message}") }
    }

    private fun loginNiuCloud() {
        val account = niuCloudAccount.trim()
        val password = niuCloudPassword.toCharArray()
        if (account.isBlank() || password.isEmpty()) { niuCloudStatus = "Введите логин и пароль"; return }
        niuCloudStatus = "Выполняется вход в NIU Cloud…"
        val selectedRegion = niuCloudRegion
        val captureCloudDetails = niuCloudVerboseTrace
        addLog("NIU CLOUD · AUTH FLOW BEGIN · region=$selectedRegion · accountType=${if (account.contains('@')) "email" else "username-or-phone"} · accountLength=${account.length} · credentials=not-logged · diagnosticMode=$captureCloudDetails")
        Thread {
            var authenticated = false
            try {
                val region = if (selectedRegion == "CHINA") NiuCloudClient.Region.CHINA else NiuCloudClient.Region.GLOBAL
                val client = NiuCloudClient(region, trace = { event -> runOnUiThread { addLog("NIU CLOUD · $event") } }, captureResponseDetails = captureCloudDetails)
                val token = client.login(account, password)
                authenticated = true
                val secretStore = SecureSecretStore(getSharedPreferences("niu_secure_secrets", MODE_PRIVATE))
                secretStore.put("niu_cloud_session_token", token)
                val vehicles = client.listVehicles(token)
                getSharedPreferences("niu_cloud", MODE_PRIVATE).edit().putString("region", niuCloudRegion).apply()
                runOnUiThread {
                    niuCloudVehicles.clear(); niuCloudVehicles.addAll(vehicles)
                    vehicles.forEach { v ->
                        val (family, model) = resolveCloudFamily(v)
                        runCatching { saveVehicle(v.serial, v.name, v.vin, family = family, model = model, cloud = true) }
                    }
                    niuCloudPassword = ""
                    niuCloudStatus = "Вход выполнен · устройств: ${vehicles.size}"
                    addLog("NIU CLOUD · AUTH FLOW COMPLETE · result=success · vehicleCount=${vehicles.size} · tokenStored=encrypted · passwordStored=false")
                }
            } catch (e: Exception) {
                runOnUiThread {
                    val outdatedClient = e.message.orEmpty().contains("too outdated", true) || e.message.orEmpty().contains("version", true) && e.message.orEmpty().contains("outdated", true)
                    niuCloudStatus = when {
                        authenticated -> "Авторизация выполнена, но список устройств недоступен: ${e.message}"
                        outdatedClient -> "NIU Cloud отклонил версию клиента. Это ограничение на стороне сервера; проверьте обновление официального NIU app/API. Повторный ввод пароля не поможет."
                        else -> "Ошибка входа: ${e.message}"
                    }
                    addLog("NIU CLOUD · AUTH FLOW FAILED · stage=${if (authenticated) "vehicle-list" else "login"} · exception=${e.javaClass.name} · message=${e.message}")
                    var cause = e.cause
                    var depth = 0
                    while (cause != null && depth < 4) { addLog("NIU CLOUD · CAUSE[$depth] · ${cause.javaClass.name}: ${cause.message}"); cause = cause.cause; depth++ }
                    e.stackTrace.take(20).forEach { addLog("NIU CLOUD · STACK · $it") }
                }
            } finally {
                password.fill('\u0000')
                runOnUiThread { niuCloudPassword = "" }
            }
        }.start()
    }

    private fun refreshNiuCloudVehicles() {
        val token = SecureSecretStore(getSharedPreferences("niu_secure_secrets", MODE_PRIVATE)).get("niu_cloud_session_token")
        if (token.isNullOrBlank()) { niuCloudStatus = "Сначала войдите в NIU Cloud"; showNiuCloudLogin = true; return }
        niuCloudStatus = "Обновляем список NIU Cloud…"
        val captureCloudDetails = niuCloudVerboseTrace
        addLog("NIU CLOUD · vehicle refresh requested")
        Thread {
            try {
                val savedRegion = getSharedPreferences("niu_cloud", MODE_PRIVATE).getString("region", niuCloudRegion) ?: niuCloudRegion
                val region = if (savedRegion == "CHINA") NiuCloudClient.Region.CHINA else NiuCloudClient.Region.GLOBAL
                val vehicles = NiuCloudClient(region, trace = { event -> runOnUiThread { addLog("NIU CLOUD · $event") } }, captureResponseDetails = captureCloudDetails).listVehicles(token)
                runOnUiThread {
                    niuCloudVehicles.clear(); niuCloudVehicles.addAll(vehicles)
                    vehicles.forEach { v -> val (family, model) = resolveCloudFamily(v); runCatching { saveVehicle(v.serial, v.name, v.vin, family = family, model = model, cloud = true) } }
                    niuCloudStatus = "Синхронизировано · ${vehicles.size} устройств"
                }
            } catch (e: Exception) { runOnUiThread {
                niuCloudStatus = "Ошибка обновления: ${e.message}"
                addLog("NIU CLOUD refresh failed: ${e.javaClass.simpleName}: ${e.message}")
                e.stackTrace.take(16).forEach { addLog("NIU CLOUD STACK · $it") }
            } }
        }.start()
    }

    private fun refreshNiuCloudTelemetry() {
        val serial = activeVehicleSerial.trim()
        if (serial.isBlank()) {
            niuCloudTelemetryStatus = "Сначала выберите скутер"
            return
        }
        val token = SecureSecretStore(getSharedPreferences("niu_secure_secrets", MODE_PRIVATE)).get("niu_cloud_session_token")
        if (token.isNullOrBlank()) {
            niuCloudTelemetryStatus = "Нет активной NIU Cloud-сессии"
            showNiuCloudLogin = true
            return
        }
        if (niuCloudTelemetryLoading) return
        niuCloudTelemetryLoading = true
        niuCloudTelemetryStatus = "Запрашиваем телеметрию Cloud…"
        addLog("NIU CLOUD TELEMETRY · START · sn=${serial.take(3)}***")
        Thread {
            try {
                val savedRegion = getSharedPreferences("niu_cloud", MODE_PRIVATE).getString("region", niuCloudRegion) ?: niuCloudRegion
                val region = if (savedRegion == "CHINA") NiuCloudClient.Region.CHINA else NiuCloudClient.Region.GLOBAL
                val snapshot = NiuCloudClient(region, trace = { event -> runOnUiThread { addLog("NIU CLOUD · $event") } }).fetchTelemetry(token, serial)
                runOnUiThread {
                    niuCloudTelemetry = snapshot
                    val available = listOfNotNull(
                        snapshot.vehicleConnected,
                        snapshot.speedKmh,
                        snapshot.estimatedRangeKm,
                        snapshot.totalMileageKm,
                        snapshot.controllerBatteryPercent
                    ).size + snapshot.batteries.sumOf { listOfNotNull(it.chargePercent, it.temperatureC).size }
                    niuCloudTelemetryStatus = if (available > 0) "Получено полей: $available · батарей: ${snapshot.batteries.size}" else "Cloud ответил, но полезные поля отсутствуют"
                    addLog("NIU CLOUD TELEMETRY · COMPLETE · fields=$available · batteries=${snapshot.batteries.size} · endpointStates=${snapshot.sourceStates}")
                    snapshot.warnings.forEach { addLog("NIU CLOUD TELEMETRY · WARN · $it") }
                    niuCloudTelemetryLoading = false
                }
            } catch (e: Exception) {
                runOnUiThread {
                    niuCloudTelemetryStatus = "Ошибка телеметрии: ${e.message ?: e.javaClass.simpleName}"
                    addLog("NIU CLOUD TELEMETRY · ERROR · ${e.javaClass.simpleName}: ${e.message}")
                    niuCloudTelemetryLoading = false
                }
            }
        }.start()
    }

    private fun logoutNiuCloud() {
        SecureSecretStore(getSharedPreferences("niu_secure_secrets", MODE_PRIVATE)).remove("niu_cloud_session_token")
        niuCloudVehicles.clear(); niuCloudStatus = "Сеанс удалён с устройства"
        addLog("NIU CLOUD: local session token removed")
    }

    private fun requiredPermissions(): Array<String> = if (Build.VERSION.SDK_INT >= 31)
        arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
    else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)

    private fun hasPermissions() = requiredPermissions().all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }
    private fun ensurePermissions() { if (hasPermissions()) startScan() else permissionLauncher.launch(requiredPermissions()) }
    private fun requestFind() {
        findMode = true
        findRssi = null
        findStatus = "Ищем NIU Link рядом…"
        if (hasPermissions()) startFindScan() else permissionLauncher.launch(requiredPermissions())
    }
    @Suppress("MissingPermission")
    private fun startFindScan(retry: Boolean = false) {
        val a = adapter ?: run { findStatus = "Bluetooth недоступен"; addLog(findStatus); return }
        if (!a.isEnabled) { findStatus = "Включите Bluetooth телефона"; addLog(findStatus); return }
        if (!retry) bleScanRetryUsed = false
        stopScan()
        devices.clear(); signalByAddress.clear(); scanning = true
        findStatus = "Сканирование BLE · 20 секунд"
        addLog("FIND scan started · target NIU Link / ${knownNiuAddresses.joinToString()}")
        mainHandler.removeCallbacks(findTimeout)
        mainHandler.postDelayed(findTimeout, 20000L)
        try {
            val scanner = a.bluetoothLeScanner ?: run { scanning = false; findStatus = "BLE Scanner недоступен"; addLog(findStatus); return }
            scanner.startScan(scanCallback)
        } catch (e: SecurityException) { scanning = false; findStatus = "Нет разрешения Bluetooth"; addLog("FIND permission error: ${e.message}") }
        catch (e: Exception) { scanning = false; findStatus = "Ошибка BLE: ${e.message}"; addLog(findStatus) }
    }
    private val diagnosticLock = Any()
    private val diagnosticMaxBytes = 2L * 1024L * 1024L
    private val diagnosticMaxFiles = 4

    /** Structured, secret-redacted JSONL diagnostics with bounded rotating storage. */
    private fun addLog(s: String) {
        val now = System.currentTimeMillis()
        val stamp = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", java.util.Locale.US).format(java.util.Date(now))
        val safe = redactLogSecrets(s).take(12000)
        val upper = safe.uppercase(java.util.Locale.ROOT)
        val level = when {
            listOf("FATAL", "CRASH", "EXCEPTION", " ERROR", "ERROR:", "FAILED", "FAILURE", "ОШИБКА").any { upper.contains(it) } -> "ERROR"
            listOf("WARN", "TIMEOUT", "ОТКАЗ", "НЕ УДАЛОСЬ").any { upper.contains(it) } -> "WARN"
            else -> "INFO"
        }
        val category = when {
            upper.contains("TELEGRAM") || upper.contains("LOCAL API") -> "INTEGRATION"
            upper.contains("NIU CLOUD") || upper.contains("CLOUD") -> "NIU_CLOUD"
            upper.contains("GATT") || upper.contains("BLE") || upper.contains("BLUETOOTH") -> "BLE"
            upper.contains("NFC") -> "NFC"
            upper.contains("WORKSPACE") || upper.contains("IDE") || upper.contains("GITHUB") -> "WORKSPACE"
            upper.contains("AUDIO") || upper.contains("MUSIC") || upper.contains("SOUND") -> "MEDIA"
            upper.contains("QR") || upper.contains("VEHICLE") || upper.contains("СКУТЕР") -> "VEHICLE"
            else -> "APP"
        }
        val line = "$stamp  [$level][$category] $safe"
        logs.add(0, line)
        if (logs.size > 2500) logs.removeAt(logs.lastIndex)
        if (persistentLoggingEnabled) runCatching {
            val record = org.json.JSONObject()
                .put("timestamp", now).put("timestamp_iso", stamp)
                .put("level", level).put("category", category)
                .put("message", safe)
                .put("app_version", BuildConfig.VERSION_NAME)
                .put("android_sdk", Build.VERSION.SDK_INT)
            synchronized(diagnosticLock) {
                val dir = java.io.File(filesDir, "diagnostics").apply { mkdirs() }
                val active = java.io.File(dir, "events.jsonl")
                if (active.exists() && active.length() + record.toString().toByteArray(Charsets.UTF_8).size + 1 > diagnosticMaxBytes) {
                    for (i in diagnosticMaxFiles - 1 downTo 1) {
                        val from = java.io.File(dir, "events.jsonl.$i")
                        val to = java.io.File(dir, "events.jsonl.${i + 1}")
                        if (from.exists()) { if (to.exists()) to.delete(); from.renameTo(to) }
                    }
                    val first = java.io.File(dir, "events.jsonl.1")
                    if (first.exists()) first.delete()
                    active.renameTo(first)
                }
                active.appendText(record.toString() + "\n", Charsets.UTF_8)
            }
        }.onFailure { android.util.Log.e("NIU-Mobility", "Could not persist diagnostic event", it) }
        if (level == "ERROR") dispatchAutoAiError(safe)
    }

    /** Opt-in only; rate-limited to one automatic AI analysis per 60 seconds. */
    private fun dispatchAutoAiError(errorLine: String) {
        val config = getSharedPreferences("niu_telegram_config", MODE_PRIVATE)
        if (!config.getBoolean("auto_ai_on_errors", false)) return
        val now = System.currentTimeMillis()
        val previous = config.getLong("last_auto_ai_error_ms", 0L)
        if (now - previous < 60_000L) return
        config.edit().putLong("last_auto_ai_error_ms", now).apply()
        Thread({
            runCatching {
                val secrets = SecureSecretStore(getSharedPreferences("niu_secure_secrets", MODE_PRIVATE))
                val profile = config.getString("active_bot_profile", "Основной") ?: "Основной"
                val profileSecret = "telegram_bot_" + Integer.toHexString(profile.trim().ifBlank { "Основной" }.lowercase().hashCode())
                val botToken = secrets.get(profileSecret) ?: secrets.get("telegram_bot_token") ?: return@runCatching
                val chats = config.getString("allowed_chat_ids", "").orEmpty()
                    .split(',', ';', '\n').map { it.trim() }.filter { it.isNotBlank() }
                if (chats.isEmpty()) return@runCatching
                val endpoint = config.getString("ai_backend_url", "").orEmpty()
                if (!endpoint.startsWith("https://")) return@runCatching
                val backendToken = secrets.get("telegram_ai_backend_token")
                val context = synchronized(logs) { logs.toList().takeLast(50) }
                val analysis = com.niu.fxstudio.security.TelegramAiAssistant.respond(
                    endpoint, backendToken,
                    "Автоматически обнаружена ошибка приложения. Объясни вероятную причину и безопасные следующие шаги. Не утверждай, что исправление уже применено.\n$errorLine",
                    context
                )
                val bot = com.niu.fxstudio.security.TelegramBotClient(botToken)
                chats.forEach { chat -> bot.sendMessage(chat, "⚠️ NIU Mobility Studio: новая ошибка\n$errorLine\n\nAI-анализ:\n$analysis".take(3900)) }
            }.onFailure { android.util.Log.e("NIU-Mobility", "Automatic Telegram AI analysis failed", it) }
        }, "niu-auto-ai-error-analysis").apply { isDaemon = true; start() }
    }

    private fun redactLogSecrets(value: String): String =
        com.niu.fxstudio.security.DiagnosticLogRedactor.redact(value)


    private fun restoreEventLog() {
        runCatching {
            synchronized(diagnosticLock) {
                val dir = java.io.File(filesDir, "diagnostics")
                val files = (diagnosticMaxFiles downTo 1).map { java.io.File(dir, "events.jsonl.$it") } + java.io.File(dir, "events.jsonl")
                files.filter { it.exists() }.forEach { file ->
                    file.forEachLine(Charsets.UTF_8) { raw ->
                        runCatching {
                            val item = org.json.JSONObject(raw)
                            val stamp = item.optString("timestamp_iso", "")
                            val level = item.optString("level", "INFO")
                            val category = item.optString("category", "APP")
                            val message = item.optString("message", "")
                            if (message.isNotBlank()) logs.add("$stamp  [$level][$category] $message")
                        }
                    }
                }
            }
            // One-time migration from the previous SharedPreferences journal.
            if (logs.isEmpty()) {
                val legacy = getSharedPreferences("niu_event_log", MODE_PRIVATE).getString("entries", null)
                if (legacy != null) {
                    val saved = org.json.JSONArray(legacy)
                    for (index in 0 until minOf(saved.length(), 1500)) addLog("LEGACY IMPORT · ${saved.getString(index)}")
                    getSharedPreferences("niu_event_log", MODE_PRIVATE).edit().remove("entries").apply()
                }
            }
            logs.sortDescending()
            while (logs.size > 2500) logs.removeAt(logs.lastIndex)
        }.onFailure { logs.add("LOG RESTORE ERROR: ${it.message}") }
    }

    @Suppress("MissingPermission")
    private fun startScan(retry: Boolean = false) {
        val a = adapter ?: run { addLog("Bluetooth недоступен на этом устройстве"); return }
        if (!a.isEnabled) { addLog("Включите Bluetooth телефона"); return }
        // Android may still own the previous scanner callback briefly after stopScan().
        if (!retry) bleScanRetryUsed = false
        stopScan()
        devices.clear(); signalByAddress.clear(); scanning = true; addLog("Поиск BLE-устройств…")
        mainHandler.removeCallbacks(scanTimeout); mainHandler.postDelayed(scanTimeout, 12000L)
        try {
            val scanner = a.bluetoothLeScanner ?: run { scanning = false; addLog("BLE Scanner недоступен"); return }
            scanner.startScan(scanCallback)
        } catch (e: SecurityException) { scanning = false; addLog("Нет разрешения Bluetooth: ${e.message}") }
        catch (e: Exception) { scanning = false; addLog("Ошибка BLE scan: ${e.message}") }
    }

    private val scanCallback: ScanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val d = result.device
            runOnUiThread {
                if (devices.none { it.address == d.address }) devices.add(d)
                signalByAddress[d.address] = result.rssi
                val name = runCatching { d.name.orEmpty() }.getOrDefault("")
                val isTarget = knownNiuAddresses.any { d.address.equals(it, true) } || name.contains("NIU", true) || name.contains("LINK", true)
                if (findMode && isTarget) {
                    findRssi = result.rssi
                    val quality = when { result.rssi >= -55 -> "очень близко"; result.rssi >= -70 -> "рядом"; result.rssi >= -85 -> "слабый сигнал"; else -> "далеко / нестабильно" }
                    findStatus = "${if (name.isBlank()) "NIU Link" else name} · $quality"
                }
            }
        }
        override fun onScanFailed(errorCode: Int) {
            val reason = when (errorCode) {
                1 -> "SCAN_FAILED_ALREADY_STARTED — предыдущий BLE-сеанс ещё активен"
                2 -> "APPLICATION_REGISTRATION_FAILED — Android не зарегистрировал BLE scan"
                3 -> "INTERNAL_ERROR — внутренняя ошибка Bluetooth"
                4 -> "FEATURE_UNSUPPORTED — BLE scan не поддерживается"
                5 -> "OUT_OF_HARDWARE_RESOURCES — исчерпан ресурс BLE"
                6 -> "SCANNING_TOO_FREQUENTLY — слишком частые запуски сканирования"
                else -> "неизвестная ошибка BLE"
            }
            runOnUiThread {
                scanning = false
                addLog("BLE scan error $errorCode · $reason · bluetoothEnabled=${runCatching { adapter?.isEnabled == true }.getOrDefault(false)} · retryUsed=$bleScanRetryUsed")
                // Error 1 is commonly a short-lived race while Android releases a prior scan.
                // Retry once after stopping the callback; never loop on resource/permission errors.
                if (errorCode == ScanCallback.SCAN_FAILED_ALREADY_STARTED && !bleScanRetryUsed) {
                    bleScanRetryUsed = true
                    // Avoid runCatching type inference here: ScanCallback is an Activity
                    // property initialized with an anonymous object and Kotlin can recurse
                    // while inferring the generic Result type on some compiler versions.
                    try {
                        val recoveryScanner: android.bluetooth.le.BluetoothLeScanner? = adapter?.bluetoothLeScanner
                        if (recoveryScanner != null) {
                            recoveryScanner.stopScan(scanCallback)
                        }
                    } catch (stopError: SecurityException) {
                        addLog("BLE scan recovery · stopScan permission error: ${stopError.message}")
                    } catch (stopError: Exception) {
                        addLog("BLE scan recovery · stopScan error: ${stopError.message}")
                    }
                    addLog("BLE scan recovery · previous callback stop requested · retry scheduled in 700ms · attempt=1/1")
                    mainHandler.postDelayed({
                        if (!isFinishing && !isDestroyed && hasPermissions() && adapter?.isEnabled == true) {
                            if (findMode) startFindScan(retry = true) else startScan(retry = true)
                        } else {
                            scanning = false
                            addLog("BLE scan recovery cancelled · Bluetooth disabled, permission missing, or Activity closing")
                        }
                    }, 700L)
                }
            }
        }
    }

    @Suppress("MissingPermission")
    private fun stopScan() { mainHandler.removeCallbacks(scanTimeout); mainHandler.removeCallbacks(findTimeout); try { adapter?.bluetoothLeScanner?.stopScan(scanCallback) } catch (_: Exception) {}; scanning = false }

    @Suppress("MissingPermission")
    private fun connect(device: BluetoothDevice) {
        stopScan(); clearGattOperationQueue("new connection"); gatt?.close(); gatt = null
        characteristicRows.clear(); characteristicValues.clear(); notifyStates.clear(); serviceRows = emptyList()
        connectionState = "Подключение…"; addLog("Подключение к ${device.address}")
        try { gatt = device.connectGatt(this, false, gattCallback, BluetoothDevice.TRANSPORT_LE) }
        catch (e: SecurityException) { connectionState = "Нет разрешения"; addLog("Bluetooth permission: ${e.message}") }
    }

    @Suppress("MissingPermission")
    private fun requestBleBond() {
        val device = gatt?.device ?: run { addLog("PAIR: сначала подключитесь к NIU Link"); return }
        try {
            when (device.bondState) {
                BluetoothDevice.BOND_BONDED -> addLog("PAIR: Android уже считает устройство сопряжённым")
                BluetoothDevice.BOND_BONDING -> addLog("PAIR: сопряжение уже выполняется")
                else -> {
                    addLog("PAIR: запрошено стандартное системное BLE-сопряжение Android")
                    val started = device.createBond()
                    if (!started) addLog("PAIR: Android не принял запрос сопряжения")
                }
            }
        } catch (e: SecurityException) {
            addLog("PAIR: нет разрешения BLUETOOTH_CONNECT · ${e.message}")
        } catch (e: Exception) {
            addLog("PAIR error: ${e.message}")
        }
    }

    private fun enqueueGattOperation(operation: PendingGattOperation) {
        if (gatt == null) {
            addLog("GATT: операция отменена · нет соединения (${operation.label})")
            operation.onComplete(257)
            return
        }
        gattOperationQueue.addLast(operation)
        runNextGattOperation()
    }

    private fun runNextGattOperation() {
        if (activeGattOperation != null) return
        val operation = gattOperationQueue.removeFirstOrNull() ?: return
        activeGattOperation = operation
        val started = try { operation.start() } catch (e: Exception) {
            addLog("GATT ${operation.label}: ${e.javaClass.simpleName} · ${e.message}")
            false
        }
        if (!started) {
            addLog("GATT ${operation.label}: Android не принял операцию")
            completeGattOperation(257)
        } else {
            mainHandler.removeCallbacks(gattOperationTimeout)
            mainHandler.postDelayed(gattOperationTimeout, 10000L)
        }
    }

    private fun completeGattOperation(status: Int) {
        mainHandler.removeCallbacks(gattOperationTimeout)
        val completed = activeGattOperation
        activeGattOperation = null
        completed?.onComplete(status)
        // Give Android's Bluetooth stack a short gap before the next ATT request.
        mainHandler.removeCallbacks(gattQueueAdvance)
        mainHandler.postDelayed(gattQueueAdvance, 120L)
    }

    /** Ignore late callbacks from a closed/replaced GATT session and callbacks unrelated to the active ATT request. */
    private fun completeGattOperationFor(callbackGatt: BluetoothGatt, status: Int, characteristicUuid: String) {
        if (callbackGatt !== gatt) {
            addLog("GATT: проигнорирован запоздалый callback от старой сессии")
            return
        }
        val active = activeGattOperation ?: return
        if (!active.label.contains(characteristicUuid, ignoreCase = true)) {
            addLog("GATT: callback $characteristicUuid не соответствует операции ${active.label}; очередь сохранена")
            return
        }
        completeGattOperation(status)
    }

    private fun handleCharacteristicRead(callbackGatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray?, status: Int) {
        runOnUiThread {
            if (callbackGatt !== gatt) return@runOnUiThread
            val safeValue = value?.clone() ?: byteArrayOf()
            val rendered = if (status == BluetoothGatt.GATT_SUCCESS) hex(safeValue) else "READ_ERROR_$status"
            characteristicValues[characteristic.uuid.toString()] = rendered
            if (status == BluetoothGatt.GATT_SUCCESS) logPacket("READ", characteristic.uuid.toString(), safeValue)
            else addLog("READ ${characteristic.uuid}: ошибка GATT $status")
            completeGattOperationFor(callbackGatt, status, characteristic.uuid.toString())
        }
    }

    private fun handleCharacteristicChanged(callbackGatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray?) {
        runOnUiThread {
            if (callbackGatt !== gatt) return@runOnUiThread
            val safeValue = value?.clone() ?: byteArrayOf()
            characteristicValues[characteristic.uuid.toString()] = hex(safeValue)
            logPacket("NOTIFY", characteristic.uuid.toString(), safeValue)
        }
    }

    private fun clearGattOperationQueue(reason: String) {
        mainHandler.removeCallbacks(gattOperationTimeout)
        mainHandler.removeCallbacks(gattQueueAdvance)
        activeGattOperation = null
        gattOperationQueue.clear()
        readAllRunning = false
        readAllRemaining = 0
        mainHandler.removeCallbacks(bleResponseTimeout)
        activeBleExchange = null
        addLog("GATT queue cleared · $reason")
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            runOnUiThread {
                if (g !== gatt) return@runOnUiThread
                if (newState == BluetoothProfile.STATE_CONNECTED && status == BluetoothGatt.GATT_SUCCESS) {
                    connectionState = "Подключено"
                    connectedName = try { g.device.name ?: "NIU Link" } catch (_: Exception) { "NIU Link" }
                    connectedAddress = try { g.device.address } catch (_: Exception) { null }
                    addLog("BLE connected · ${connectedAddress ?: "device"}")
                    if (!g.discoverServices()) addLog("GATT: Android не принял запрос DISCOVER SERVICES")
                } else {
                    clearGattOperationQueue("disconnected")
                    connectionState = "Не подключено"
                    connectedName = null
                    connectedAddress = null
                    serviceRows = emptyList()
                    characteristicRows.clear()
                    characteristicValues.clear()
                    notifyStates.clear()
                    addLog("Соединение завершено · status=$status")
                    runCatching { g.close() }
                    if (gatt === g) gatt = null
                }
            }
        }

        @Suppress("DEPRECATION")
        override fun onCharacteristicRead(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, status: Int) {
            handleCharacteristicRead(g, characteristic, characteristic.value, status)
        }

        override fun onCharacteristicRead(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray, status: Int) {
            handleCharacteristicRead(g, characteristic, value, status)
        }

        @Suppress("DEPRECATION")
        override fun onCharacteristicWrite(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, status: Int) {
            runOnUiThread {
                if (g !== gatt) return@runOnUiThread
                if (status == BluetoothGatt.GATT_SUCCESS) addLog("WRITE complete ${characteristic.uuid} · GATT_SUCCESS")
                else addLog("WRITE failed ${characteristic.uuid} · GATT status=$status")
                val activeWrite = activeGattOperation
                if (activeWrite?.label?.startsWith("WRITE ", true) == true && activeWrite.label.contains(characteristic.uuid.toString(), true)) {
                    finishBleExchangeWrite(status)
                }
                completeGattOperationFor(g, status, characteristic.uuid.toString())
            }
        }

        @Suppress("DEPRECATION")
        override fun onDescriptorWrite(g: BluetoothGatt, descriptor: BluetoothGattDescriptor, status: Int) {
            runOnUiThread {
                if (g !== gatt) return@runOnUiThread
                if (status == BluetoothGatt.GATT_SUCCESS) addLog("DESCRIPTOR WRITE complete ${descriptor.uuid}")
                else addLog("DESCRIPTOR WRITE failed ${descriptor.uuid} · GATT status=$status")
                completeGattOperationFor(g, status, descriptor.characteristic.uuid.toString())
            }
        }

        @Suppress("DEPRECATION")
        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            handleCharacteristicChanged(g, characteristic, characteristic.value)
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
            handleCharacteristicChanged(g, characteristic, value)
        }

        override fun onMtuChanged(g: BluetoothGatt, mtu: Int, status: Int) {
            runOnUiThread { if (g === gatt) addLog("BLE MTU result=$mtu status=$status") }
        }

        override fun onReadRemoteRssi(g: BluetoothGatt, rssi: Int, status: Int) {
            runOnUiThread { if (g === gatt) addLog("BLE RSSI=$rssi dBm status=$status") }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            runOnUiThread {
                if (g !== gatt) return@runOnUiThread
                serviceRows = if (status == BluetoothGatt.GATT_SUCCESS) g.services.map { service ->
                    val known = when (service.uuid.toString().lowercase()) {
                        "8ec94e30-f315-4f60-9fb8-838830daea52" -> " · NIU LINK DATA CHANNEL"
                        "61751276-fdd6-11ed-be56-0242ac120002" -> " · NIU LINK CONTROL SERVICE"
                        else -> ""
                    }
                    "SERVICE  ${service.uuid}$known\n" + service.characteristics.joinToString("\n") { c ->
                        val hint = when (c.uuid.toString().lowercase()) {
                            "8ec94e31-f315-4f60-9fb8-838830daea52" -> "  · Chip to App"
                            "8ec94e32-f315-4f60-9fb8-838830daea52" -> "  · App to Chip candidate"
                            "8ec94e33-f315-4f60-9fb8-838830daea52" -> "  · protected characteristic"
                            "99ea30e2-fdda-11ed-be56-0242ac120002" -> "  · Write No Response"
                            else -> ""
                        }
                        "   ${c.uuid}  [${c.propertiesLabel()}]$hint"
                    }
                } else emptyList()
                characteristicRows.clear()
                if (status == BluetoothGatt.GATT_SUCCESS) g.services.forEach { service ->
                    service.characteristics.forEach { c ->
                        characteristicRows.add(CharacteristicEntry(service.uuid.toString(), c.uuid.toString(), c.properties, c.descriptors.map { it.uuid.toString() }))
                    }
                }
                addLog("Обнаружено BLE-сервисов: ${serviceRows.size}; характеристик: ${characteristicRows.size}")
                addLog("Команды управления отключены до подтверждения протокола и авторизации")
            }
        }
    }

    private fun hex(bytes: ByteArray?): String = bytes?.joinToString(" ") { "%02X".format(it) } ?: ""

    private fun logPacket(direction: String, uuid: String, bytes: ByteArray?) {
        val data = bytes ?: byteArrayOf()
        val exchange = activeBleExchange
        val isReceive = direction.equals("NOTIFY", true) || direction.equals("READ", true) || direction.equals("INDICATE", true)
        if (isReceive && exchange != null && System.currentTimeMillis() >= exchange.startedAt) {
            exchange.rxCount += 1
            addLog("BLE EXCHANGE #${exchange.id} RX_CANDIDATE · source=$direction · uuid=$uuid · packet=${exchange.rxCount}")
            updateBleCommandResult(exchange.id, "RX_RECEIVED", "Получен входящий пакет ${exchange.rxCount}; это ответ по времени, не подтверждённый ECU ACK")
        }
        addLog("$direction $uuid · ${data.size} byte · ${hex(data)}")
    }

    private fun beginBleExchange(uuid: String, bytes: ByteArray) {
        mainHandler.removeCallbacks(bleResponseTimeout)
        activeBleExchange?.let { previous ->
            addLog("BLE EXCHANGE #${previous.id} SUPERSEDED by next TX · RX candidates=${previous.rxCount}; no ECU ACK inferred")
            updateBleCommandResult(previous.id, "INTERRUPTED", "Прервано: начата следующая отправка")
        }
        val id = ++bleExchangeSequence
        activeBleExchange = BleExchange(id, uuid, System.currentTimeMillis())
        bleCommandResults.add(0, BleCommandResult(id, uuid, hex(bytes), "SENDING", "Команда поставлена в отправку", System.currentTimeMillis()))
        while (bleCommandResults.size > 20) bleCommandResults.removeAt(bleCommandResults.lastIndex)
        addLog("BLE EXCHANGE #$id TX · uuid=$uuid · ${bytes.size} byte · HEX=${hex(bytes)}")
    }

    private fun finishBleExchangeWrite(status: Int) {
        val exchange = activeBleExchange ?: return
        if (status == BluetoothGatt.GATT_SUCCESS) {
            if (exchange.rxCount == 0) {
                updateBleCommandResult(exchange.id, "SENT_WAITING", "Отправлено: GATT подтвердил запись. Ожидается ответ скутера; действие ещё не подтверждено")
            } else {
                updateBleCommandResult(exchange.id, "RX_RECEIVED", "Ответ уже получен (${exchange.rxCount} пакет.); выполнение команды протоколом не подтверждено")
            }
            addLog("BLE EXCHANGE #${exchange.id} GATT_WRITE_OK · ожидаю RX до 5 секунд; это ещё не ECU ACK")
            mainHandler.removeCallbacks(bleResponseTimeout)
            mainHandler.postDelayed(bleResponseTimeout, 5000L)
        } else {
            updateBleCommandResult(exchange.id, "ERROR", "Ошибка GATT-записи: status=$status")
            addLog("BLE EXCHANGE #${exchange.id} GATT_WRITE_ERROR · status=$status")
            activeBleExchange = null
        }
    }

    /** Passive protocol survey: MTU/RSSI, GATT metadata, readable values and receive-only subscriptions.
     * No proprietary command payloads or writes to NIU data/control characteristics are sent.
     */
    @Suppress("MissingPermission", "DEPRECATION")
    private fun runProtocolSurvey() {
        val active = gatt ?: run { addLog("PROTOCOL SURVEY: нет активного BLE-соединения"); return }
        addLog("========== NIU PROTOCOL SURVEY START ==========")
        addLog("SURVEY device=${connectedName ?: "unknown"} address=${connectedAddress ?: "unknown"} sdk=${android.os.Build.VERSION.SDK_INT}")
        runCatching { active.requestMtu(247) }.onFailure { addLog("SURVEY MTU request failed: ${it.message}") }
        runCatching { active.readRemoteRssi() }.onFailure { addLog("SURVEY RSSI request failed: ${it.message}") }
        active.services.orEmpty().forEach { service ->
            addLog("SURVEY SERVICE ${service.uuid} type=${service.type} characteristics=${service.characteristics.size}")
            service.characteristics.forEach { c ->
                addLog("SURVEY CHAR ${c.uuid} properties=${c.propertiesLabel()} instance=${c.instanceId} descriptors=${c.descriptors.size}")
                c.descriptors.forEach { d -> addLog("SURVEY DESC ${c.uuid}/${d.uuid} permissions=${d.permissions}") }
            }
        }
        val protected = setOf(
            "8ec94e32-f315-4f60-9fb8-838830daea52",
            "8ec94e33-f315-4f60-9fb8-838830daea52",
            "99ea30e2-fdda-11ed-be56-0242ac120002"
        )
        val receiveCandidates = active.services.orEmpty().flatMap { it.characteristics }
            .filter { it.uuid.toString().lowercase() !in protected }
            .filter { it.properties and (BluetoothGattCharacteristic.PROPERTY_NOTIFY or BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0 }
        addLog("SURVEY receive candidates=${receiveCandidates.size}; receive-only subscriptions; manual TX is available in GATT Explorer")
        receiveCandidates.forEach { c ->
            if (notifyStates[c.uuid.toString()] != true) toggleNotifications(c.uuid.toString(), true)
        }
        addLog("SURVEY starting sequential readable-characteristic scan")
        readAllAvailable()
        addLog("========== NIU PROTOCOL SURVEY QUEUED ==========")
    }

    @Suppress("MissingPermission")
    private fun readCharacteristic(uuidText: String) {
        val active = gatt ?: run { addLog("Нет активного соединения"); return }
        val characteristic = active.services.orEmpty().flatMap { it.characteristics }.firstOrNull { it.uuid.toString().equals(uuidText, true) }
            ?: run { addLog("Характеристика не найдена: $uuidText"); return }
        if (characteristic.properties and BluetoothGattCharacteristic.PROPERTY_READ == 0) {
            addLog("Чтение не поддерживается: $uuidText"); return
        }
        enqueueGattOperation(PendingGattOperation(
            label = "READ $uuidText",
            start = { gatt === active && active.readCharacteristic(characteristic) },
            onComplete = { status ->
                if (status == BluetoothGatt.GATT_SUCCESS) addLog("READ complete $uuidText")
                else addLog("READ failed $uuidText · status=$status")
            }
        ))
    }

    /** Reads readable characteristics sequentially; HID is excluded because Android may require BLUETOOTH_PRIVILEGED. */
    private fun readAllAvailable() {
        val active = gatt ?: run { addLog("READ ALL: нет активного BLE-соединения"); return }
        if (readAllRunning) { addLog("READ ALL: операция уже выполняется"); return }
        val hidService = "00001812-0000-1000-8000-00805f9b34fb"
        val protectedNiuCharacteristic = "8ec94e33-f315-4f60-9fb8-838830daea52"
        val readable = active.services.orEmpty()
            .filterNot { it.uuid.toString().equals(hidService, true) }
            .flatMap { it.characteristics }
            .filter { it.properties and BluetoothGattCharacteristic.PROPERTY_READ != 0 }
            .filterNot { it.uuid.toString().equals(protectedNiuCharacteristic, true) }
        val skippedHid = active.services.orEmpty()
            .filter { it.uuid.toString().equals(hidService, true) }
            .sumOf { it.characteristics.size }
        if (readable.isEmpty()) { addLog("READ ALL: нет доступных READ-характеристик"); return }
        readAllRunning = true
        readAllRemaining = readable.size
        addLog("READ ALL: очередь ${readable.size}; HID пропущен: $skippedHid; защищённая NIU characteristic пропущена")
        readable.forEach { characteristic ->
            val uuid = characteristic.uuid.toString()
            enqueueGattOperation(PendingGattOperation(
                label = "READ ALL $uuid",
                start = { gatt === active && active.readCharacteristic(characteristic) },
                onComplete = { status ->
                    if (status != BluetoothGatt.GATT_SUCCESS) addLog("READ ALL: $uuid · ошибка $status")
                    readAllRemaining = (readAllRemaining - 1).coerceAtLeast(0)
                    if (readAllRemaining == 0) {
                        readAllRunning = false
                        addLog("READ ALL: завершено")
                    }
                }
            ))
        }
    }

    @Suppress("MissingPermission", "DEPRECATION")
    private fun toggleNotifications(uuidText: String, enable: Boolean) {
        val active = gatt ?: run { addLog("Нет активного соединения"); return }
        val characteristic = active.services.orEmpty().flatMap { it.characteristics }.firstOrNull { it.uuid.toString().equals(uuidText, true) }
            ?: run { addLog("Характеристика не найдена: $uuidText"); return }
        val canNotify = characteristic.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0
        val canIndicate = characteristic.properties and BluetoothGattCharacteristic.PROPERTY_INDICATE != 0
        if (!canNotify && !canIndicate) { addLog("Notify/Indicate не поддерживается: $uuidText"); return }
        val cccd = characteristic.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb"))
            ?: run { addLog("CCCD-дескриптор отсутствует у $uuidText"); return }
        enqueueGattOperation(PendingGattOperation(
            label = "CCCD $uuidText",
            start = {
                if (gatt !== active || !active.setCharacteristicNotification(characteristic, enable)) false
                else {
                    cccd.value = if (!enable) BluetoothGattDescriptor.DISABLE_NOTIFICATION_VALUE
                        else if (canNotify) BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE else BluetoothGattDescriptor.ENABLE_INDICATION_VALUE
                    active.writeDescriptor(cccd)
                }
            },
            onComplete = { status ->
                if (status == BluetoothGatt.GATT_SUCCESS) {
                    notifyStates[uuidText] = enable
                    addLog("${if (enable) "Подписка подтверждена" else "Подписка отключена"}: $uuidText")
                } else {
                    runCatching { active.setCharacteristicNotification(characteristic, false) }
                    notifyStates[uuidText] = false
                    addLog("CCCD не подтверждён для $uuidText · status=$status")
                }
            }
        ))
    }

    @Suppress("MissingPermission", "DEPRECATION")
    private fun writeCharacteristicHex(uuidText: String, hexText: String) {
        val active = gatt ?: run { recordBleCommandFailure(uuidText, hexText, "Нет активного BLE-соединения"); return }
        val characteristic = active.services.orEmpty().flatMap { it.characteristics }.firstOrNull { it.uuid.toString().equals(uuidText, true) }
            ?: run { recordBleCommandFailure(uuidText, hexText, "Характеристика не найдена"); return }
        val proprietaryNiuCandidates = setOf(
            "8ec94e32-f315-4f60-9fb8-838830daea52",
            "8ec94e33-f315-4f60-9fb8-838830daea52",
            "99ea30e2-fdda-11ed-be56-0242ac120002"
        )
        if (uuidText.lowercase() in proprietaryNiuCandidates) {
            if (uuidText.equals("8ec94e33-f315-4f60-9fb8-838830daea52", true)) {
                recordBleCommandFailure(uuidText, hexText, "Защищённый AUTH-канал 8ec94e33; ручная запись отключена")
                addLog("WRITE BLOCKED · 8ec94e33 protected/auth channel · prior GATT AUTH FAIL (0x89); no raw writes to this characteristic")
                return
            }
            addLog("EXPERIMENTAL NIU WRITE requested · uuid=$uuidText · payload is user-supplied, not generated by the app. GATT acceptance does not prove ECU execution.")
        }
        val props = characteristic.properties
        val withResponse = props and BluetoothGattCharacteristic.PROPERTY_WRITE != 0
        val withoutResponse = props and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0
        if (!withResponse && !withoutResponse) { recordBleCommandFailure(uuidText, hexText, "Характеристика не поддерживает WRITE"); return }
        val tokens = hexText.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
        if (tokens.isEmpty() || tokens.any { !it.matches(Regex("(?i)[0-9a-f]{2}")) }) {
            recordBleCommandFailure(uuidText, hexText, "Некорректный HEX; используйте байты через пробел, например 01 0A FF")
            return
        }
        val bytes = tokens.map { it.toInt(16).toByte() }.toByteArray()
        val normalizedUuid = characteristic.uuid.toString()
        lastBleWriteUuid = normalizedUuid
        lastBleWriteHex = hex(bytes)
        // The Chip→App notification channel is subscribed first when available, so RX capture is armed before TX.
        if (normalizedUuid.equals("8ec94e32-f315-4f60-9fb8-838830daea52", true) || normalizedUuid.equals("99ea30e2-fdda-11ed-be56-0242ac120002", true)) {
            val rxCharacteristic = active.services.orEmpty().flatMap { it.characteristics }
                .firstOrNull { it.uuid.toString().equals("8ec94e31-f315-4f60-9fb8-838830daea52", true) }
            if (rxCharacteristic != null && rxCharacteristic.properties and (BluetoothGattCharacteristic.PROPERTY_NOTIFY or BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0 && notifyStates[rxCharacteristic.uuid.toString()] != true) {
                addLog("BLE EXCHANGE: enabling Chip→App RX notification before write")
                toggleNotifications(rxCharacteristic.uuid.toString(), true)
            }
        }
        val writeType = if (withResponse) BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT else BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
        enqueueGattOperation(PendingGattOperation(
            label = "WRITE $normalizedUuid",
            start = {
                if (gatt !== active) false else {
                    characteristic.writeType = writeType
                    characteristic.value = bytes
                    val accepted = active.writeCharacteristic(characteristic)
                    if (accepted) beginBleExchange(normalizedUuid, bytes)
                    else recordBleCommandFailure(normalizedUuid, hex(bytes), "Android Bluetooth stack не принял запись")
                    accepted
                }
            },
            onComplete = { status ->
                if (status == BluetoothGatt.GATT_SUCCESS) {
                    addLog("WRITE accepted/completed $normalizedUuid · ${bytes.size} byte · ${hex(bytes)} · ${if (withResponse) "WITH RESPONSE" else "WITHOUT RESPONSE"} · ECU_ACK_NOT_CONFIRMED")
                    // Some Android stacks do not deliver a write callback for WRITE_NO_RESPONSE.
                    if (!withResponse && activeBleExchange != null) finishBleExchangeWrite(BluetoothGatt.GATT_SUCCESS)
                } else {
                    addLog("WRITE failed $normalizedUuid · status=$status · no ECU command confirmation")
                    if (activeBleExchange != null) finishBleExchangeWrite(status)
                }
            }
        ))
    }

    private fun android.bluetooth.BluetoothGattCharacteristic.propertiesLabel(): String {
        val p = properties; val a = mutableListOf<String>()
        if (p and android.bluetooth.BluetoothGattCharacteristic.PROPERTY_READ != 0) a.add("R")
        if (p and android.bluetooth.BluetoothGattCharacteristic.PROPERTY_WRITE != 0) a.add("W")
        if (p and android.bluetooth.BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0) a.add("WNR")
        if (p and android.bluetooth.BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0) a.add("N")
        if (p and android.bluetooth.BluetoothGattCharacteristic.PROPERTY_INDICATE != 0) a.add("I")
        return a.joinToString("/")
    }

    @Suppress("MissingPermission")
    private fun refreshServices() {
        val active = gatt ?: run { addLog("Нет активного BLE-соединения"); return }
        try { serviceRows = emptyList(); active.discoverServices(); addLog("Повторное обнаружение GATT-сервисов") }
        catch (e: Exception) { addLog("Ошибка обновления GATT: ${e.message}") }
    }

    private fun buildExportReport(): String = buildString {
        appendLine("NIU Mobility Studio · nRF BLE report")
        appendLine("Generated: ${java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US).format(java.util.Date())}")
        appendLine("Connection: $connectionState")
        appendLine("Device: ${connectedName ?: "—"} · ${connectedAddress ?: "—"}")
        appendLine("\nGATT SERVICES")
        serviceRows.forEach { appendLine(it) }
        appendLine("\nCHARACTERISTICS")
        characteristicRows.forEach { row ->
            appendLine("SERVICE ${row.serviceUuid}")
            appendLine("  ${row.uuid} [${propertiesLabel(row.properties)}]")
            row.descriptors.forEach { appendLine("    DESCRIPTOR $it") }
            val packetBytes = characteristicValues[row.uuid].orEmpty().trim().split(Regex("\\s+")).filter { it.matches(Regex("[0-9A-Fa-f]{2}")) }
            appendLine("    VALUE_HEX ${packetBytes.joinToString(" ").ifBlank { "(not read)" }}")
            packetBytes.forEachIndexed { index, byteText ->
                val byte = byteText.toIntOrNull(16) ?: 0
                val ascii = if (byte in 32..126) byte.toChar() else '.'
                appendLine("      BYTE[$index] HEX=${byteText.uppercase()} DEC=$byte BIN=${byte.toString(2).padStart(8, '0')} ASCII=$ascii")
            }
            appendLine("    NOTIFY ${notifyStates[row.uuid] == true}")
        }
        appendLine("\nEVENT LOG")
        logs.reversed().forEach { appendLine(it) }
        appendLine("\nSafety: no unknown control commands were sent by this app.")
    }

    private fun propertiesLabel(p: Int): String = buildList {
        if (p and BluetoothGattCharacteristic.PROPERTY_READ != 0) add("READ")
        if (p and BluetoothGattCharacteristic.PROPERTY_WRITE != 0) add("WRITE")
        if (p and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0) add("WRITE_NO_RESPONSE")
        if (p and BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0) add("NOTIFY")
        if (p and BluetoothGattCharacteristic.PROPERTY_INDICATE != 0) add("INDICATE")
    }.joinToString("/")

    private fun importReferenceText(text: String, fileName: String) {
        referenceRawText = text
        referenceFileName = fileName
        referenceCharacteristics.clear()
        val uuid = "[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}"
        val blockRegex = Regex("(?is)($uuid)\\s*\\[([^]]*)]([^$]+?)(?=$uuid\\s*\\[|$)")
        blockRegex.findAll(text).forEach { match ->
            val id = match.groupValues[1].lowercase()
            val props = match.groupValues[2].trim().uppercase()
            val tail = match.groupValues[3]
            val value = Regex("(?im)^\\s*(?:VALUE|ЗНАЧЕНИЕ)\\s*:?\\s*(.+)$").find(tail)?.groupValues?.get(1)?.trim()
            referenceCharacteristics[id] = ReferenceCharacteristic(props, value)
        }
        // Also accept compact rows such as UUID | READ/NOTIFY | 01 02 FF.
        if (referenceCharacteristics.isEmpty()) {
            val rowRegex = Regex("(?im)^\\s*($uuid)\\s*[|;,]\\s*([^|;,]+)(?:[|;,]\\s*(.*))?$")
            rowRegex.findAll(text).forEach { m ->
                referenceCharacteristics[m.groupValues[1].lowercase()] = ReferenceCharacteristic(m.groupValues[2].trim().uppercase(), m.groupValues.getOrNull(3)?.trim()?.takeIf { it.isNotBlank() })
            }
        }
        addLog("Импорт эталона: $fileName · характеристик: ${referenceCharacteristics.size}")
        if (referenceCharacteristics.isEmpty()) addLog("В файле не найдены строки UUID с характеристиками. Нужен TXT-отчёт FX Studio/nRF или строки UUID | PROPERTIES | VALUE.")
    }

    private fun referenceComparisonReport(): String = buildString {
        appendLine("NIU FX · ORIGINAL APP COMPARISON")
        appendLine("Reference: ${referenceFileName ?: "not imported"}")
        appendLine("Current device: ${connectedName ?: "—"} · ${connectedAddress ?: "—"}")
        appendLine("UUID | ORIGINAL PROPERTIES | CURRENT PROPERTIES | ORIGINAL VALUE | CURRENT VALUE | RESULT")
        val ids = (referenceCharacteristics.keys + characteristicRows.map { it.uuid.lowercase() }).distinct().sorted()
        ids.forEach { id ->
            val ref = referenceCharacteristics[id]
            val cur = characteristicRows.firstOrNull { it.uuid.equals(id, true) }
            val currentProps = cur?.let { propertiesLabel(it.properties) } ?: "MISSING"
            val currentValue = characteristicValues[id] ?: "—"
            val normalizeProps: (String) -> String = { it.uppercase().replace("_", "").replace("/", "").replace(" ", "") }
            val propertyMatch = ref != null && cur != null && normalizeProps(ref.properties) == normalizeProps(currentProps)
            val valueMatch = ref?.value != null && characteristicValues[id] != null && ref.value.equals(currentValue, true)
            val result = when {
                ref == null -> "NOT_IN_REFERENCE"
                cur == null -> "NOT_IN_CURRENT"
                ref.value != null && characteristicValues[id] != null && !valueMatch -> "VALUE_DIFFERS"
                propertyMatch && (ref.value == null || characteristicValues[id] == null || valueMatch) -> "MATCH_OR_INCOMPLETE_VALUE"
                else -> "CHECK_REQUIRED"
            }
            appendLine("$id | ${ref?.properties ?: "—"} | $currentProps | ${ref?.value ?: "—"} | $currentValue | $result")
        }
        appendLine("\nFUNCTIONAL CHECKS")
        appendLine("BLE connection: ${if (connectedName != null) "PASS" else "NOT_TESTED"}")
        appendLine("GATT discovery: ${if (characteristicRows.isNotEmpty()) "PASS" else "NOT_TESTED"}")
        appendLine("Readable values: ${characteristicRows.count { it.properties and BluetoothGattCharacteristic.PROPERTY_READ != 0 && characteristicValues[it.uuid] != null }}")
        appendLine("Active notifications: ${notifyStates.count { it.value }}")
        appendLine("Note: structural/value comparison does not prove that a scooter function (lock, drive mode, alarm, etc.) behaves like the official app.")
    }

    private fun shareText(report: String, subject: String) {
        val intent = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_SUBJECT, subject); putExtra(Intent.EXTRA_TEXT, report) }
        startActivity(Intent.createChooser(intent, "Поделиться отчётом"))
    }

    private fun shareDiagnostics() = shareText(buildExportReport(), "NIU FX BLE diagnostics")

    private fun saveText(report: String, fileName: String) {
        pendingExportText = report
        createTextFile.launch(fileName)
    }

    private fun saveDiagnosticsTxt() = saveText(buildExportReport(), "NIU_FX_BLE_${System.currentTimeMillis()}.txt")

    @Suppress("MissingPermission")
    private fun disconnect() {
        clearGattOperationQueue("manual disconnect")
        val old = gatt
        gatt = null
        try { old?.disconnect() } catch (_: Exception) {}
        try { old?.close() } catch (_: Exception) {}
        connectionState = "Не подключено"
        connectedName = null
        connectedAddress = null
        serviceRows = emptyList()
        characteristicRows.clear()
        characteristicValues.clear()
        notifyStates.clear()
        readAllRunning = false; readAllRemaining = 0
        addLog("Отключено пользователем · GATT закрыт")
    }

    private fun safeStatusProbe() {
        val target = "8ec94e31-f315-4f60-9fb8-838830daea52"
        val row = characteristicRows.firstOrNull { it.uuid.equals(target, true) }
        if (row == null) {
            addLog("STATUS probe: канал Chip-to-App не найден в текущем GATT")
            return
        }
        if (row.properties and BluetoothGattCharacteristic.PROPERTY_READ != 0) {
            addLog("STATUS probe: только READ существующей характеристики; управляющие данные не отправляются")
            readCharacteristic(target)
        } else if (row.properties and (BluetoothGattCharacteristic.PROPERTY_NOTIFY or BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0) {
            addLog("STATUS probe: включите подписку NOTIFY для приёма данных от скутера")
            toggleNotifications(target, true)
        } else addLog("STATUS probe: характеристика не поддерживает READ/NOTIFY")
    }

    private fun listenTelemetry() {
        val target = "8ec94e31-f315-4f60-9fb8-838830daea52"
        val row = characteristicRows.firstOrNull { it.uuid.equals(target, true) }
        if (row == null) { addLog("Telemetry: характеристика Chip-to-App не обнаружена"); return }
        toggleNotifications(target, notifyStates[target] != true)
    }

    private fun appPinPrefs() = getSharedPreferences("niu_app_lock", MODE_PRIVATE)

    private fun appPinHash(pin: String, salt: ByteArray): ByteArray {
        val spec = javax.crypto.spec.PBEKeySpec(pin.toCharArray(), salt, 180_000, 256)
        return try { javax.crypto.SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded }
        finally { spec.clearPassword() }
    }

    private fun authenticateAppBiometric(onSuccess: () -> Unit, onError: (String) -> Unit) {
        val authenticators = BiometricManager.Authenticators.BIOMETRIC_STRONG
        if (BiometricManager.from(this).canAuthenticate(authenticators) != BiometricManager.BIOMETRIC_SUCCESS) {
            onError("На устройстве не настроен совместимый отпечаток пальца")
            return
        }
        val prompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) = onSuccess()
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) = onError(errString.toString())
            override fun onAuthenticationFailed() = onError("Отпечаток не распознан")
        })
        prompt.authenticate(BiometricPrompt.PromptInfo.Builder()
            .setTitle("NIU Mobility Studio")
            .setSubtitle("Подтвердите вход в приложение")
            .setNegativeButtonText("Отмена")
            .setAllowedAuthenticators(authenticators)
            .build())
    }

    @Composable private fun FxApp() {
        val prefs = remember { appPinPrefs() }
        var authenticated by remember { mutableStateOf(false) }
        val configured = remember { prefs.contains("pin_hash") && prefs.contains("pin_salt") }
        if (!configured) {
            AppPinSetup { authenticated = true }
        } else if (!authenticated) {
            AppPinUnlock(
                biometricEnabled = prefs.getBoolean("biometric_enabled", false),
                onPin = { pin ->
                    val salt = runCatching { android.util.Base64.decode(prefs.getString("pin_salt", ""), android.util.Base64.NO_WRAP) }.getOrNull()
                    val expected = runCatching { android.util.Base64.decode(prefs.getString("pin_hash", ""), android.util.Base64.NO_WRAP) }.getOrNull()
                    val actual = if (salt != null) runCatching { appPinHash(pin, salt) }.getOrNull() else null
                    val valid = actual != null && expected != null && java.security.MessageDigest.isEqual(actual, expected)
                    actual?.fill(0)
                    valid
                },
                onBiometric = { success, failure -> authenticateAppBiometric(success, failure) },
                onUnlocked = { authenticated = true }
            )
        } else {
            FxAppContent()
        }
    }

    @Composable private fun AppPinSetup(onComplete: () -> Unit) {
        val prefs = remember { appPinPrefs() }
        var first by remember { mutableStateOf("") }
        var second by remember { mutableStateOf("") }
        var step by remember { mutableIntStateOf(0) }
        var biometric by remember { mutableStateOf(false) }
        var error by remember { mutableStateOf("") }
        Column(Modifier.fillMaxSize().background(Ink).padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.Settings, contentDescription = null, tint = Lime, modifier = Modifier.size(48.dp))
            Spacer(Modifier.height(18.dp))
            Text("ЗАЩИТА ПРИЛОЖЕНИЯ", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(if (step == 0) "Создайте PIN-код только из цифр (4–8 знаков)." else "Повторите PIN-код для подтверждения.", color = Muted, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(vertical = 14.dp))
            OutlinedTextField(
                value = if (step == 0) first else second,
                onValueChange = { value ->
                    val digits = value.filter(Char::isDigit).take(8)
                    if (step == 0) first = digits else second = digits
                    error = ""
                },
                modifier = Modifier.fillMaxWidth(), singleLine = true,
                label = { Text("PIN-код · 4–8 цифр", color = Color.White) },
                textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 22.sp, letterSpacing = 7.sp, textAlign = TextAlign.Center),
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.NumberPassword)
            )
            if (error.isNotBlank()) Text(error, color = Color(0xFFFF8A80), fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
            if (step == 0) {
                Button(onClick = { if (first.length in 4..8) step = 1 else error = "PIN должен содержать от 4 до 8 цифр" }, modifier = Modifier.fillMaxWidth().padding(top = 16.dp)) { Text("ПРОДОЛЖИТЬ") }
            } else {
                Button(onClick = {
                    if (second != first) { error = "PIN-коды не совпадают"; second = "" }
                    else {
                        val salt = ByteArray(16).also { java.security.SecureRandom().nextBytes(it) }
                        val hash = appPinHash(first, salt)
                        prefs.edit()
                            .putString("pin_salt", android.util.Base64.encodeToString(salt, android.util.Base64.NO_WRAP))
                            .putString("pin_hash", android.util.Base64.encodeToString(hash, android.util.Base64.NO_WRAP))
                            .putBoolean("biometric_enabled", biometric && BiometricManager.from(this@MainActivity).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) == BiometricManager.BIOMETRIC_SUCCESS).apply()
                        hash.fill(0); first = ""; second = ""
                        // First successful PIN setup enters the app immediately; biometric is offered on the next unlock.
                        onComplete()
                    }
                }, modifier = Modifier.fillMaxWidth().padding(top = 16.dp)) { Text("СОХРАНИТЬ PIN") }
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 8.dp)) {
                    Checkbox(checked = biometric, onCheckedChange = { biometric = it })
                    Text("Включить вход по отпечатку", color = Color.White, fontSize = 12.sp)
                }
                TextButton(onClick = { step = 0; second = ""; error = "" }) { Text("Назад", color = Muted) }
            }
            Text("PIN хранится в виде криптографического хеша. Отпечаток обрабатывает Android; приложение не получает биометрические данные.", color = Muted, fontSize = 10.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 18.dp))
        }
    }

    @Composable private fun AppPinUnlock(biometricEnabled: Boolean, onPin: (String) -> Boolean, onBiometric: (() -> Unit, (String) -> Unit) -> Unit, onUnlocked: () -> Unit) {
        var pin by remember { mutableStateOf("") }
        var error by remember { mutableStateOf("") }
        Column(Modifier.fillMaxSize().background(Ink).padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.Settings, contentDescription = null, tint = Lime, modifier = Modifier.size(46.dp))
            Spacer(Modifier.height(16.dp))
            Text("NIU MOBILITY STUDIO", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Text("Введите PIN-код для входа", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(vertical = 16.dp))
            OutlinedTextField(pin, { pin = it.filter(Char::isDigit).take(8); error = "" }, Modifier.fillMaxWidth(), label = { Text("PIN · только цифры", color = Color.White) }, singleLine = true, textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 22.sp, letterSpacing = 7.sp, textAlign = TextAlign.Center), visualTransformation = PasswordVisualTransformation(), keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.NumberPassword))
            if (error.isNotBlank()) Text(error, color = Color(0xFFFF8A80), fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
            Button(onClick = { if (onPin(pin)) { pin = ""; onUnlocked() } else error = "Неверный PIN-код" }, enabled = pin.length in 4..8, modifier = Modifier.fillMaxWidth().padding(top = 16.dp)) { Text("ВОЙТИ") }
            if (biometricEnabled) OutlinedButton(onClick = { onBiometric({ onUnlocked() }, { error = it }) }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) { Text("ОТПЕЧАТОК ПАЛЬЦА") }
        }
    }

    @Composable private fun FxAppContent() {
        var splashVisible by remember { mutableStateOf(true) }
        LaunchedEffect(Unit) {
            delay(1_650)
            splashVisible = false
        }
        var tab by remember {
            mutableIntStateOf(getSharedPreferences("workspace_session", MODE_PRIVATE)
                .getInt("last_route", 0).coerceIn(0, 20))
        }
        val history = remember(activeVehicleSerial) { mutableStateListOf<Int>() }
        var toolsMenuExpanded by remember { mutableStateOf(false) }
        var toolsUnlocked by remember { mutableStateOf(false) }
        var adminGrantRefresh by remember { mutableIntStateOf(0) }
        val appContext = LocalContext.current
        val protectedToolsAvailable = BuildConfig.PROTECTED_TOOLS_ENABLED && adminGrantRefresh >= 0 && (!BuildConfig.IS_USER_BUILD || AdminGrantVerifier.isAuthorized(appContext, BuildConfig.ADMIN_PUBLIC_KEY))
        LaunchedEffect(BuildConfig.IS_USER_BUILD) {
            if (BuildConfig.IS_USER_BUILD) while (true) { delay(15_000); adminGrantRefresh++ }
        }
        LaunchedEffect(protectedToolsAvailable) { if (!protectedToolsAvailable) toolsUnlocked = false }
        val protectedRoutes = remember { setOf(4, 5, 6, 12, 13, 15, 16) } // Local diagnostics remain available in user distributions.
        val mainNav = listOf(
            Triple(0, "Главная", Icons.Default.Home),
            Triple(1, "Скутер", Icons.Default.DirectionsBike),
            Triple(2, "Профиль", Icons.Default.Person)
        )
        fun navigate(route: Int) {
            if (route == tab) return
            history.add(tab)
            tab = route
        }
        LaunchedEffect(cloudJournalNavigationRequest) {
            if (cloudJournalNavigationRequest) {
                navigate(14)
                cloudJournalNavigationRequest = false
            }
        }
        fun goBack() {
            if (history.isNotEmpty()) tab = history.removeAt(history.lastIndex)
            else if (tab != 0) tab = 0
        }
        BackHandler(enabled = history.isNotEmpty() || tab != 0) { goBack() }
        LaunchedEffect(tab) {
            getSharedPreferences("workspace_session", MODE_PRIVATE).edit().putInt("last_route", tab).apply()
        }
        MaterialTheme(
            colorScheme = darkColorScheme(
                primary = Lime, background = Ink, surface = Panel,
                onPrimary = Color.White, onBackground = Color.White, onSurface = Color.White
            ),
            typography = Typography().copy(
                labelLarge = Typography().labelLarge.copy(fontSize = 12.sp, lineHeight = 14.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.1.sp),
                labelMedium = Typography().labelMedium.copy(fontSize = 11.sp, lineHeight = 13.sp),
                bodyMedium = Typography().bodyMedium.copy(fontSize = 13.sp, lineHeight = 19.sp),
                titleSmall = Typography().titleSmall.copy(fontSize = 15.sp, lineHeight = 20.sp, fontWeight = FontWeight.SemiBold)
            ),
            shapes = Shapes(
                small = RoundedCornerShape(8.dp),
                medium = RoundedCornerShape(12.dp),
                large = RoundedCornerShape(16.dp)
            )
        ) {
            BoxWithConstraints(Modifier.fillMaxSize().background(Ink).windowInsetsPadding(WindowInsets.safeDrawing)) {
                val wideLayout = maxWidth >= 600.dp
                val largeLayout = maxWidth >= 1200.dp
                Scaffold(
                    containerColor = Ink,
                    topBar = {
                        Row(
                            Modifier.fillMaxWidth().heightIn(min = 60.dp).background(Panel).padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (history.isNotEmpty() || tab != 0) {
                                IconButton(onClick = { goBack() }) {
                                    Icon(Icons.Default.ArrowBack, contentDescription = "Назад", tint = Color.White)
                                }
                            }
                            ComposeImage(
                                painter = painterResource(id = com.niu.fxstudio.R.drawable.niu_mobility_logo),
                                contentDescription = "Логотип NIU Mobility Studio",
                                modifier = Modifier.size(32.dp).padding(end = 6.dp),
                                contentScale = ContentScale.Fit
                            )
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
                                Text("NIU MOBILITY STUDIO", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = .5.sp, maxLines = 1)
                                Text(when (tab) {
                                    0 -> "ВАШЕ ПРОСТРАНСТВО"
                                    13 -> "РЕДАКТОР ПРОЕКТА"
                                    1 -> "УПРАВЛЕНИЕ СКУТЕРОМ"
                                    2 -> "ПРОФИЛЬ И АККАУНТ"
                                    3 -> "ИНСТРУМЕНТЫ"
                                    4 -> "BLE EXPLORER"
                                    5 -> "NFC INSPECTOR"
                                    6 -> "ДИАГНОСТИКА"
                                    8 -> "ДИСПЛЕЙ"
                                    9 -> "МУЗЫКА"
                                    10 -> "ЗВУКОВЫЕ ЭФФЕКТЫ"
                                    11 -> "О ПРИЛОЖЕНИИ"
                                    12 -> "AI ASSISTANT"
                                    14 -> "ЖУРНАЛ СОБЫТИЙ"
                                    15 -> "ОБСЛУЖИВАНИЕ И ПОЕЗДКИ"
                                    16 -> "TELEGRAM И ЛОКАЛЬНЫЙ СЕРВЕР"
                                    17 -> "ДОКУМЕНТАЦИЯ И README"
                                    else -> "СВЯЗЬ"
                                }, color = Muted, fontSize = 9.sp, letterSpacing = .8.sp)
                            }
                            Text(BuildConfig.VERSION_NAME, color = Muted, fontSize = 10.sp, modifier = Modifier.padding(end = 2.dp))
                            IconButton(onClick = { navigate(14) }) {
                                Icon(Icons.Default.BugReport, contentDescription = "Журнал ошибок", tint = if (tab == 14) Lime else Color.White)
                            }
                            InfoIconButton("Журнал событий", "Открывает общий журнал ошибок и событий. Здесь можно выбрать фильтр, сохранить TXT/MD/JSON/CSV или подготовить обезличенный Markdown для ручной публикации на mdpaste.ru.")
                            Box {
                                IconButton(onClick = { toolsMenuExpanded = true }) {
                                    Icon(Icons.Default.Settings, contentDescription = "Меню инструментов", tint = if (toolsMenuExpanded) Lime else Color.White)
                                }
                                DropdownMenu(expanded = toolsMenuExpanded, onDismissRequest = { toolsMenuExpanded = false }) {
                                    Text("УПРАВЛЕНИЕ", color = Lime, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
                                    DropdownMenuItem(
                                        text = { Column { Text("Скутер и подключение"); Text("Cloud · BLE · состояние устройства", color = Muted, fontSize = 10.sp) } },
                                        onClick = { toolsMenuExpanded = false; navigate(1) },
                                        leadingIcon = { Icon(Icons.Default.DirectionsBike, contentDescription = null) }
                                    )
                                    DropdownMenuItem(text = { Text("Связь / Bluetooth") }, onClick = { toolsMenuExpanded = false; navigate(7) })
                                    Divider()
                                    Text("ЗАЩИЩЁННАЯ СРЕДА", color = Lime, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
                                    DropdownMenuItem(
                                        text = { Column { Text("Инструменты и Workspace"); Text("BLE · nRF · диагностика · логи · AI · Telegram", color = Muted, fontSize = 10.sp) } },
                                        onClick = { toolsMenuExpanded = false; navigate(19) },
                                        leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) }
                                    )
                                    Divider()
                                    Text("ПЕРСОНАЛИЗАЦИЯ", color = Lime, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
                                    listOf(18 to "Оформление и темы", 8 to "Дисплей и обои", 9 to "Музыка", 10 to "Звуковые эффекты").forEach { (route, label) ->
                                        DropdownMenuItem(text = { Text(label) }, onClick = { toolsMenuExpanded = false; navigate(route) })
                                    }
                                    Divider()
                                    Text("СПРАВКА", color = Lime, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
                                    listOf(17 to "Документация", 11 to "О приложении").forEach { (route, label) ->
                                        DropdownMenuItem(text = { Text(label) }, onClick = { toolsMenuExpanded = false; navigate(route) })
                                    }
                                }
                            }
                        }
                    },
                    bottomBar = {
                        if (!wideLayout) {
                            NavigationBar(modifier = Modifier.height(64.dp), containerColor = Panel, contentColor = Lime, tonalElevation = 0.dp) {
                                mainNav.forEach { (route, label, icon) ->
                                    NavigationBarItem(
                                        selected = tab == route,
                                        onClick = { navigate(route) },
                                        icon = { Icon(icon, contentDescription = label) },
                                        label = { Text(label, maxLines = 1, softWrap = false) },
                                        colors = NavigationBarItemDefaults.colors(
                                            selectedIconColor = Lime, selectedTextColor = Color.White,
                                            indicatorColor = Color(0xFF3A2525), unselectedIconColor = Muted,
                                            unselectedTextColor = Muted
                                        )
                                    )
                                }
                            }
                        }
                    }
                ) { pad ->
                    Row(Modifier.fillMaxSize().padding(pad)) {
                        if (wideLayout) {
                            Column(
                                Modifier.width(if (largeLayout) 208.dp else 76.dp)
                                    .fillMaxHeight().background(Panel).padding(vertical = 12.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                mainNav.forEach { (route, label, icon) ->
                                    val selected = tab == route
                                    Row(
                                        Modifier.fillMaxWidth().padding(horizontal = 8.dp)
                                            .background(if (selected) Color(0xFF3A2525) else Color.Transparent, RoundedCornerShape(16.dp))
                                            .clickable { navigate(route) }
                                            .padding(horizontal = if (largeLayout) 14.dp else 0.dp, vertical = 13.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = if (largeLayout) Arrangement.Start else Arrangement.Center
                                    ) {
                                        Icon(icon, contentDescription = label, tint = if (selected) Lime else Muted)
                                        if (largeLayout) Text(label, color = if (selected) Color.White else Muted, fontSize = 12.sp, modifier = Modifier.padding(start = 12.dp))
                                    }
                                }
                                Spacer(Modifier.weight(1f))
                                Text("NIU MOBILITY\nSTUDIO", color = Muted, fontSize = 9.sp, modifier = Modifier.padding(14.dp))
                            }
                        }
                        Box(Modifier.weight(1f).fillMaxHeight().padding(horizontal = if (wideLayout) 20.dp else 12.dp, vertical = 8.dp)) {
                            when (tab) {
                                0 -> Overview(PaddingValues(0.dp)) { navigate(7) }
                                13 -> if (!protectedToolsAvailable) ProtectedToolsDisabledScreen(PaddingValues(0.dp), onImported = { adminGrantRefresh++ }) else if (toolsUnlocked) WorkspaceIde(PaddingValues(0.dp), { openEditorFile.launch(arrayOf("text/*", "application/json", "application/xml", "application/octet-stream")) }, { saveEditorFile() }, { saveEditorFileAs() }, { createWorkspaceBackup.launch("NIU_Mobility_Studio_workspace_backup.zip") }) else SecureToolsGate(PaddingValues(0.dp)) { toolsUnlocked = true }
                                1 -> ScooterControl(PaddingValues(0.dp))
                                2 -> Profile(PaddingValues(0.dp))
                                3 -> SettingsHub(PaddingValues(0.dp)) { navigate(it) }
                                4 -> if (!protectedToolsAvailable) ProtectedToolsDisabledScreen(PaddingValues(0.dp), onImported = { adminGrantRefresh++ }) else if (toolsUnlocked) NrfExplorer(PaddingValues(0.dp)) else SecureToolsGate(PaddingValues(0.dp)) { toolsUnlocked = true }
                                5 -> if (!protectedToolsAvailable) ProtectedToolsDisabledScreen(PaddingValues(0.dp), onImported = { adminGrantRefresh++ }) else if (toolsUnlocked) NfcInspector(PaddingValues(0.dp)) else SecureToolsGate(PaddingValues(0.dp)) { toolsUnlocked = true }
                                6 -> if (!protectedToolsAvailable) ProtectedToolsDisabledScreen(PaddingValues(0.dp), onImported = { adminGrantRefresh++ }) else if (toolsUnlocked) Diagnostics(PaddingValues(0.dp)) else SecureToolsGate(PaddingValues(0.dp)) { toolsUnlocked = true }
                                8 -> DisplayStudio(PaddingValues(0.dp))
                                9 -> MusicStudio(PaddingValues(0.dp))
                                10 -> SoundStudio(PaddingValues(0.dp))
                                11 -> AboutAndChangelog(PaddingValues(0.dp))
                                12 -> if (!protectedToolsAvailable) ProtectedToolsDisabledScreen(PaddingValues(0.dp), onImported = { adminGrantRefresh++ }) else if (toolsUnlocked) NiuAiAssistant(PaddingValues(0.dp)) else SecureToolsGate(PaddingValues(0.dp)) { toolsUnlocked = true }
                                14 -> EventLogScreen(PaddingValues(0.dp))
                                15 -> if (!protectedToolsAvailable) ProtectedToolsDisabledScreen(PaddingValues(0.dp), onImported = { adminGrantRefresh++ }) else if (toolsUnlocked) MaintenanceJournal(PaddingValues(0.dp)) else SecureToolsGate(PaddingValues(0.dp)) { toolsUnlocked = true }
                                16 -> if (!protectedToolsAvailable) ProtectedToolsDisabledScreen(PaddingValues(0.dp), onImported = { adminGrantRefresh++ }) else if (toolsUnlocked) TelegramAndLocalServer(PaddingValues(0.dp)) else SecureToolsGate(PaddingValues(0.dp)) { toolsUnlocked = true }
                                17 -> DocumentationCenter(PaddingValues(0.dp))
                                18 -> AppearanceSettings(PaddingValues(0.dp))
                                19 -> if (!protectedToolsAvailable) ProtectedToolsDisabledScreen(PaddingValues(0.dp), onImported = { adminGrantRefresh++ }) else if (toolsUnlocked) SecureToolsHub(PaddingValues(0.dp), { route -> navigate(route) }, { toolsUnlocked = false; tab = 0; history.clear() }, { adminGrantRefresh++ }) else SecureToolsGate(PaddingValues(0.dp)) { toolsUnlocked = true }
                                20 -> if (!protectedToolsAvailable) ProtectedToolsDisabledScreen(PaddingValues(0.dp), onImported = { adminGrantRefresh++ }) else if (toolsUnlocked) ProtectedApkExportScreen(PaddingValues(0.dp)) else SecureToolsGate(PaddingValues(0.dp)) { toolsUnlocked = true }
                                                else -> if (tab in protectedRoutes && !protectedToolsAvailable) ProtectedToolsDisabledScreen(PaddingValues(0.dp), onImported = { adminGrantRefresh++ }) else if (tab in protectedRoutes && !toolsUnlocked) SecureToolsGate(PaddingValues(0.dp)) { toolsUnlocked = true } else Connection(PaddingValues(0.dp))
                            }
                        }
                    }
                }
                AnimatedVisibility(
                    visible = splashVisible,
                    modifier = Modifier.fillMaxSize(),
                    enter = fadeIn(animationSpec = tween(220)),
                    exit = fadeOut(animationSpec = tween(420))
                ) {
                    StartupSplash(Modifier.fillMaxSize())
                }
                activeHelp?.let { help ->
                    AlertDialog(
                        onDismissRequest = { activeHelp = null },
                        title = { Text(help.title) },
                        text = { Text(help.description, lineHeight = 20.sp) },
                        confirmButton = { TextButton(onClick = { activeHelp = null }) { Text("ПОНЯТНО") } },
                        containerColor = Panel,
                        titleContentColor = Color.White,
                        textContentColor = Color(0xFFE0E0E0)
                    )
                }
            }
        }
    }

    @Composable private fun StartupSplash(modifier: Modifier = Modifier) {
        val transition = rememberInfiniteTransition(label = "niu-splash")
        val pulse by transition.animateFloat(
            initialValue = 0.94f,
            targetValue = 1.04f,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = 900, easing = LinearEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "logo-pulse"
        )
        val orbit by transition.animateFloat(
            initialValue = 0f,
            targetValue = 360f,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = 2_800, easing = LinearEasing)
            ),
            label = "orbit-rotation"
        )
        Box(
            modifier = modifier.background(
                Brush.verticalGradient(listOf(Color(0xFF202020), Ink, Color(0xFF080808)))
            ),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.size(164.dp), contentAlignment = Alignment.Center) {
                    Box(
                        Modifier.fillMaxSize()
                            .graphicsLayer { rotationZ = orbit }
                            .padding(5.dp)
                            .border(1.dp, Lime.copy(alpha = 0.55f), CircleShape)
                    )
                    ComposeImage(
                        painter = painterResource(id = com.niu.fxstudio.R.drawable.niu_mobility_logo),
                        contentDescription = "Логотип NIU Mobility Studio",
                        modifier = Modifier.size(118.dp).graphicsLayer {
                            scaleX = pulse
                            scaleY = pulse
                        },
                        contentScale = ContentScale.Fit
                    )
                }
                Spacer(Modifier.height(24.dp))
                Text(
                    "NIU MOBILITY STUDIO",
                    color = Color.White,
                    fontSize = 19.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 2.2.sp
                )
                Spacer(Modifier.height(7.dp))
                Text(
                    "UNIVERSAL ELECTRIC MOBILITY TOOLKIT",
                    color = Muted,
                    fontSize = 9.sp,
                    letterSpacing = 1.4.sp
                )
                Spacer(Modifier.height(28.dp))
                CircularProgressIndicator(
                    modifier = Modifier.size(28.dp),
                    color = Lime,
                    strokeWidth = 2.5.dp
                )
                Spacer(Modifier.height(12.dp))
                Text("ЗАГРУЗКА ПРИЛОЖЕНИЯ", color = Muted, fontSize = 9.sp, letterSpacing = 1.2.sp)
                Spacer(Modifier.height(14.dp))
                Text("v${BuildConfig.VERSION_NAME}", color = Muted.copy(alpha = 0.72f), fontSize = 10.sp)
            }
        }
    }

    private fun exportNiuCloudTrace() {
        val entries = logs.toList().asReversed().filter { it.contains("NIU CLOUD", true) || it.contains("AUTH[", true) || it.contains("HTTP[", true) }
        pendingLogExportText = buildString {
            appendLine("NIU Mobility Studio ${BuildConfig.VERSION_NAME} — NIU Cloud diagnostic trace")
            appendLine("Export: ${java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())}")
            appendLine("Entries: ${entries.size}")
            appendLine("Secrets policy: passwords, password digests, tokens, cookies and signature values are redacted/not logged.")
            appendLine("=".repeat(72))
            entries.forEach(::appendLine)
        }
        exportLogsDocument.launch("NIU_Cloud_trace_${BuildConfig.VERSION_NAME}.txt")
        addLog("NIU CLOUD · diagnostic trace export requested · entries=${entries.size}")
    }

    private fun exportLogs(format: String) {
        val entries = logs.toList().asReversed()
        val body = when (format) {
            "md" -> buildString {
                appendLine("# NIU Mobility Studio — журнал событий")
                appendLine("\n- Версия: ${BuildConfig.VERSION_NAME}")
                appendLine("- Экспорт: ${java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())}")
                appendLine("\n## События\n")
                entries.forEach { appendLine("- `$it`") }
            }
            "json" -> org.json.JSONArray(entries.map { line ->
                val match = Regex("""^(.*?)  \[([^]]+)]\[([^]]+)] (.*)$""").find(line)
                org.json.JSONObject()
                    .put("timestamp", match?.groupValues?.get(1) ?: "")
                    .put("level", match?.groupValues?.get(2) ?: "INFO")
                    .put("category", match?.groupValues?.get(3) ?: "APP")
                    .put("message", match?.groupValues?.get(4) ?: line)
                    .put("app_version", BuildConfig.VERSION_NAME)
            }).toString(2)
            "csv" -> buildString {
                appendLine("timestamp,level,category,message")
                entries.forEach { line ->
                    val match = Regex("""^(.*?)  \[([^]]+)]\[([^]]+)] (.*)$""").find(line)
                    val fields = if (match != null) match.groupValues.drop(1) else listOf("", "INFO", "APP", line)
                    appendLine(fields.joinToString(",") { "\"${it.replace("\"", "\"\"")}\"" })
                }
            }
            else -> buildString {
                appendLine("NIU Mobility Studio ${BuildConfig.VERSION_NAME} — журнал событий")
                appendLine("Экспорт: ${java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())}")
                appendLine("=".repeat(64))
                entries.forEach(::appendLine)
            }
        }
        pendingLogExportText = body
        val extension = if (format == "md") "md" else format
        exportLogsDocument.launch("NIU_Mobility_Studio_logs.${extension}")
    }

    /** Copies a bounded, redacted Markdown report, then opens the user's chosen mdpaste site. */
    private fun copyDiagnosticLogAndOpenMdpaste() {
        val allEntries = logs.toList()
        val entries = allEntries.take(500).asReversed()
        val report = buildString {
            appendLine("# NIU Mobility Studio — diagnostic log")
            appendLine()
            appendLine("- App version: ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})")
            appendLine("- Android SDK: ${Build.VERSION.SDK_INT}")
            appendLine("- Exported: ${java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US).format(java.util.Date())}")
            appendLine("- Included events: ${entries.size}${if (allEntries.size > entries.size) " of ${allEntries.size} (newest 500)" else ""}")
            appendLine("- Privacy: credentials, tokens, account identifiers, e-mails, VIN/SN and Bluetooth addresses are redacted where recognized.")
            appendLine()
            appendLine("## Events")
            appendLine("```text")
            entries.forEach { appendLine(redactLogSecrets(it)) }
            appendLine("```")
        }
        val safeReport = redactLogSecrets(report).take(512 * 1024)
        runCatching {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("NIU Mobility Studio diagnostic log", safeReport))
        }.onFailure {
            addLog("MDPASTE ERROR: не удалось скопировать журнал · ${it.javaClass.simpleName}")
            Toast.makeText(this, "Не удалось скопировать журнал", Toast.LENGTH_LONG).show()
            return
        }
        addLog("MDPASTE: подготовлен безопасный Markdown-журнал · ${entries.size} событий · ${safeReport.length} символов")
        Toast.makeText(this, "Журнал скопирован. Вставьте его в форму mdpaste.ru и опубликуйте.", Toast.LENGTH_LONG).show()
        runCatching {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://mdpaste.ru/")))
        }.onFailure {
            addLog("MDPASTE ERROR: не удалось открыть mdpaste.ru · ${it.javaClass.simpleName}")
            Toast.makeText(this, "Сайт не открылся. Текст уже скопирован в буфер обмена.", Toast.LENGTH_LONG).show()
        }
    }

    @Composable private fun EventLogScreen(pad: PaddingValues) {
        val logListState = androidx.compose.foundation.lazy.rememberLazyListState()
        LaunchedEffect(logs.size, logFilter, logAutoScrollEnabled) {
            if (logAutoScrollEnabled && logs.isNotEmpty()) logListState.animateScrollToItem(0)
        }
        val visible = logs.filter { line ->
            when (logFilter) {
                "Ошибки" -> line.contains("error", true) || line.contains("ошиб", true) || line.contains("fail", true) || line.contains("fatal", true) || line.contains("timeout", true) || line.contains("exception", true)
                "BLE" -> line.contains("BLE", true) || line.contains("GATT", true)
                "NIU Cloud" -> line.contains("NIU CLOUD", true)
                else -> true
            }
        }
        Column(Modifier.fillMaxSize().padding(pad).padding(horizontal = 16.dp, vertical = 14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("События и ошибки", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    Text("${logs.size} записей · Cloud: ${logs.count { it.contains("NIU CLOUD", true) }} · ошибки: ${logs.count { it.contains("ERROR", true) || it.contains("ошиб", true) || it.contains("EXCEPTION", true) }}", color = Muted, fontSize = 10.sp)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { logs.clear(); addLog("Журнал очищен пользователем") }) { Text("Очистить") }
                    InfoIconButton("Очистить журнал", actionHelpDescription("ОЧИСТИТЬ ЖУРНАЛ"))
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                listOf("Все", "Ошибки", "BLE", "NIU Cloud").forEach { filter ->
                    FilterChip(selected = logFilter == filter, onClick = { logFilter = filter }, label = { Text(filter) })
                }
                InfoIconButton("Фильтры журнала", "«Все» показывает каждую запись; «Ошибки» оставляет сообщения об ошибках и исключениях; «BLE» показывает Bluetooth/GATT; «NIU Cloud» показывает облачную авторизацию и API. Фильтр не удаляет записи.")
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                FilterChip(selected = logAutoScrollEnabled, onClick = { logAutoScrollEnabled = !logAutoScrollEnabled }, label = { Text(if (logAutoScrollEnabled) "Автопрокрутка ВКЛ" else "Автопрокрутка ВЫКЛ") })
                FilterChip(selected = persistentLoggingEnabled, onClick = {
                    persistentLoggingEnabled = !persistentLoggingEnabled
                    getSharedPreferences("niu_diagnostics", MODE_PRIVATE).edit().putBoolean("persistent_logging", persistentLoggingEnabled).apply()
                    addLog(if (persistentLoggingEnabled) "LOGGING · постоянная запись включена" else "LOGGING · временная запись включена; новые события не сохраняются после закрытия")
                }, label = { Text(if (persistentLoggingEnabled) "Постоянный лог" else "Временный лог") })
            }
            Spacer(Modifier.height(8.dp))
            Text("СОХРАНИТЬ ЖУРНАЛ", color = Muted, fontSize = 10.sp, letterSpacing = 1.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.fillMaxWidth()) {
                listOf("TXT", "MD", "JSON", "CSV").forEach { format ->
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        OutlinedButton(onClick = { exportLogs(format.lowercase()) }, modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(horizontal = 3.dp, vertical = 8.dp)) {
                            Text(format, fontSize = 11.sp)
                        }
                        InfoIconButton("Экспорт $format", "Формирует файл журнала в формате $format и открывает системное окно Android для выбора места сохранения. Перед передачей проверьте содержимое файла.")
                    }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(
                    onClick = { showMdpasteConfirm = true },
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 10.dp)
                ) { Text("СКОПИРОВАТЬ И ОТКРЫТЬ MDPASTE.RU", fontSize = 11.sp) }
                InfoIconButton("Подготовить журнал для mdpaste.ru", actionHelpDescription("MDPASTE"))
            }
            Text(
                "Текст копируется в буфер обмена; приложение откроет сайт. Вставьте журнал в форму и отправьте вручную. Перед публикацией проверьте содержимое.",
                color = Muted, fontSize = 10.sp, lineHeight = 14.sp
            )
            Spacer(Modifier.height(10.dp))
            if (visible.isEmpty()) {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { Text("Записей пока нет", color = Muted) }
            } else LazyColumn(state = logListState, modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(visible) { line ->
                    val isError = line.contains("error", true) || line.contains("ошиб", true) || line.contains("fail", true) || line.contains("fatal", true) || line.contains("timeout", true)
                    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(10.dp)).padding(10.dp), verticalAlignment = Alignment.Top) {
                        Box(Modifier.padding(top = 4.dp).size(7.dp).background(if (isError) Color(0xFFFF6B6B) else Lime, CircleShape))
                        Text(line, color = if (isError) Color(0xFFFFB4B4) else Color(0xFFD5D5D5), fontSize = 11.sp, lineHeight = 16.sp, modifier = Modifier.padding(start = 9.dp))
                    }
                }
            }
            val crash = getSharedPreferences("niu_crash_log", MODE_PRIVATE).getString("last_crash", null)
            if (crash != null) Text("Последний аварийный отчёт сохранён локально. Он добавляется в журнал при следующем запуске.", color = Color(0xFFFFC66D), fontSize = 10.sp, modifier = Modifier.padding(top = 8.dp))
        }
        if (showMdpasteConfirm) {
            AlertDialog(
                onDismissRequest = { showMdpasteConfirm = false },
                title = { Text("Подготовить журнал для mdpaste.ru?") },
                text = { Text("Будут скопированы последние 500 событий в Markdown. Известные пароли, токены, данные аккаунта, e-mail, VIN/SN и Bluetooth-адреса маскируются. После вставки на mdpaste.ru опубликованный текст может стать доступен другим людям. Не включайте в него личные или конфиденциальные данные.") },
                confirmButton = {
                    TextButton(onClick = {
                        showMdpasteConfirm = false
                        copyDiagnosticLogAndOpenMdpaste()
                    }) { Text("Скопировать и открыть") }
                },
                dismissButton = {
                    TextButton(onClick = { showMdpasteConfirm = false }) { Text("Отмена") }
                }
            )
        }
    }

    @Composable private fun DisplayStudio(pad: PaddingValues) {
        val accents = listOf(Color(0xFFE53935), Color(0xFF42A5F5), Color(0xFF66BB6A), Color(0xFFFFCA28), Color(0xFFAB47BC), Color.White)
        LazyColumn(Modifier.fillMaxSize().padding(pad), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item { PageHeader("DASHBOARD PERSONALIZATION", "Дисплей и обои") }
            item {
                CardBlock {
                    Text("ПРЕДПРОСМОТР ПРИБОРНОЙ ПАНЕЛИ", color = Lime, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Box(Modifier.fillMaxWidth().height(205.dp).background(Color(0xFF080B0D), RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
                        val bitmap = wallpaperBitmap
                        if (bitmap != null) androidx.compose.foundation.Image(bitmap.asImageBitmap(), contentDescription = "Предпросмотр обоев", modifier = Modifier.fillMaxSize().graphicsLayer(scaleX = wallpaperZoom, scaleY = wallpaperZoom), contentScale = ContentScale.Crop)
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text("${if (wallpaperBitmap != null) "FX WIND STRIKE" else "NIU FX"}", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text("00", color = accents[wallpaperAccent], fontSize = 48.sp, fontWeight = FontWeight.Black)
                            Text("km/h", color = Color.White, fontSize = 10.sp)
                            Text("ECO     SPORT     BOOST", color = accents[wallpaperAccent], fontSize = 9.sp)
                        }
                        Box(Modifier.fillMaxSize().padding(5.dp).background(Color.Transparent, RoundedCornerShape(14.dp)))
                    }
                    Text(if (wallpaperUri != null) "Выбрано: ${wallpaperUri?.lastPathSegment?.takeLast(42)}" else "Выберите фотографию или изображение для локального предпросмотра", color = Muted, fontSize = 11.sp)
                    PrimaryButton("ВЫБРАТЬ ИЗОБРАЖЕНИЕ") { openWallpaper.launch(arrayOf("image/*")) }
                    Text("МАСШТАБ / ОБРЕЗКА · ${(wallpaperZoom * 100).toInt()}%", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Slider(value = wallpaperZoom, onValueChange = { wallpaperZoom = it; wallpaperSaved = false }, valueRange = 1f..2.5f)
                }
            }
            item {
                CardBlock {
                    Text("ЦВЕТ АКЦЕНТА", color = Lime, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        accents.forEachIndexed { index, color ->
                            Box(Modifier.size(34.dp).background(color, CircleShape).clickable { wallpaperAccent = index; wallpaperSaved = false }.padding(3.dp), contentAlignment = Alignment.Center) {
                                if (wallpaperAccent == index) Text("✓", color = Color.Black, fontWeight = FontWeight.Black)
                            }
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedButton(onClick = { wallpaperSaved = true; getSharedPreferences("fx_display", MODE_PRIVATE).edit().putString("wallpaper_uri", wallpaperUri?.toString()).putInt("accent", wallpaperAccent).putFloat("zoom", wallpaperZoom).apply(); addLog("DISPLAY preset saved locally; not uploaded to scooter") }, enabled = wallpaperUri != null, modifier = Modifier.weight(1f)) { Text(if (wallpaperSaved) "ЛОКАЛЬНЫЙ ПРОФИЛЬ СОХРАНЁН" else "СОХРАНИТЬ ЛОКАЛЬНЫЙ ПРОФИЛЬ") }
                        InfoIconButton("Сохранить профиль дисплея", "Сохраняет выбранную картинку, масштаб и цветовой акцент только в локальных настройках телефона. Обои не загружаются в приборную панель NIU.")
                    }
                }
            }
            item {
                CardBlock {
                    Text("ПЕРЕДАЧА НА ПРИБОРНУЮ ПАНЕЛЬ", color = Color(0xFFFFC66D), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text("Оригинальная FX поддерживает персональные обои. Но BLE-отчёты пока не раскрывают протокол передачи изображения. Кнопка загрузки появится после определения канала, формата файла, разбиения на пакеты и подтверждения приёма приборкой.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
                    Text("Статус: локальный выбор и предпросмотр работают · отправка в скутер пока не активна", color = Color(0xFFFFC66D), fontSize = 11.sp)
                }
            }
            item { Text("По найденным материалам FX: Vehicle Settings → Instrument → Custom Wallpaper. После сохранения оригинальное приложение просит повернуть Magic Wheel для применения/калибровки.", color = Muted, fontSize = 11.sp, lineHeight = 16.sp) }
        }
    }

    @Composable private fun MusicStudio(pad: PaddingValues) {
        LazyColumn(Modifier.fillMaxSize().padding(pad), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item { PageHeader("BLUETOOTH AUDIO", "Музыка") }
            item {
                CardBlock {
                    Icon(Icons.Default.MusicNote, null, tint = Lime, modifier = Modifier.size(34.dp))
                    Text(musicTitle, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text("Источник: файл на телефоне", color = Muted, fontSize = 11.sp)
                    Text(if (musicUris.isEmpty()) "Плейлист пуст" else "Трек ${musicIndex + 1} из ${musicUris.size}", color = Muted, fontSize = 10.sp)
                    PrimaryButton("ВЫБРАТЬ МУЗЫКУ / ПЛЕЙЛИСТ") { openMusic.launch(arrayOf("audio/*")) }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                            OutlinedButton(onClick = { previousMusic() }, enabled = musicUris.size > 1, modifier = Modifier.fillMaxWidth()) { Text("ПРЕДЫДУЩИЙ", fontSize = 9.sp) }
                            InfoIconButton("Предыдущий трек", actionHelpDescription("ПРЕДЫДУЩИЙ"))
                        }
                        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                            OutlinedButton(onClick = { toggleMusicPlayback() }, enabled = musicUri != null, modifier = Modifier.fillMaxWidth()) { Text(if (musicPlaying) "ПАУЗА" else "PLAY") }
                            InfoIconButton("Воспроизведение / пауза", actionHelpDescription("PLAY / ПАУЗА"))
                        }
                        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                            OutlinedButton(onClick = { nextMusic() }, enabled = musicUris.size > 1, modifier = Modifier.fillMaxWidth()) { Text("СЛЕДУЮЩИЙ", fontSize = 9.sp) }
                            InfoIconButton("Следующий трек", actionHelpDescription("СЛЕДУЮЩИЙ"))
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedButton(onClick = { runCatching { mediaPlayer?.pause(); mediaPlayer?.seekTo(0); musicPlaying = false } }, enabled = musicUri != null, modifier = Modifier.weight(1f)) { Text("СТОП / С НАЧАЛА") }
                        InfoIconButton("Остановить и перемотать", "Останавливает воспроизведение выбранного файла и перематывает его в начало. Трек остаётся выбранным.")
                    }
                    Text("Громкость приложения · ${(musicVolume * 100).toInt()}%", color = Muted, fontSize = 11.sp)
                    Slider(value = musicVolume, onValueChange = { musicVolume = it; mediaPlayer?.setVolume(it, it) })
                }
            }
            item {
                CardBlock {
                    Text("АУДИОВЫХОД", color = Lime, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text("Android направляет звук на активное Bluetooth Audio-устройство (A2DP), если скутер поддерживает и объявляет этот профиль. NIU Link BLE и Bluetooth Audio — разные соединения.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
                    Text(audioOutputSummary, color = Color.White, fontSize = 11.sp, lineHeight = 16.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedButton(onClick = { refreshAudioOutputs() }, modifier = Modifier.weight(1f)) { Text("ПРОВЕРИТЬ АУДИОВЫХОДЫ ANDROID") }
                        InfoIconButton("Проверить аудиовыходы", actionHelpDescription("ПРОВЕРИТЬ АУДИОВЫХОДЫ"))
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedButton(onClick = { runCatching { startActivity(Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS)) }.onFailure { addLog("Не удалось открыть Bluetooth Settings") } }, modifier = Modifier.weight(1f)) { Text("ОТКРЫТЬ НАСТРОЙКИ BLUETOOTH") }
                        InfoIconButton("Настройки Bluetooth", actionHelpDescription("ОТКРЫТЬ НАСТРОЙКИ BLUETOOTH"))
                    }
                }
            }
            item {
                CardBlock {
                    Text("СТАТУС", color = Color(0xFFFFC66D), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text("Локальный аудиоплеер реализован. Факт вывода именно на динамик FX зависит от наличия A2DP-профиля в скутере. GATT-отчёт его не показывает, потому что A2DP не является GATT-сервисом.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
                }
            }
        }
    }

    @Composable private fun SoundStudio(pad: PaddingValues) {
        val themes = listOf("Вариант 1", "Вариант 2", "Вариант 3")
        LazyColumn(Modifier.fillMaxSize().padding(pad), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item { PageHeader("RIDE SOUND", "Звуковые эффекты") }
            item {
                CardBlock {
                    Text("ТЕМЫ ЗВУКА", color = Lime, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text("В материалах дилера FX подтверждены три варианта звука, но их официальные названия и параметры пока не установлены. Здесь можно сохранить локальный выбор; отправка настройки в скутер требует подтверждения протокола.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
                    themes.forEach { theme ->
                        Row(Modifier.fillMaxWidth().clickable { soundTheme = theme }.padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = soundTheme == theme, onClick = { soundTheme = theme })
                            Text(theme, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                    Text("Выбрано: $soundTheme", color = Lime, fontSize = 11.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedButton(onClick = { getSharedPreferences("fx_sound", MODE_PRIVATE).edit().putString("theme", soundTheme).apply(); addLog("SOUND theme saved locally · $soundTheme") }, modifier = Modifier.weight(1f)) { Text("СОХРАНИТЬ ЛОКАЛЬНЫЙ ПРОФИЛЬ") }
                        InfoIconButton("Сохранить звуковую тему", "Сохраняет выбранную тему звукового профиля локально на телефоне. Не меняет звук или настройки ECU скутера.")
                    }
                }
            }
            item {
                CardBlock {
                    Text("СОБСТВЕННЫЙ ЗВУК", color = Lime, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text(soundTitle, color = Color.White, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    PrimaryButton("ВЫБРАТЬ АУДИО / ВИДЕО") { openSound.launch(arrayOf("audio/*", "video/*")) }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedButton(onClick = { soundUri?.let { prepareAudio(it, start = true) } ?: addLog("SOUND: сначала выберите файл") }, enabled = soundUri != null, modifier = Modifier.weight(1f)) { Text("ПРОСЛУШАТЬ") }
                        InfoIconButton("Прослушать выбранный звук", "Воспроизводит выбранный аудиофайл через Android-плеер. Файл не отправляется на скутер.")
                    }
                    Text("НАЗНАЧИТЬ СОБЫТИЕ", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
                        listOf("POWER_ON", "POWER_OFF", "ALARM").forEach { event ->
                            FilterChip(selected = soundEvent == event, onClick = { soundEvent = event }, label = { Text(event, fontSize = 9.sp) })
                        }
                        InfoIconButton("Событие звука", "Выбирает локальный триггер профиля: POWER_ON — включение, POWER_OFF — выключение, ALARM — сигнализация. Выбор хранится в настройках приложения; не является командой скутеру.")
                    }
                    Text("ЧАСТОТА СРАБАТЫВАНИЯ", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
                        listOf("ONCE", "DAILY", "WEEKLY", "MONTHLY").forEach { trigger ->
                            FilterChip(selected = soundTrigger == trigger, onClick = { soundTrigger = trigger }, label = { Text(trigger, fontSize = 9.sp) })
                        }
                        InfoIconButton("Периодичность", "Выбирает повторение локального напоминания/звукового назначения: ONCE — один раз, DAILY — ежедневно, WEEKLY — еженедельно, MONTHLY — ежемесячно. Не является расписанием ECU.")
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedButton(onClick = { getSharedPreferences("fx_sound", MODE_PRIVATE).edit().putString("custom_uri", soundUri?.toString()).putString("event", soundEvent).putString("trigger", soundTrigger).apply(); addLog("SOUND profile saved locally · $soundEvent / $soundTrigger; not sent to scooter") }, enabled = soundUri != null, modifier = Modifier.weight(1f)) { Text("СОХРАНИТЬ НАЗНАЧЕНИЕ ЛОКАЛЬНО") }
                        InfoIconButton("Сохранить назначение звука", "Сохраняет ссылку на выбранный файл, событие и режим срабатывания в приложении. Это локальная запись, она не передаётся NIU.")
                    }
                    Text("Импорт, предпрослушивание и локальное сохранение профиля работают. Назначение на события и загрузка в FX пока ожидают протокол.", color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
                }
            }
        }
    }

    private fun saveEditorFile() {
        val uri = editorFileUri
        if (uri == null) { saveEditorFileAs(); return }
        runCatching {
            contentResolver.openOutputStream(uri, "wt")?.bufferedWriter(Charsets.UTF_8)?.use { it.write(editorText) }
                ?: error("Нет разрешения на запись")
            editorDirty = false
            editorStatus = "Сохранено: $editorFileName"
            addLog("WORKSPACE: saved $editorFileName")
        }.onFailure { editorStatus = "Ошибка сохранения: ${it.message}"; addLog("WORKSPACE save error: ${it.message}") }
    }

    private fun saveEditorFileAs() {
        pendingEditorSave = editorText
        createEditorFile.launch(editorFileName.takeIf { it.isNotBlank() && it != "Новый файл" } ?: "MainActivity.kt")
    }

    @Composable private fun WorkspaceIde(
        pad: PaddingValues,
        openFile: () -> Unit,
        save: () -> Unit,
        saveAs: () -> Unit,
        backup: () -> Unit
    ) {
        val context = LocalContext.current
        val secretStore = remember { SecureSecretStore(context.getSharedPreferences("niu_secure_secrets", MODE_PRIVATE)) }
        // Local multi-file workspace. Files remain inside app-private storage unless explicitly exported.
        val projectDir = remember { File(context.filesDir, "niu-workspace").apply { mkdirs() } }
        val projectFiles = remember { mutableStateListOf<File>() }
        val openTabs = remember { mutableStateListOf<File>() }
        var selectedProjectFile by remember { mutableStateOf<File?>(null) }
        var newProjectFileName by remember { mutableStateOf("NewFile.kt") }
        var projectMessage by remember { mutableStateOf("Локальный проект готов") }
        fun refreshProjectFiles() {
            projectFiles.clear()
            projectFiles.addAll(projectDir.walkTopDown().filter { file -> file.isFile && (file.extension.lowercase() in setOf("kt", "kts", "java", "xml", "json", "md", "txt", "gradle", "properties", "yml", "yaml", "sh", "bat", "toml", "pro", "cfg") || file.name in setOf("gradlew", ".gitignore", ".editorconfig")) }.sortedBy { it.relativeTo(projectDir).path }.toList())
        }
        fun openProjectFile(file: File) {
            runCatching {
                require(file.canonicalPath.startsWith(projectDir.canonicalPath + File.separator)) { "Недопустимый путь" }
                editorText = file.readText(Charsets.UTF_8)
                editorFileName = file.relativeTo(projectDir).path
                editorDirty = false
                selectedProjectFile = file
                if (!openTabs.contains(file)) openTabs.add(file)
                editorStatus = "Открыт локальный файл: ${file.name}"
                projectMessage = "Открыт ${file.relativeTo(projectDir).path}"
            }.onFailure { projectMessage = "Ошибка открытия: ${it.message}" }
        }
        fun saveProjectFile() {
            val file = selectedProjectFile
            if (file == null) { projectMessage = "Сначала выберите файл проекта"; return }
            runCatching {
                require(file.canonicalPath.startsWith(projectDir.canonicalPath + File.separator)) { "Недопустимый путь" }
                file.parentFile?.mkdirs()
                file.writeText(editorText, Charsets.UTF_8)
                editorDirty = false
                editorStatus = "Сохранено: ${file.name}"
                projectMessage = "Сохранено ${file.relativeTo(projectDir).path}"
                refreshProjectFiles()
            }.onFailure { projectMessage = "Ошибка сохранения: ${it.message}" }
        }
        LaunchedEffect(Unit) {
            if (projectDir.listFiles()?.isEmpty() != false) {
                File(projectDir, "README.md").writeText("# NIU Mobility Studio Workspace\n\nЛокальный проект. Добавляйте сюда исходники и документацию.\n", Charsets.UTF_8)
                File(projectDir, "Main.kt").writeText("// NIU Mobility Studio v3 workspace\nfun main() {\n    println(\"Hello, NIU\")\n}\n", Charsets.UTF_8)
            }
            refreshProjectFiles()
        }
        val workspaceScope = rememberCoroutineScope()
        val buildPrefs = remember { context.getSharedPreferences("niu_build_settings", MODE_PRIVATE) }
        var githubRepo by remember { mutableStateOf(buildPrefs.getString("repo", "") ?: "") }
        var githubOAuthClientId by remember { mutableStateOf(buildPrefs.getString("oauth_client_id", "") ?: "") }
        var githubUser by remember { mutableStateOf(if (secretStore.get("github_actions_token").isNullOrBlank()) "" else (buildPrefs.getString("github_user", "") ?: "")) }
        var githubUserCode by remember { mutableStateOf("") }
        var githubDeviceCode by remember { mutableStateOf("") }
        var githubVerificationUri by remember { mutableStateOf("https://github.com/login/device") }
        var githubDeviceInterval by remember { mutableIntStateOf(5) }
        var githubDeviceExpiresAt by remember { mutableLongStateOf(0L) }
        var githubRepos by remember { mutableStateOf(emptyList<GitHubBuildClient.Repository>()) }
        var githubBranch by remember { mutableStateOf("main") }
        var githubBranches by remember { mutableStateOf(emptyList<String>()) }
        var githubNewRepoName by remember { mutableStateOf("NIU-Mobility-Studio") }
        var buildStatus by remember { mutableStateOf("Репозиторий не подключён") }
        var buildConclusion by remember { mutableStateOf<String?>(null) }
        var buildBusy by remember { mutableStateOf(false) }
        var buildArtifactName by remember { mutableStateOf("niu-user-debug-apk") }
        var artifactMenuExpanded by remember { mutableStateOf(false) }
        LazyColumn(
            Modifier.fillMaxSize().padding(pad),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 18.dp, bottom = 30.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { PageHeader("NIU MOBILITY · CODE WORKSPACE", "Редактор проекта") }
            item {
                CardBlock {
                    Text("PROJECT EXPLORER · ЛОКАЛЬНЫЙ ПРОЕКТ", color = Lime, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text("Файлы хранятся в приватном каталоге приложения. Поддерживаются вкладки и редактирование текстовых исходников.", color = Muted, fontSize = 10.sp, lineHeight = 15.sp)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                            OutlinedButton(onClick = { importSourceProject.launch(arrayOf("application/zip", "application/octet-stream")) }, modifier = Modifier.fillMaxWidth()) { Text("ИМПОРТ ZIP", fontSize = 10.sp) }
                            InfoIconButton("Импорт ZIP", "Открывает системный выбор ZIP-архива и импортирует исходный проект в приватный каталог Workspace. Существующие файлы с совпадающими именами могут быть заменены — проверьте содержимое архива.")
                        }
                        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                            OutlinedButton(onClick = { exportSourceProject.launch("NIU_Mobility_Studio_1.0.0_source.zip") }, modifier = Modifier.fillMaxWidth()) { Text("ЭКСПОРТ ПРОЕКТА", fontSize = 10.sp) }
                            InfoIconButton("Экспорт проекта ZIP", "Создаёт ZIP-архив файлов локального Workspace и открывает системное сохранение. Экспорт не публикует проект в GitHub.")
                        }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(value = newProjectFileName, onValueChange = { newProjectFileName = it }, modifier = Modifier.weight(1f), singleLine = true, label = { Text("Имя файла") })
                        Button(onClick = {
                            val safeName = newProjectFileName.trim().replace('\\', '_').replace('/', '_')
                            if (safeName.isBlank() || safeName.startsWith('.')) projectMessage = "Укажите безопасное имя файла"
                            else runCatching {
                                val file = File(projectDir, safeName)
                                require(file.canonicalPath.startsWith(projectDir.canonicalPath + File.separator))
                                if (!file.exists()) file.writeText("", Charsets.UTF_8)
                                refreshProjectFiles(); openProjectFile(file)
                            }.onFailure { projectMessage = "Не удалось создать файл: ${it.message}" }
                        }, colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = Color.White)) { Text("СОЗДАТЬ") }
                        InfoIconButton("Создать файл проекта", "Создаёт новый пустой файл с указанным безопасным именем в локальном Workspace и открывает его в редакторе.")
                    }
                    if (openTabs.isNotEmpty()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("OPEN TABS", color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            InfoIconButton("Открытые вкладки", "Переключает активный документ в редакторе. Открытие вкладки не сохраняет изменения автоматически; перед закрытием сохраните изменённые файлы.")
                        }
                        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            openTabs.toList().forEach { file ->
                                FilterChip(selected = selectedProjectFile == file, onClick = { openProjectFile(file) }, label = { Text(file.name, fontSize = 10.sp) })
                            }
                        }
                    }
                    Text("PROJECT FILES · ${projectFiles.size}", color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    projectFiles.forEach { file ->
                        Row(Modifier.fillMaxWidth().clickable { openProjectFile(file) }.padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(if (selectedProjectFile == file) "●" else "○", color = Lime, fontSize = 12.sp)
                            Text(file.relativeTo(projectDir).path, color = Color.White, fontSize = 11.sp, modifier = Modifier.weight(1f).padding(start = 8.dp))
                            Text("${file.length()} B", color = Muted, fontSize = 9.sp)
                        }
                    }
                    Text(projectMessage, color = Muted, fontSize = 10.sp)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                            OutlinedButton(onClick = { refreshProjectFiles(); projectMessage = "Список файлов обновлён" }, modifier = Modifier.fillMaxWidth()) { Text("ОБНОВИТЬ") }
                            InfoIconButton("Обновить список проекта", "Повторно сканирует локальный каталог Workspace и обновляет список файлов на экране.")
                        }
                        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                            Button(onClick = { saveProjectFile() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = Color.White), enabled = selectedProjectFile != null) { Text("СОХРАНИТЬ ФАЙЛ") }
                            InfoIconButton("Сохранить файл проекта", "Сохраняет выбранный файл проекта из активной вкладки/редактора. Кнопка недоступна, когда файл не выбран.")
                        }
                    }
                }
            }
            item {
                CardBlock {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                            Button(onClick = openFile, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = Color.White)) { Text("ОТКРЫТЬ ФАЙЛ", fontSize = 10.sp) }
                            InfoIconButton("Открыть файл", actionHelpDescription("ОТКРЫТЬ ФАЙЛ"))
                        }
                        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                            OutlinedButton(onClick = save, modifier = Modifier.fillMaxWidth()) { Text("СОХРАНИТЬ", fontSize = 10.sp) }
                            InfoIconButton("Сохранить", "Записывает текущий текст в открытый документ. При первом сохранении используйте «Сохранить как».")
                        }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                            OutlinedButton(onClick = saveAs, modifier = Modifier.fillMaxWidth()) { Text("СОХРАНИТЬ КАК", fontSize = 10.sp) }
                            InfoIconButton("Сохранить как", "Открывает системное сохранение документа и позволяет выбрать имя/место для текущего текста.")
                        }
                        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                            OutlinedButton(onClick = backup, modifier = Modifier.fillMaxWidth()) { Text("ZIP BACKUP", fontSize = 10.sp) }
                            InfoIconButton("ZIP backup", "Создаёт резервную копию локального Workspace в ZIP. Используйте перед массовым редактированием или импортом файлов.")
                        }
                    }
                    Text("${editorFileName}${if (editorDirty) " · ИЗМЕНЁН" else ""}", color = Lime, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text(editorStatus, color = Muted, fontSize = 10.sp)
                }
            }
            item {
                CardBlock {
                    Text("EDITOR · TEXT / KOTLIN / JSON / XML", color = Lime, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Box(Modifier.fillMaxWidth().heightIn(min = 300.dp, max = 620.dp).background(Color(0xFF101820), RoundedCornerShape(12.dp)).padding(12.dp).verticalScroll(rememberScrollState())) {
                        BasicTextField(
                            value = editorText,
                            onValueChange = { editorText = it; editorDirty = true },
                            modifier = Modifier.fillMaxWidth(),
                            textStyle = androidx.compose.ui.text.TextStyle(color = Color(0xFFE4EAF0), fontSize = 12.sp, lineHeight = 18.sp)
                        )
                    }
                    Text("Редактор поддерживает локальные файлы проекта и документы Android Storage Access Framework. Подсветка синтаксиса и полноценное дерево каталогов с вложенной навигацией не входят в этот редактор.", color = Muted, fontSize = 10.sp, lineHeight = 15.sp)
                }
            }
            item {
                CardBlock {
                    Text("NIU AI · ВХОД ПО КНОПКЕ", color = Lime, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text("Войти в ChatGPT", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text("Авторизация проходит на официальной стороне ChatGPT. NIU Mobility Studio не получает пароль или сессионный токен и не выдаёт вход на сайт за API-доступ. У OpenAI нет публичного универсального OAuth-входа, который позволял бы стороннему Android-приложению использовать подписку ChatGPT как API.", color = Muted, fontSize = 10.sp, lineHeight = 15.sp)
                    Button(onClick = {
                        runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://chatgpt.com/auth/login"))) }
                            .onFailure { addLog("Не удалось открыть страницу входа ChatGPT: ${it.message}") }
                    }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = Color.White), shape = RoundedCornerShape(13.dp)) {
                        Text("ВОЙТИ В CHATGPT", fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(onClick = {
                        val file = selectedProjectFile
                        val handoff = buildString {
                            appendLine("Проект: NIU Mobility Studio ${BuildConfig.VERSION_NAME}")
                            appendLine("Задача: проверь этот код на ошибки и предложи исправления. Не выдумывай неподтверждённые BLE-команды NIU FX.")
                            appendLine("Файл: ${file?.relativeTo(projectDir)?.path ?: editorFileName}")
                            appendLine("--- SOURCE ---")
                            append(editorText.take(120_000))
                        }
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_SUBJECT, "NIU Mobility Studio — проверка исходника")
                            putExtra(Intent.EXTRA_TEXT, handoff)
                        }
                        runCatching { startActivity(Intent.createChooser(send, "Передать исходник в ChatGPT или другой AI")) }
                            .onFailure { addLog("Не удалось передать исходник AI: ${it.message}") }
                    }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(13.dp)) {
                        Text("ПЕРЕДАТЬ ОТКРЫТЫЙ ФАЙЛ В AI")
                    }
                    Text("Важно: это безопасная передача по явному действию пользователя, а не скрытая интеграция. Для полноценного встроенного AI-анализа без API-ключей нужен собственный backend с OAuth-входом и серверной авторизацией; такого сервера у проекта пока нет.", color = Color(0xFFFFC66D), fontSize = 10.sp, lineHeight = 15.sp)
                }
            }
            item {
                CardBlock {
                    Text("ЕДИНЫЙ ЦЕНТР УПРАВЛЕНИЯ · GITHUB ACTIONS", color = Lime, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    if (!BuildConfig.IS_USER_BUILD) {
                        OutlinedButton(
                            onClick = { com.niu.fxstudio.admin.AdminConsoleEntry.open(this@MainActivity) },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("АДМИНИСТРИРОВАНИЕ · КЛЮЧИ · ДОСТУПЫ") }
                    }
                    Text("Сборка, администрирование, разрешения и получение APK объединены в одном приложении. Сборка выполняется на GitHub Actions; отдельное приложение Admin больше не требуется.", color = Muted, fontSize = 10.sp, lineHeight = 15.sp)
                    Text("Реальная сборка выполняется на GitHub runner из опубликованного репозитория. После сборки приложение может скачать APK и передать его системному установщику Android.", color = Muted, fontSize = 10.sp, lineHeight = 15.sp)
                    Box {
                        OutlinedButton(onClick = { artifactMenuExpanded = true }, enabled = !buildBusy, modifier = Modifier.fillMaxWidth()) { Text("АРТЕФАКТ: ${when (buildArtifactName) { "niu-full-debug-apk" -> "FULL APK"; else -> "USER APK" }}") }
                        DropdownMenu(expanded = artifactMenuExpanded, onDismissRequest = { artifactMenuExpanded = false }) {
                            listOf("niu-user-debug-apk" to "USER APK", "niu-full-debug-apk" to "FULL APK").forEach { (id, label) ->
                                DropdownMenuItem(text = { Text(label) }, onClick = { buildArtifactName = id; artifactMenuExpanded = false })
                            }
                        }
                    }
                    Text(if (githubUser.isBlank()) "GitHub не подключён" else "Авторизован: @$githubUser", color = if (githubUser.isBlank()) Muted else Lime, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    OutlinedTextField(value = githubOAuthClientId, onValueChange = { githubOAuthClientId = it.trim() }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("GitHub OAuth App · публичный Client ID") }, placeholder = { Text("20-символьный Client ID") })
                    Text("Client ID — публичный идентификатор зарегистрированного OAuth App, не пароль и не токен. Владелец приложения задаёт его один раз; после этого вход запускается кнопкой и подтверждается на github.com.", color = Muted, fontSize = 10.sp, lineHeight = 14.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {
                            buildBusy = true; buildStatus = "Запрос кода авторизации GitHub…"
                            workspaceScope.launch {
                                runCatching { withContext(Dispatchers.IO) { GitHubOAuthDeviceFlow.begin(githubOAuthClientId) } }
                                    .onSuccess { session ->
                                        githubDeviceCode = session.deviceCode; githubUserCode = session.userCode
                                        githubVerificationUri = session.verificationUri; githubDeviceInterval = session.interval
                                        githubDeviceExpiresAt = System.currentTimeMillis() + session.expiresIn * 1000L
                                        buildPrefs.edit().putString("oauth_client_id", githubOAuthClientId).apply()
                                        buildStatus = "Открываем официальный GitHub для подтверждения входа"
                                        runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(githubVerificationUri))) }
                                            .onFailure { buildStatus = "Код создан. Откройте GitHub вручную и введите код ниже." }
                                    }.onFailure { buildStatus = it.message ?: "Не удалось начать авторизацию" }
                                buildBusy = false
                            }
                        }, enabled = !buildBusy && githubOAuthClientId.isNotBlank(), modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = Color.White)) { Text("ВОЙТИ ЧЕРЕЗ GITHUB") }
                        OutlinedButton(onClick = {
                            if (githubDeviceCode.isBlank()) buildStatus = "Сначала запросите код авторизации"
                            else context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(githubVerificationUri)))
                        }, enabled = githubDeviceCode.isNotBlank(), modifier = Modifier.weight(1f)) { Text("ОТКРЫТЬ GITHUB") }
                    }
                    if (githubUserCode.isNotBlank()) {
                        CardBlock {
                            Text("КОД АВТОРИЗАЦИИ", color = Lime, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            Text(githubUserCode, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Black)
                            Text("Введите этот код на github.com/login/device. Действует ограниченное время.", color = Muted, fontSize = 10.sp)
                            OutlinedButton(onClick = {
                                if (System.currentTimeMillis() > githubDeviceExpiresAt) { githubUserCode = ""; githubDeviceCode = ""; buildStatus = "Код истёк. Запросите новый." }
                                else {
                                    buildBusy = true
                                    workspaceScope.launch {
                                        runCatching { withContext(Dispatchers.IO) { GitHubOAuthDeviceFlow.poll(githubOAuthClientId, githubDeviceCode) } }
                                            .onSuccess { result -> when (result) {
                                                is GitHubOAuthDeviceFlow.PollResult.Authorized -> {
                                                    secretStore.put("github_actions_token", result.accessToken)
                                                    githubUser = withContext(Dispatchers.IO) { GitHubBuildClient.authenticatedUser(result.accessToken) }
                                                    githubRepos = withContext(Dispatchers.IO) { GitHubBuildClient.listRepositories(result.accessToken) }
                                                    buildPrefs.edit().putString("github_user", githubUser).apply()
                                                    githubUserCode = ""; githubDeviceCode = ""
                                                    buildStatus = "GitHub подключён · ${githubRepos.size} репозиториев доступно"
                                                }
                                                GitHubOAuthDeviceFlow.PollResult.Pending -> buildStatus = "Ожидаем подтверждение на GitHub. Повторите проверку через ${githubDeviceInterval} сек."
                                                GitHubOAuthDeviceFlow.PollResult.SlowDown -> { githubDeviceInterval += 5; buildStatus = "GitHub просит увеличить интервал. Повторите позже." }
                                                GitHubOAuthDeviceFlow.PollResult.Expired -> { githubUserCode = ""; githubDeviceCode = ""; buildStatus = "Код авторизации истёк. Запросите новый." }
                                                is GitHubOAuthDeviceFlow.PollResult.Failed -> buildStatus = result.message
                                            } }.onFailure { buildStatus = it.message ?: "Ошибка проверки авторизации" }
                                        buildBusy = false
                                    }
                                }
                            }, enabled = !buildBusy && githubDeviceCode.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("ПРОВЕРИТЬ АВТОРИЗАЦИЮ") }
                        }
                    }
                    if (githubUser.isNotBlank()) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = {
                                buildBusy = true
                                workspaceScope.launch {
                                    runCatching { withContext(Dispatchers.IO) { GitHubBuildClient.listRepositories(secretStore.get("github_actions_token") ?: error("Повторите вход в GitHub")) } }
                                        .onSuccess { githubRepos = it; buildStatus = "Список репозиториев обновлён" }
                                        .onFailure { buildStatus = it.message ?: "Ошибка загрузки репозиториев" }
                                    buildBusy = false
                                }
                            }, modifier = Modifier.weight(1f)) { Text("ОБНОВИТЬ РЕПОЗИТОРИИ") }
                            OutlinedButton(onClick = {
                                secretStore.put("github_actions_token", ""); githubUser = ""; githubRepos = emptyList()
                                buildPrefs.edit().remove("github_user").apply(); buildStatus = "GitHub отключён на этом устройстве"
                            }, modifier = Modifier.weight(1f)) { Text("ВЫЙТИ") }
                        }
                        if (githubRepos.isNotEmpty()) {
                            Text("ВАШИ РЕПОЗИТОРИИ", color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            githubRepos.take(30).forEach { repoItem ->
                                Row(Modifier.fillMaxWidth().clickable { githubRepo = repoItem.fullName; githubBranch = repoItem.defaultBranch; buildPrefs.edit().putString("repo", githubRepo).apply() }.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(repoItem.fullName, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                        Text("${if (repoItem.private) "Private" else "Public"} · ${repoItem.defaultBranch}", color = Muted, fontSize = 9.sp)
                                    }
                                    if (githubRepo == repoItem.fullName) Text("ВЫБРАН", color = Lime, fontSize = 9.sp)
                                }
                            }
                        }
                        OutlinedTextField(value = githubNewRepoName, onValueChange = { githubNewRepoName = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("Создать новый private-репозиторий") })
                        OutlinedButton(onClick = {
                            buildBusy = true
                            workspaceScope.launch {
                                runCatching { withContext(Dispatchers.IO) { GitHubBuildClient.createRepository(secretStore.get("github_actions_token") ?: error("GitHub не авторизован"), githubNewRepoName, true) } }
                                    .onSuccess { created -> githubRepo = created; githubBranch = "main"; githubRepos = withContext(Dispatchers.IO) { GitHubBuildClient.listRepositories(secretStore.get("github_actions_token")!!) }; buildStatus = "Создан $created" }
                                    .onFailure { buildStatus = it.message ?: "Ошибка создания репозитория" }
                                buildBusy = false
                            }
                        }, enabled = !buildBusy && githubNewRepoName.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("СОЗДАТЬ РЕПОЗИТОРИЙ") }
                    }
                    OutlinedTextField(value = githubRepo, onValueChange = { githubRepo = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("Активный репозиторий · owner/name") }, placeholder = { Text("owner/NIU-Mobility-Studio") })
                    OutlinedTextField(value = githubBranch, onValueChange = { githubBranch = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("Ветка Git") })
                    OutlinedButton(onClick = {
                        val token = secretStore.get("github_actions_token")
                        if (token.isNullOrBlank()) buildStatus = "Сначала авторизуйтесь через GitHub"
                        else {
                            buildBusy = true
                            workspaceScope.launch {
                                runCatching { withContext(Dispatchers.IO) { GitHubBuildClient.listBranches(githubRepo.trim(), token) } }
                                    .onSuccess { githubBranches = it; if (githubBranch !in it && it.isNotEmpty()) githubBranch = it.first(); buildStatus = "Загружено веток: ${it.size}" }
                                    .onFailure { buildStatus = it.message ?: "Ошибка загрузки веток" }
                                buildBusy = false
                            }
                        }
                    }, enabled = !buildBusy && githubRepo.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("ОБНОВИТЬ СПИСОК ВЕТОК") }
                    if (githubBranches.isNotEmpty()) Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        githubBranches.forEach { branchName -> FilterChip(selected = githubBranch == branchName, onClick = { githubBranch = branchName }, label = { Text(branchName, fontSize = 10.sp) }) }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = {
                            val token = secretStore.get("github_actions_token")
                            if (token.isNullOrBlank()) buildStatus = "Сначала авторизуйтесь через GitHub"
                            else {
                                buildBusy = true
                                workspaceScope.launch {
                                    runCatching { withContext(Dispatchers.IO) { GitHubBuildClient.pullWorkspace(githubRepo.trim(), token, githubBranch, projectDir) } }
                                        .onSuccess { count -> refreshProjectFiles(); buildStatus = "Загружено файлов из GitHub в активный Workspace: $count" }
                                        .onFailure { buildStatus = it.message ?: "Ошибка загрузки проекта" }
                                    buildBusy = false
                                }
                            }
                        }, enabled = !buildBusy && githubRepo.isNotBlank(), modifier = Modifier.weight(1f)) { Text("PULL · ЗАГРУЗИТЬ") }
                        OutlinedButton(onClick = {
                            val token = secretStore.get("github_actions_token")
                            if (token.isNullOrBlank()) buildStatus = "Сначала авторизуйтесь через GitHub"
                            else {
                                buildBusy = true; buildStatus = "Публикация файлов и запуск сборки…"
                                workspaceScope.launch {
                                    runCatching { withContext(Dispatchers.IO) {
                                        val commit = GitHubBuildClient.publishWorkspace(githubRepo.trim(), token, projectDir, githubBranch)
                                        GitHubBuildClient.dispatch(githubRepo.trim(), token, githubBranch)
                                        commit
                                    } }
                                        .onSuccess { commit -> buildStatus = "Опубликован commit ${commit.take(8)} · workflow запущен" }
                                        .onFailure { buildStatus = it.message ?: "Ошибка публикации" }
                                    buildBusy = false
                                }
                            }
                        }, enabled = !buildBusy && githubRepo.isNotBlank(), modifier = Modifier.weight(1f)) { Text("PUSH · ОТПРАВИТЬ + СОБРАТЬ") }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = {
                            val token = secretStore.get("github_actions_token")
                            if (token.isNullOrBlank()) buildStatus = "Сначала авторизуйтесь через GitHub"
                            else {
                                buildBusy = true
                                workspaceScope.launch {
                                    runCatching { withContext(Dispatchers.IO) { GitHubBuildClient.latestRun(githubRepo.trim(), token) } }
                                        .onSuccess { run ->
                                            if (run == null) buildStatus = "Запуски workflow не найдены"
                                            else { buildConclusion = run.conclusion; buildStatus = "Сборка #${run.id}: ${run.status} · ${run.conclusion ?: "выполняется"}" }
                                        }.onFailure { buildStatus = it.message ?: "Ошибка проверки" }
                                    buildBusy = false
                                }
                            }
                        }, enabled = !buildBusy && githubRepo.isNotBlank(), modifier = Modifier.weight(1f)) { Text("ПРОВЕРИТЬ СБОРКУ") }
                        OutlinedButton(onClick = {
                            val token = secretStore.get("github_actions_token")
                            if (token.isNullOrBlank()) buildStatus = "Сначала авторизуйтесь через GitHub"
                            else {
                                buildBusy = true; buildStatus = "Загрузка APK…"
                                workspaceScope.launch {
                                    runCatching { withContext(Dispatchers.IO) { GitHubBuildClient.downloadLatestApk(githubRepo.trim(), token, File(filesDir, "builds/${buildArtifactName}.apk"), buildArtifactName) } }
                                        .onSuccess { apk ->
                                            buildStatus = "APK скачан: ${apk.length() / 1024} КБ"
                                            runCatching {
                                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !packageManager.canRequestPackageInstalls()) {
                                                    startActivity(Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
                                                    buildStatus += " · Разрешите установку из этого источника и повторите нажатие"
                                                } else {
                                                    val uri = androidx.core.content.FileProvider.getUriForFile(this@MainActivity, "$packageName.files", apk)
                                                    val intent = Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                                    startActivity(intent)
                                                }
                                            }.onFailure { buildStatus += " · Откройте APK из файлов вручную: ${it.message}" }
                                        }.onFailure { buildStatus = it.message ?: "Ошибка загрузки APK" }
                                    buildBusy = false
                                }
                            }
                        }, enabled = !buildBusy && githubRepo.isNotBlank(), modifier = Modifier.weight(1f)) { Text("СКАЧАТЬ / УСТАНОВИТЬ") }
                    }
                    Text("OAuth Device Flow запрашивает repo, workflow и read:user. Для OAuth App необходимо включить Device Flow в настройках GitHub; Client ID является публичным идентификатором приложения, OAuth token хранится в Android Keystore. Репозиторий должен иметь выбранную ветку; локальный workspace будет опубликован отдельным commit (секреты, keystore, build и .gradle исключаются), затем запустится workflow android-build.yml. APK устанавливается только через системное подтверждение Android; приложение не обновляет себя скрытно.", color = Muted, fontSize = 10.sp, lineHeight = 15.sp)
                }
            }
            item {
                CardBlock {
                    Text("BUILD & RELEASE READINESS", color = Lime, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text("Среда приложения: Android API ${Build.VERSION.SDK_INT} · ABI: ${Build.SUPPORTED_ABIS.joinToString()} · версия ${BuildConfig.VERSION_NAME}", color = Color.White, fontSize = 11.sp)
                    Text("Исходники можно импортировать ZIP, редактировать в Project Explorer и экспортировать обратно. Android-приложение не может безопасно пересобрать собственный установленный APK без отдельного build toolchain и разрешённой среды выполнения. Для сборки подготовлен GitHub Actions workflow: он собирает APK на серверном runner после публикации проекта в репозитории.", color = Muted, fontSize = 10.sp, lineHeight = 15.sp)
                    Text("Git, терминал, sandboxed signed plugins, полноценная Kotlin/Java code intelligence и on-device APK toolchain ещё не реализованы. Не запускайте непроверенные build scripts из импортированных архивов.", color = Color(0xFFFFC66D), fontSize = 10.sp, lineHeight = 15.sp)
                }
            }
        }
    }

    private fun toolPasswordPrefs() = getSharedPreferences("niu_protected_tools", MODE_PRIVATE)

    // A per-release bootstrap credential. Only its PBKDF2 verifier is stored in the APK.
    // Users should keep the supplied credential private and may change it in a later release.
    private val bootstrapToolsSalt = android.util.Base64.decode("KYnbPkHgeMJ4vsAqdiUeUA==", android.util.Base64.NO_WRAP)
    private val bootstrapToolsHash = "3PgkbJ3xcjGolNCbqpa6VFu4AJLP9+IWZtB8ajKzEfM="

    private fun deriveToolsPassword(password: String, salt: ByteArray): ByteArray {
        val spec = javax.crypto.spec.PBEKeySpec(password.toCharArray(), salt, 210_000, 256)
        return try { javax.crypto.SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded }
        finally { spec.clearPassword() }
    }

    private fun showToolsBiometric(onSuccess: () -> Unit, onError: (String) -> Unit) {
        val manager = BiometricManager.from(this)
        val authenticators = BiometricManager.Authenticators.BIOMETRIC_STRONG
        if (manager.canAuthenticate(authenticators) != BiometricManager.BIOMETRIC_SUCCESS) {
            onError("На устройстве не настроен совместимый отпечаток пальца")
            return
        }
        val prompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { onSuccess() }
            override fun onAuthenticationError(code: Int, message: CharSequence) { onError(message.toString()) }
            override fun onAuthenticationFailed() { onError("Отпечаток не распознан") }
        })
        prompt.authenticate(BiometricPrompt.PromptInfo.Builder()
            .setTitle("NIU Mobility Studio")
            .setSubtitle("Подтвердите личность для доступа к защищённым инструментам")
            .setNegativeButtonText("Отмена")
            .setAllowedAuthenticators(authenticators)
            .build())
    }

    private fun verifyToolsPassword(password: String): Boolean {
        val prefs = toolPasswordPrefs()
        val salt = runCatching {
            prefs.getString("password_salt", null)?.let { android.util.Base64.decode(it, android.util.Base64.NO_WRAP) } ?: bootstrapToolsSalt
        }.getOrNull() ?: return false
        val expected = runCatching {
            prefs.getString("password_hash", null)?.let { android.util.Base64.decode(it, android.util.Base64.NO_WRAP) }
                ?: android.util.Base64.decode(bootstrapToolsHash, android.util.Base64.NO_WRAP)
        }.getOrNull() ?: return false
        val actual = runCatching { deriveToolsPassword(password, salt) }.getOrNull() ?: return false
        val valid = java.security.MessageDigest.isEqual(actual, expected)
        actual.fill(0)
        return valid
    }

    @Composable private fun ProtectedApkExportScreen(pad: PaddingValues) {
        var status by remember { mutableStateOf("Экспортирует APK текущей установленной версии") }
        var busy by remember { mutableStateOf(false) }
        Column(Modifier.fillMaxSize().padding(pad).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("ЗАЩИЩЁННЫЙ ЭКСПОРТ APK", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("Инструмент доступен только после разблокировки защищённых инструментов. APK копируется из установленного приложения и передаётся через системное меню Android.", color = Muted, fontSize = 12.sp, lineHeight = 17.sp)
            Button(onClick = {
                if (busy) return@Button
                busy = true
                runCatching {
                    val appInfo = packageManager.getApplicationInfo(packageName, 0)
                    val installedApk = File(appInfo.sourceDir)
                    require(installedApk.isFile && installedApk.length() > 0L) { "Не удалось найти APK установленного приложения" }
                    val exportDir = File(filesDir, "builds").apply { mkdirs() }
                    val exportApk = File(exportDir, "NIU-Mobility-Studio-${BuildConfig.VERSION_NAME}-installed.apk")
                    installedApk.inputStream().use { input -> exportApk.outputStream().use { output -> input.copyTo(output) } }
                    val uri = androidx.core.content.FileProvider.getUriForFile(this@MainActivity, "$packageName.files", exportApk)
                    val share = Intent(Intent.ACTION_SEND).apply {
                        type = "application/vnd.android.package-archive"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        putExtra(Intent.EXTRA_SUBJECT, "NIU Mobility Studio ${BuildConfig.VERSION_NAME} APK")
                        putExtra(Intent.EXTRA_TEXT, "Установочный APK NIU Mobility Studio ${BuildConfig.VERSION_NAME}")
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        clipData = ClipData.newUri(contentResolver, exportApk.name, uri)
                    }
                    startActivity(Intent.createChooser(share, "Передать APK"))
                    status = "Подготовлен APK · ${exportApk.length() / 1024} КБ"
                    addLog("SECURE APK EXPORT · ${exportApk.length()} bytes")
                }.onFailure { status = "Ошибка экспорта: ${it.message}"; addLog("SECURE APK EXPORT ERROR · ${it.message}") }
                busy = false
            }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "ПОДГОТОВКА…" else "ЭКСПОРТИРОВАТЬ / ПЕРЕДАТЬ APK") }
            Text(status, color = Muted, fontSize = 11.sp)
            Text("Примечание: на устройствах с split APK этот способ может экспортировать только базовый APK. Для полной передачи используйте артефакт GitHub Actions.", color = Color(0xFFFFC66D), fontSize = 10.sp, lineHeight = 14.sp)
        }
    }

    @Composable private fun ProtectedToolsDisabledScreen(pad: PaddingValues, onImported: () -> Unit, onClose: (() -> Unit)? = null) {
        val context = LocalContext.current
        var grantText by remember { mutableStateOf("") }
        var message by remember { mutableStateOf("") }
        Column(Modifier.fillMaxSize().padding(pad).padding(24.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.Lock, contentDescription = null, tint = Lime, modifier = Modifier.size(42.dp))
            Spacer(Modifier.height(14.dp))
            Text("ЗАЩИЩЁННЫЕ ИНСТРУМЕНТЫ", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Text("Доступ пользовательской сборки открывается только подписанным разрешением администратора, привязанным к этой установке и ограниченным по сроку. Открытый ключ администратора закрепляется при сборке APK.", color = Muted, fontSize = 12.sp, lineHeight = 17.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 10.dp, bottom = 14.dp))
            Text("ID ЭТОЙ УСТАНОВКИ", color = Lime, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text(AdminGrantVerifier.installationId(context), color = Color.White, fontSize = 11.sp, modifier = Modifier.clickable { android.content.ClipData.newPlainText("Installation ID", AdminGrantVerifier.installationId(context)).also { clip -> (context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(clip) } })
            OutlinedTextField(value = grantText, onValueChange = { grantText = it }, modifier = Modifier.fillMaxWidth().padding(top = 14.dp), label = { Text("Подписанное разрешение администратора") }, minLines = 3)
            Button(onClick = { val ok = AdminGrantVerifier.importGrant(context, grantText, BuildConfig.ADMIN_PUBLIC_KEY); message = if (ok) "Разрешение принято. Доступ открыт." else "Разрешение недействительно, отозвано, просрочено или не предназначено для этой установки."; if (ok) onImported() }, enabled = grantText.isNotBlank() && BuildConfig.ADMIN_PUBLIC_KEY.isNotBlank(), modifier = Modifier.fillMaxWidth().padding(top = 10.dp)) { Text("ПРОВЕРИТЬ И АКТИВИРОВАТЬ") }
            var revokeText by remember { mutableStateOf("") }
            OutlinedTextField(value = revokeText, onValueChange = { revokeText = it }, modifier = Modifier.fillMaxWidth().padding(top = 14.dp), label = { Text("Подписанный список отзыва (если выдан)" ) }, minLines = 2)
            OutlinedButton(onClick = { val ok = AdminGrantVerifier.importRevocationList(context, revokeText, BuildConfig.ADMIN_PUBLIC_KEY); message = if (ok) "Список отзыва принят. Отозванные разрешения заблокированы." else "Список отзыва не прошёл проверку подписи."; if (ok) onImported() }, enabled = revokeText.isNotBlank() && BuildConfig.ADMIN_PUBLIC_KEY.isNotBlank(), modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) { Text("ИМПОРТИРОВАТЬ СПИСОК ОТЗЫВА") }
            if (message.isNotBlank()) Text(message, color = Lime, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
            Text("Если поле недоступно, сборка не содержит закреплённого открытого ключа администратора. Не устанавливайте неизвестные ключи из чатов.", color = Color(0xFFFFC66D), fontSize = 10.sp, modifier = Modifier.padding(top = 12.dp))
            if (onClose != null) TextButton(onClick = onClose, modifier = Modifier.padding(top = 8.dp)) { Text("НАЗАД К ИНСТРУМЕНТАМ", color = Lime) }
        }
    }

    @Composable private fun SecureToolsGate(pad: PaddingValues, onUnlocked: () -> Unit) {
        val prefs = remember { toolPasswordPrefs() }
        var password by remember { mutableStateOf("") }
        var error by remember { mutableStateOf("") }
        var biometricEnabled by remember { mutableStateOf(prefs.getBoolean("biometric_enabled", false)) }
        var busy by remember { mutableStateOf(false) }
        Column(Modifier.fillMaxSize().padding(pad).padding(22.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.Settings, contentDescription = null, tint = Lime, modifier = Modifier.size(42.dp))
            Spacer(Modifier.height(14.dp))
            Text("ЗАЩИЩЁННЫЕ ИНСТРУМЕНТЫ", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text("Введите выданный пароль или используйте отпечаток пальца.", color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 8.dp, bottom = 18.dp))
            OutlinedTextField(password, { password = it; error = "" }, Modifier.fillMaxWidth(), label = { Text("Пароль доступа") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
            if (error.isNotBlank()) Text(error, color = Color(0xFFFF8A80), fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
            Spacer(Modifier.height(14.dp))
            Button(enabled = !busy && password.isNotBlank(), onClick = {
                busy = true
                try {
                    val ok = verifyToolsPassword(password)
                    if (ok) {
                        prefs.edit().putBoolean("password_verified", true).apply()
                        password = ""
                        if (!biometricEnabled) {
                            showToolsBiometric({ prefs.edit().putBoolean("biometric_enabled", true).apply(); biometricEnabled = true; onUnlocked() }, { error = "Пароль верный. Отпечаток не включён: $it"; onUnlocked() })
                        } else onUnlocked()
                    } else error = "Неверный пароль"
                } catch (e: Exception) { error = "Ошибка проверки пароля" }
                busy = false
            }, modifier = Modifier.fillMaxWidth()) { Text("РАЗБЛОКИРОВАТЬ") }
            if (biometricEnabled) {
                OutlinedButton(enabled = !busy, onClick = {
                    showToolsBiometric({ onUnlocked() }, { error = it })
                }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) { Text("ОТПЕЧАТОК ПАЛЬЦА") }
            }
            Text("Пароль проверяется по PBKDF2-HMAC-SHA256 с уникальной солью. Биометрия проверяется системным Android BiometricPrompt; данные отпечатка приложение не получает.", color = Muted, fontSize = 10.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 12.dp))
        }
    }

    @Composable private fun SecureToolsHub(pad: PaddingValues, open: (Int) -> Unit, lock: () -> Unit, onGrantChanged: () -> Unit) {
        if (!BuildConfig.PROTECTED_TOOLS_ENABLED || (BuildConfig.IS_USER_BUILD && !AdminGrantVerifier.isAuthorized(LocalContext.current, BuildConfig.ADMIN_PUBLIC_KEY))) { ProtectedToolsDisabledScreen(pad, onImported = { onGrantChanged() }); return }
        var showAdminPermission by remember { mutableStateOf(false) }
        if (BuildConfig.IS_USER_BUILD && showAdminPermission) {
            ProtectedToolsDisabledScreen(pad, { showAdminPermission = false; onGrantChanged() }, { showAdminPermission = false })
            return
        }
        val prefs = remember { toolPasswordPrefs() }
        var showPasswordDialog by remember { mutableStateOf(false) }
        var currentPassword by remember { mutableStateOf("") }
        var newPassword by remember { mutableStateOf("") }
        var confirmPassword by remember { mutableStateOf("") }
        var passwordMessage by remember { mutableStateOf("") }
        val entries = listOf(
            Triple(4, "BLE EXPLORER / nRF", "Сканер, GATT, READ/NOTIFY и ручная диагностика"),
            Triple(6, "ДИАГНОСТИКА ECU", "Сервисы, характеристики и состояние каналов"),
            Triple(14, "ЛОГИРОВАНИЕ", "Журнал событий, фильтры и экспорт"),
            Triple(15, "ОБСЛУЖИВАНИЕ", "История поездок и сервисные записи"),
            Triple(16, "TELEGRAM BOT / API", "Бот, разрешения пользователей и локальный сервер"),
            Triple(12, "NIU AI ASSISTANT", "Анализ журналов и протокольных наблюдений"),
            Triple(13, "CODE WORKSPACE / IDE", "Исходники, редактор и резервные копии"),
            Triple(20, "ЭКСПОРТ APK", "Передача установленного APK через защищённые инструменты"),
        )
        Column(Modifier.fillMaxSize().padding(pad)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                if (BuildConfig.IS_USER_BUILD) TextButton(onClick = { showAdminPermission = true }) { Text("АДМИН-ДОСТУП", color = Lime) }
                TextButton(onClick = { showPasswordDialog = true }) { Text("ИЗМЕНИТЬ ПАРОЛЬ", color = Lime) }
                TextButton(onClick = lock) { Text("ЗАБЛОКИРОВАТЬ", color = Lime) }
            }
            LazyColumn(contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                items(entries) { item ->
                    Card(onClick = { open(item.first) }, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(15.dp), modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Settings, contentDescription = null, tint = Lime, modifier = Modifier.size(25.dp))
                            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) { Text(item.second, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp); Text(item.third, color = Muted, fontSize = 10.sp, lineHeight = 14.sp) }
                            Text("›", color = Lime, fontSize = 24.sp)
                        }
                    }
                }
            }
        }
        if (showPasswordDialog) {
            AlertDialog(
                onDismissRequest = { showPasswordDialog = false; currentPassword = ""; newPassword = ""; confirmPassword = ""; passwordMessage = "" },
                title = { Text("Изменить пароль инструментов") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(currentPassword, { currentPassword = it; passwordMessage = "" }, label = { Text("Текущий пароль") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
                        OutlinedTextField(newPassword, { newPassword = it; passwordMessage = "" }, label = { Text("Новый пароль · минимум 8 символов") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
                        OutlinedTextField(confirmPassword, { confirmPassword = it; passwordMessage = "" }, label = { Text("Повторите новый пароль") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
                        if (passwordMessage.isNotBlank()) Text(passwordMessage, color = Color(0xFFFF8A80), fontSize = 12.sp)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        when {
                            !verifyToolsPassword(currentPassword) -> passwordMessage = "Текущий пароль неверен"
                            newPassword.length < 8 -> passwordMessage = "Новый пароль должен содержать минимум 8 символов"
                            newPassword != confirmPassword -> passwordMessage = "Новые пароли не совпадают"
                            else -> {
                                val salt = ByteArray(16).also { java.security.SecureRandom().nextBytes(it) }
                                val hash = deriveToolsPassword(newPassword, salt)
                                prefs.edit()
                                    .putString("password_salt", android.util.Base64.encodeToString(salt, android.util.Base64.NO_WRAP))
                                    .putString("password_hash", android.util.Base64.encodeToString(hash, android.util.Base64.NO_WRAP))
                                    .apply()
                                hash.fill(0)
                                currentPassword = ""; newPassword = ""; confirmPassword = ""; passwordMessage = ""
                                showPasswordDialog = false
                                addLog("SECURE TOOLS password changed")
                            }
                        }
                    }) { Text("СОХРАНИТЬ") }
                },
                dismissButton = { TextButton(onClick = { showPasswordDialog = false }) { Text("ОТМЕНА") } }
            )
        }
    }

    @Composable private fun SettingsHub(pad: PaddingValues, openSection: (Int) -> Unit) {
        LazyColumn(
            Modifier.fillMaxSize().padding(pad),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 22.dp, bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { PageHeader("TOOLS & CONFIGURATION", "Инструменты") }
            item { Text("Диагностика и подключение вынесены сюда, чтобы главный экран оставался простым.", color = Muted, fontSize = 12.sp) }
            item { SettingsEntry("ОФОРМЛЕНИЕ И ТЕМЫ", "Темы и цвета", Icons.Default.Image) { openSection(18) } }
            item { SettingsEntry("ДИСПЛЕЙ / ОБОИ", "Фон и оформление дисплея", Icons.Default.Image) { openSection(8) } }
            item { SettingsEntry("МУЗЫКА", "Локальный плеер", Icons.Default.MusicNote) { openSection(9) } }
            item { SettingsEntry("ЗВУКОВЫЕ ЭФФЕКТЫ", "Звуки и события", Icons.Default.VolumeUp) { openSection(10) } }
            item { SettingsEntry("nRF CONNECT", "Сканирование и GATT", Icons.Default.Bluetooth) { openSection(4) } }
            item { SettingsEntry("NFC", "Чтение NFC", Icons.Default.Settings) { openSection(5) } }
            item { SettingsEntry("TELEGRAM И ЛОКАЛЬНЫЙ СЕРВЕР", "Боты и локальный API", Icons.Default.Info) { openSection(16) } }
            item { SettingsEntry("ПОЕЗДКИ И ОБСЛУЖИВАНИЕ", "История и обслуживание", Icons.Default.Info) { openSection(15) } }
            item { SettingsEntry("ЖУРНАЛ СОБЫТИЙ", "События и экспорт", Icons.Default.BugReport) { openSection(14) } }
            item { SettingsEntry("ДИАГНОСТИКА", "Сервисы и характеристики", Icons.Default.Settings) { openSection(6) } }
            item { SettingsEntry("СВЯЗЬ", "Подключение к скутеру", Icons.Default.Bluetooth) { openSection(7) } }
            item { SettingsEntry("CODE WORKSPACE / IDE", "Исходники и резервные копии", Icons.Default.Home) { openSection(13) } }
            item { SettingsEntry("NIU AI ASSISTANT", "Анализ протокола", Icons.Default.Info) { openSection(12) } }
            item { SettingsEntry("О ПРИЛОЖЕНИИ", "Версия и изменения", Icons.Default.Info) { openSection(11) } }
            item { SettingsEntry("ДОКУМЕНТАЦИЯ / README", "Руководство проекта", Icons.Default.Info) { openSection(17) } }
        }
    }

    @Composable private fun AppearanceSettings(pad: PaddingValues) {
        val context = LocalContext.current
        val selected = AppAppearance.selected
        LazyColumn(
            Modifier.fillMaxSize().padding(pad),
            contentPadding = PaddingValues(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item { PageHeader("PERSONALIZATION", "Оформление приложения") }
            item { Text("Выбери один из двух вариантов. Изменение применяется сразу ко всему интерфейсу и сохраняется после перезапуска.", color = Muted, fontSize = 12.sp) }
            item {
                CardBlock {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Box(Modifier.size(42.dp).background(Color(0xFF101010), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                            Box(Modifier.size(19.dp).background(Color(0xFFE53935), CircleShape))
                        }
                        Column(Modifier.weight(1f)) {
                            Text("NIU GRAPHITE / CRIMSON", color = Color.White, fontWeight = FontWeight.Bold)
                            Text("Графитовая основа · акцент Crimson · строгая контрастная сетка", color = Muted, fontSize = 11.sp)
                        }
                        RadioButton(selected == "CURRENT", onClick = {
                            AppAppearance.selected = "CURRENT"
                            context.getSharedPreferences("app_appearance", MODE_PRIVATE).edit().putString("theme", "CURRENT").apply()
                        })
                    }
                    ThemePreviewCard(Color(0xFF101010), Color(0xFF1D1D1D), Color(0xFFE53935))
                    if (selected == "CURRENT") Text("АКТИВНАЯ ТЕМА", color = Lime, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
            item {
                CardBlock {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Box(Modifier.size(42.dp).background(Color(0xFF17212B), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                            Box(Modifier.size(19.dp).background(Color(0xFF55A7E8), CircleShape))
                        }
                        Column(Modifier.weight(1f)) {
                            Text("NIU AERO / AZURE", color = Color.White, fontWeight = FontWeight.Bold)
                            Text("Сине-графитовая основа · акцент Azure · компактные панели и мягкие скругления", color = Muted, fontSize = 11.sp)
                        }
                        RadioButton(selected == "TELEGRAM", onClick = {
                            AppAppearance.selected = "TELEGRAM"
                            context.getSharedPreferences("app_appearance", MODE_PRIVATE).edit().putString("theme", "TELEGRAM").apply()
                        })
                    }
                    ThemePreviewCard(Color(0xFF17212B), Color(0xFF232E3C), Color(0xFF55A7E8))
                    if (selected == "TELEGRAM") Text("АКТИВНАЯ ТЕМА", color = Lime, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
            item { Text("Оба оформления разработаны для NIU Mobility Studio. Вариант Aero / Azure использует компактную навигацию, мягкие панели и сине-голубую палитру.", color = Muted, fontSize = 10.sp, lineHeight = 15.sp) }
        }
    }

    @Composable private fun ThemePreviewCard(background: Color, panel: Color, accent: Color) {
        Column(Modifier.fillMaxWidth().background(background, RoundedCornerShape(12.dp)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(24.dp).background(accent, CircleShape))
                Text("  NIU MOBILITY STUDIO", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.weight(1f).height(38.dp).background(panel, RoundedCornerShape(9.dp)).padding(8.dp)) { Text("Панель", color = Color.White, fontSize = 10.sp) }
                Box(Modifier.weight(1f).height(38.dp).background(panel, RoundedCornerShape(9.dp)).padding(8.dp)) { Text("Действия", color = Color.White, fontSize = 10.sp) }
            }
            Box(Modifier.fillMaxWidth().height(5.dp).background(accent, CircleShape))
        }
    }

    @Composable private fun DocumentationCenter(pad: PaddingValues) {
        val context = LocalContext.current
        val readme = remember {
            runCatching { context.assets.open("README_RU.md").bufferedReader(Charsets.UTF_8).use { it.readText() } }
                .getOrElse { "# NIU Mobility Studio\n\nREADME не найден в assets. Полная документация находится в корне исходного проекта.\n" }
        }
        val agentBrief = remember {
            runCatching { context.assets.open("AI_AGENT_BRIEF.md").bufferedReader(Charsets.UTF_8).use { it.readText() } }
                .getOrElse { "Project: NIU Mobility Studio. Android/Kotlin/Jetpack Compose app for NIU vehicle diagnostics, BLE/GATT exploration, cloud integrations, Telegram automation and project workspace. Preserve safety gates; never invent ECU commands; redact credentials; validate model/firmware before protocol operations." }
        }
        LazyColumn(
            Modifier.fillMaxSize().padding(pad),
            contentPadding = PaddingValues(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { PageHeader("PROJECT DOCUMENTATION", "README и AI Agent Brief") }
            item {
                CardBlock {
                    Text("README ПРОЕКТА", color = Lime, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text("Полная документация доступна для просмотра и сохранения в удобном формате через системное окно Android.", color = Muted, fontSize = 11.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                        listOf("md", "txt", "html", "json").forEach { format ->
                            Button(onClick = {
                                val exported = when (format) {
                                    "txt" -> readme.replace(Regex("(?m)^#{1,6}\\s*"), "").replace(Regex("\\*\\*(.*?)\\*\\*"), "\$1").replace(Regex("`([^`]+)`"), "\$1")
                                    "html" -> "<!doctype html><html lang=\"ru\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>NIU Mobility Studio README</title><style>body{font:16px system-ui;max-width:900px;margin:40px auto;padding:0 20px;line-height:1.6}pre{overflow:auto;background:#eee;padding:12px}</style></head><body><pre>${readme.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")}</pre></body></html>"
                                    "json" -> org.json.JSONObject().put("project", "NIU Mobility Studio").put("version", BuildConfig.VERSION_NAME).put("document", "README_RU.md").put("content", readme).toString(2)
                                    else -> readme
                                }
                                pendingReadmeExportText = exported
                                pendingReadmeExportName = "NIU_Mobility_Studio_README.$format"
                                exportReadmeDocument.launch(pendingReadmeExportName)
                            }, colors = ButtonDefaults.buttonColors(containerColor = Panel2, contentColor = Color.White)) { Text(format.uppercase()) }
                        }
                    }
                    Text("В документ входят назначение проекта, функции, архитектура, ограничения и история обновлений.", color = Muted, fontSize = 10.sp)
                }
            }
            item {
                CardBlock {
                    Text("AI AGENT BRIEF", color = Lime, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text("Краткое описание для вставки в системный контекст AI-агента:", color = Muted, fontSize = 11.sp)
                    Text(agentBrief.trim(), color = Color.White, fontSize = 11.sp, lineHeight = 16.sp)
                    Button(onClick = {
                        pendingReadmeExportText = agentBrief
                        pendingReadmeExportName = "NIU_Mobility_Studio_AI_AGENT_BRIEF.md"
                        exportReadmeDocument.launch(pendingReadmeExportName)
                    }, modifier = Modifier.fillMaxWidth()) { Text("СОХРАНИТЬ AI AGENT BRIEF") }
                    Text("Отдельный файл AI_AGENT_BRIEF.md также входит в исходный проект.", color = Muted, fontSize = 10.sp)
                }
            }
            item {
                CardBlock {
                    Text("ПРЕДПРОСМОТР README", color = Lime, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text(readme.take(12000), color = Color.White, fontSize = 10.sp, lineHeight = 15.sp)
                    if (readme.length > 12000) Text("Предпросмотр сокращён. Экспорт сохраняет полный файл.", color = Muted, fontSize = 10.sp)
                }
            }
        }
    }

    @Composable private fun TelegramAndLocalServer(pad: PaddingValues) {
        val prefs = getSharedPreferences("niu_telegram_config", MODE_PRIVATE)
        val secretStore = remember { SecureSecretStore(getSharedPreferences("niu_secure_secrets", MODE_PRIVATE)) }
        var botName by remember { mutableStateOf(prefs.getString("active_bot_profile", "Основной") ?: "Основной") }
        val selectedSecretName = remember(botName) { "telegram_bot_" + Integer.toHexString(botName.trim().ifBlank { "Основной" }.lowercase().hashCode()) }
        var botToken by remember { mutableStateOf("") }
        var chatIds by remember { mutableStateOf(prefs.getString("allowed_chat_ids", "") ?: "") }
        var adminUserIds by remember { mutableStateOf(prefs.getStringSet("telegram_admin_user_ids", emptySet()).orEmpty().sorted().joinToString(", ")) }
        var regularUserIds by remember { mutableStateOf(prefs.getStringSet("telegram_allowed_user_ids", emptySet()).orEmpty().sorted().joinToString(", ")) }
        var aiBackendUrl by remember { mutableStateOf(prefs.getString("ai_backend_url", "") ?: "") }
        var aiBackendToken by remember { mutableStateOf("") }
        var autoAiOnErrors by remember { mutableStateOf(prefs.getBoolean("auto_ai_on_errors", false)) }
        var port by remember { mutableStateOf(prefs.getInt("local_port", 8765).toString()) }
        var lanEnabled by remember { mutableStateOf(prefs.getBoolean("lan_enabled", false)) }
        var localKey by remember { mutableStateOf("") }
        var botInfo by remember { mutableStateOf(prefs.getString("bot_info", "Бот не проверен") ?: "Бот не проверен") }
        var menuButtons by remember { mutableStateOf(prefs.getString("menu_buttons", "Диагностика|/status\nМодели NIU|/models\nОшибки|/errors\nЖурнал|/logs\nBluetooth|/ble\nNIU Cloud|/cloud").orEmpty()) }
        var consoleFilter by remember { mutableStateOf("Все") }
        var serviceRunning by remember { mutableStateOf(prefs.getBoolean("telegram_service_running", false)) }
        var serviceConsoleLines by remember { mutableStateOf(prefs.getString("telegram_console_lines", "").orEmpty().lines().filter { it.isNotBlank() }.takeLast(250)) }
        var status by remember { mutableStateOf("Интеграции остановлены") }
        var busy by remember { mutableStateOf(false) }
        val scope = rememberCoroutineScope()
        val tokenReadResult = runCatching {
            secretStore.getOrThrow(selectedSecretName) ?: secretStore.getOrThrow("telegram_bot_token")
        }
        val tokenSaved = !tokenReadResult.getOrNull().isNullOrBlank()
        val tokenStorageIssue = tokenReadResult.exceptionOrNull()
        val savedBotProfiles = prefs.getStringSet("bot_profiles", emptySet())?.toList()?.sorted().orEmpty()
        val serverKeySaved = secretStore.contains("local_api_token")
        val isPolling = serviceRunning || prefs.getBoolean("telegram_service_running", false) || telegramPollingThread?.isAlive == true
        val isServerRunning = localControlServer?.isRunning == true
        LaunchedEffect(isPolling) {
            while (isPolling) {
                serviceConsoleLines = prefs.getString("telegram_console_lines", "").orEmpty().lines().filter { it.isNotBlank() }.takeLast(250)
                serviceRunning = prefs.getBoolean("telegram_service_running", false)
                delay(1500)
            }
            serviceConsoleLines = prefs.getString("telegram_console_lines", "").orEmpty().lines().filter { it.isNotBlank() }.takeLast(250)
        }
        val lanIp = remember { runCatching { java.net.NetworkInterface.getNetworkInterfaces().toList().flatMap { it.inetAddresses.toList() }.firstOrNull { !it.isLoopbackAddress && it is java.net.Inet4Address }?.hostAddress ?: "IP не определён" }.getOrDefault("IP не определён") }
        fun persistConfig() {
            val profiles = prefs.getStringSet("bot_profiles", emptySet())?.toMutableSet() ?: mutableSetOf()
            profiles.add(botName.trim().ifBlank { "Основной" })
            prefs.edit().putStringSet("bot_profiles", profiles).putString("active_bot_profile", botName.trim().ifBlank { "Основной" })
                .putString("allowed_chat_ids", chatIds)
                .putStringSet("telegram_admin_user_ids", adminUserIds.split(',', ';', '\n').map { it.trim() }.filter { it.matches(Regex("[0-9]{3,24}")) }.toSet())
                .putStringSet("telegram_allowed_user_ids", regularUserIds.split(',', ';', '\n').map { it.trim() }.filter { it.matches(Regex("[0-9]{3,24}")) }.toSet())
                .putString("ai_backend_url", aiBackendUrl.trim())
                .putBoolean("auto_ai_on_errors", autoAiOnErrors)
                .putInt("local_port", port.toIntOrNull() ?: 8765)
                .putBoolean("lan_enabled", lanEnabled).putString("bot_info", botInfo).putString("menu_buttons", menuButtons).apply()
            try {
                if (botToken.isNotBlank()) {
                    val value = botToken.trim()
                    secretStore.put(selectedSecretName, value)
                    check(secretStore.get(selectedSecretName) == value) { "Токен записан, но контрольное чтение не удалось" }
                }
                if (localKey.isNotBlank()) secretStore.put("local_api_token", localKey.trim())
                if (aiBackendToken.isNotBlank()) secretStore.put("telegram_ai_backend_token", aiBackendToken.trim())
                botToken = ""; localKey = ""; aiBackendToken = ""
                addLog("Telegram/Local API: конфигурация сохранена; секреты зашифрованы Android Keystore")
                status = if (secretStore.get(selectedSecretName).isNullOrBlank() && secretStore.get("telegram_bot_token").isNullOrBlank())
                    "Настройки сохранены; токен ещё не добавлен" else "Настройки и токен сохранены"
            } catch (error: Exception) {
                status = "Не удалось сохранить секрет: ${error.message ?: error.javaClass.simpleName}"
                addLog("Secure storage ERROR: ${error.javaClass.simpleName}")
            }
        }
        LazyColumn(
            Modifier.fillMaxSize().padding(pad),
            contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { PageHeader("AUTOMATION & SELF-HOSTED", "Telegram и локальный сервер") }
            item { Text("Подключайте собственных ботов Telegram и запускайте защищённый HTTP API прямо на телефоне. Токены хранятся зашифрованно и не попадают в журнал.", color = Muted, fontSize = 12.sp) }
            item {
                CardBlock {
                    Text("TELEGRAM BOT API", color = Lime, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    OutlinedTextField(botName, { botName = it.take(40) }, Modifier.fillMaxWidth(), label = { Text("Название профиля бота") }, singleLine = true)
                    if (savedBotProfiles.isNotEmpty()) Text("Сохранённые профили: ${savedBotProfiles.joinToString(" · ")}", color = Muted, fontSize = 10.sp)
                    Text(
                        when {
                            tokenStorageIssue != null -> "Не удалось расшифровать сохранённый токен. Повторно введите токен BotFather и сохраните его заново."
                            tokenSaved -> "Токен сохранён защищённо. Поле пустое намеренно; введите новый токен только для замены."
                            else -> "Для этого профиля токен ещё не добавлен"
                        },
                        color = if (tokenSaved) Lime else if (tokenStorageIssue != null) Color(0xFFFFB74D) else Muted,
                        fontSize = 11.sp, lineHeight = 15.sp
                    )
                    OutlinedTextField(
                        botToken, { botToken = it }, Modifier.fillMaxWidth(),
                        label = { Text(if (tokenSaved) "Новый Bot Token · необязательно" else "Bot Token · BotFather") },
                        placeholder = { Text(if (tokenSaved && tokenStorageIssue == null) "Оставьте пустым, чтобы сохранить текущий" else "Вставьте токен от BotFather") },
                        singleLine = true, visualTransformation = PasswordVisualTransformation()
                    )
                    OutlinedTextField(chatIds, { chatIds = it }, Modifier.fillMaxWidth(), label = { Text("Разрешённые Chat ID (через запятую)") }, supportingText = { Text("Обязательно для запуска бота. Пустой список запрещён.") })
                    OutlinedTextField(adminUserIds, { adminUserIds = it }, Modifier.fillMaxWidth(), label = { Text("Telegram User ID администраторов") }, supportingText = { Text("Первичного администратора укажите здесь. Несколько ID через запятую.") })
                    OutlinedTextField(regularUserIds, { regularUserIds = it }, Modifier.fillMaxWidth(), label = { Text("Telegram User ID обычных пользователей") }, supportingText = { Text("Если список пуст, обычным пользователям разрешён доступ из разрешённых чатов.") })
                    OutlinedTextField(aiBackendUrl, { aiBackendUrl = it }, Modifier.fillMaxWidth(),
                        label = { Text("AI backend HTTPS URL") },
                        supportingText = { Text("POST JSON {message, context.logs}; ответ JSON {reply}. Нужен собственный HTTPS backend.") })
                    OutlinedTextField(aiBackendToken, { aiBackendToken = it }, Modifier.fillMaxWidth(),
                        label = { Text("AI backend Bearer token (необязательно)") },
                        visualTransformation = PasswordVisualTransformation(), singleLine = true)
                    Text("AI Telegram: ${if (aiBackendUrl.startsWith("https://")) "backend настроен" else "не настроен"}", color = Muted, fontSize = 11.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Автоанализ новых ошибок", color = Color.White, fontSize = 13.sp)
                            Text("Отправляет маскированную ошибку и последние логи в AI и уведомляет разрешённые Chat ID. Лимит: 1 раз в минуту.", color = Muted, fontSize = 10.sp)
                        }
                        Switch(checked = autoAiOnErrors, onCheckedChange = { autoAiOnErrors = it; prefs.edit().putBoolean("auto_ai_on_errors", it).apply() })
                    }
                    Text(botInfo, color = Muted, fontSize = 11.sp)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { persistConfig() }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 10.dp, vertical = 9.dp)) {
                            Text("Сохранить профиль", fontSize = 11.sp, lineHeight = 13.sp, textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                        OutlinedButton(onClick = { secretStore.remove(selectedSecretName); secretStore.remove("telegram_bot_token"); status = "Токен выбранного профиля удалён"; addLog("Telegram bot token removed") }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 10.dp, vertical = 9.dp)) {
                            Text("Удалить токен", fontSize = 11.sp, lineHeight = 13.sp, textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { persistConfig(); val token = secretStore.get(selectedSecretName) ?: secretStore.get("telegram_bot_token"); if (token.isNullOrBlank()) { status = "Сначала сохраните токен" } else { busy = true; Thread { val result = runCatching { com.niu.fxstudio.security.TelegramBotClient(token).getMe() }; runOnUiThread { busy = false; result.onSuccess { botInfo = "@${it.username} · ${it.firstName} · ID ${it.id}"; prefs.edit().putString("bot_info", botInfo).apply(); status = "Токен подтверждён"; addLog("Telegram getMe: ${it.username}") }.onFailure { status = it.message ?: "Ошибка Telegram"; addLog("Telegram ERROR: $status") } } }.start() } }, enabled = !busy, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 8.dp, vertical = 9.dp)) {
                            Text("Проверить токен", fontSize = 11.sp, lineHeight = 13.sp, textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                        OutlinedButton(onClick = { persistConfig(); val token = secretStore.get(selectedSecretName) ?: secretStore.get("telegram_bot_token"); if (!token.isNullOrBlank()) Thread { val result = runCatching { com.niu.fxstudio.security.TelegramBotClient(token).setCommands() }; runOnUiThread { status = result.fold({ "Команды бота обновлены" }, { "Ошибка: ${it.message}" }); addLog("Telegram setMyCommands: $status") } }.start() }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 8.dp, vertical = 9.dp)) {
                            Text("Установить команды", fontSize = 11.sp, lineHeight = 13.sp, textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {
                            persistConfig()
                            val token = runCatching { secretStore.getOrThrow(selectedSecretName) ?: secretStore.getOrThrow("telegram_bot_token") }.getOrNull()
                            val allowed = chatIds.split(',', ';', '\n').map { it.trim() }.filter { it.isNotBlank() }.toSet()
                            if (token.isNullOrBlank()) { status = "Сначала сохраните токен бота"; return@Button }
                            if (allowed.isEmpty()) { status = "Добавьте минимум один разрешённый Chat ID"; return@Button }
                            if (isPolling) { status = "Бот уже работает в фоновом режиме"; return@Button }
                            prefs.edit().putBoolean("telegram_service_running", true).apply()
                            val serviceIntent = Intent(this@MainActivity, com.niu.fxstudio.security.TelegramBotService::class.java).setAction(com.niu.fxstudio.security.TelegramBotService.ACTION_START)
                            try {
                                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 913)
                                }
                                if (Build.VERSION.SDK_INT >= 26) ContextCompat.startForegroundService(this@MainActivity, serviceIntent) else startService(serviceIntent)
                                serviceRunning = true
                                status = "Запуск фонового Telegram-сервиса…"
                                addLog("Telegram foreground service start requested")
                            } catch (error: Exception) {
                                serviceRunning = false
                                prefs.edit().putBoolean("telegram_service_running", false).apply()
                                status = "Не удалось запустить Telegram service: ${error.message ?: error.javaClass.simpleName}"
                                addLog("Telegram service START ERROR: ${error.javaClass.simpleName}: ${error.message}")
                            }
                        }, enabled = !isPolling, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 8.dp, vertical = 9.dp)) {
                            Text("Запустить бота", fontSize = 11.sp, lineHeight = 13.sp, textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                        OutlinedButton(onClick = {
                            runCatching { startService(Intent(this@MainActivity, com.niu.fxstudio.security.TelegramBotService::class.java).setAction(com.niu.fxstudio.security.TelegramBotService.ACTION_STOP)) }
                            telegramPollingFlag?.set(false)
                            serviceRunning = false
                            prefs.edit().putBoolean("telegram_service_running", false).apply()
                            status = "Остановка фонового бота запрошена"
                            addLog("Telegram foreground service stop requested")
                        }, enabled = isPolling, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 8.dp, vertical = 9.dp)) {
                            Text("Остановить", fontSize = 11.sp, lineHeight = 13.sp, textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                    }
                    Text("Бот работает отдельным Foreground Service и продолжает Long Polling при сворачивании приложения. Android показывает постоянное уведомление; разрешите уведомления и снимите ограничения энергосбережения. Принудительная остановка приложения завершает сервис. Webhook не требуется.", color = Muted, fontSize = 11.sp)
                }
            }
            item {
                CardBlock {
                    Text("КНОПОЧНОЕ МЕНЮ TELEGRAM", color = Lime, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text("Редактируйте подписи и команды кнопок. Одна строка = Название|/команда. Кнопки отправляются как inline keyboard после команды /menu.", color = Muted, fontSize = 11.sp)
                    OutlinedTextField(menuButtons, { menuButtons = it.take(1800) }, Modifier.fillMaxWidth().heightIn(min = 130.dp), label = { Text("Кнопки бота") }, minLines = 5)
                    Text("Доступные команды: /status, /vehicle, /models, /ble, /nfc, /diagnostics, /cloud, /service, /logs, /errors, /analyze, /ai, /fix, /ping, /version", color = Muted, fontSize = 10.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { menuButtons = "Диагностика|/status\nМодели NIU|/models\nОшибки|/errors\nЖурнал|/logs\nBluetooth|/ble\nNIU Cloud|/cloud" }) { Text("По умолчанию") }
                        Button(onClick = { prefs.edit().putString("menu_buttons", menuButtons).apply(); status = "Кнопки меню сохранены"; addLog("Telegram menu: custom buttons saved") }) { Text("Сохранить кнопки") }
                    }
                    Button(onClick = {
                        val token = runCatching { secretStore.getOrThrow(selectedSecretName) ?: secretStore.getOrThrow("telegram_bot_token") }.getOrNull()
                        val ids = chatIds.split(',', ';', '\n').map { it.trim() }.filter { it.isNotBlank() }
                        val buttons = menuButtons.lines().mapNotNull { line -> val a = line.split("|", limit = 2).map { it.trim() }; if (a.size == 2 && a[0].isNotBlank() && a[1].matches(Regex("/[a-zA-Z0-9_]{1,32}"))) a[0] to a[1] else null }.take(12)
                        if (token.isNullOrBlank() || ids.isEmpty() || buttons.isEmpty()) { status = "Нужны токен, Chat ID и корректные строки кнопок" }
                        else Thread { val result = runCatching { val bot = com.niu.fxstudio.security.TelegramBotClient(token) { event -> runOnUiThread { addLog("Telegram API: $event") } }; ids.forEach { bot.sendMenu(it, buttons) } }; runOnUiThread { status = result.fold({ "Меню отправлено в ${ids.size} чат(а)" }, { "Ошибка отправки меню: ${it.message}" }); addLog("Telegram menu send: $status") } }.start()
                    }, modifier = Modifier.fillMaxWidth()) { Text("Отправить меню в разрешённые чаты") }
                }
            }
            item {
                CardBlock {
                    Text("КОНСОЛЬ TELEGRAM · LIVE LOG", color = Lime, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text("Полный журнал запросов Bot API, входящих обновлений, команд, ошибок сети и повторных подключений. Токены автоматически маскируются.", color = Muted, fontSize = 11.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("Все", "Ошибки", "API", "Команды").forEach { filter ->
                            FilterChip(selected = consoleFilter == filter, onClick = { consoleFilter = filter }, label = { Text(filter, fontSize = 10.sp) })
                        }
                    }
                    val telegramLogs = (logs.filter { it.contains("TELEGRAM", true) && !it.contains("LEGACY IMPORT", true) } + serviceConsoleLines)
                        .distinct().takeLast(250)
                        .filter { line -> when (consoleFilter) {
                            "Ошибки" -> line.contains("ERROR", true) || line.contains("TIMEOUT", true) || line.contains("FAIL", true) || line.contains("WARN", true) || line.contains("ошиб", true)
                            "API" -> line.contains("HTTP", true) || line.contains("API", true) || line.contains("DNS", true) || line.contains("CONNECT", true)
                            "Команды" -> line.contains("COMMAND", true) || line.contains("UPDATE", true) || line.contains("callback", true) || line.contains("/", true)
                            else -> true
                        } }.takeLast(100)
                    val prettyTelegramLogs = telegramLogs.map(::formatTelegramConsoleLine)
                    Text("Событий Telegram: ${telegramLogs.size} · фон: ${if (isPolling) "активен" else "остановлен"}", color = Muted, fontSize = 10.sp)
                    Column(Modifier.fillMaxWidth().heightIn(max = 300.dp).verticalScroll(rememberScrollState()).background(Color(0xFF090909), RoundedCornerShape(8.dp)).padding(10.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        if (prettyTelegramLogs.isEmpty()) Text("Событий Telegram пока нет. Здесь появятся подключения, команды и ошибки.", color = Muted, fontSize = 11.sp)
                        prettyTelegramLogs.forEach { line ->
                            val errorLine = line.contains(" ERROR ", true) || line.contains(" WARN ", true)
                            Text(line, color = if (errorLine) Color(0xFFFF8A80) else Color(0xFFD7E3E8), fontSize = 10.sp, lineHeight = 14.sp)
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { pendingLogExportText = prettyTelegramLogs.joinToString("\n"); exportLogsDocument.launch("NIU_Telegram_console.txt") }, modifier = Modifier.weight(1f)) { Text("Экспорт консоли") }
                        OutlinedButton(onClick = { consoleFilter = "Все"; serviceConsoleLines = prefs.getString("telegram_console_lines", "").orEmpty().lines().filter { it.isNotBlank() }.takeLast(250); addLog("Telegram console refreshed") }, modifier = Modifier.weight(1f)) { Text("Обновить") }
                    }
                }
            }
            item {
                CardBlock {
                    Text("LOCAL HTTP API", color = Lime, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text(if (isServerRunning) "Сервер запущен" else "Сервер остановлен", color = if (isServerRunning) Lime else Muted, fontSize = 12.sp)
                    OutlinedTextField(port, { port = it.filter(Char::isDigit).take(5) }, Modifier.fillMaxWidth(), label = { Text("Порт (1024–65535)") }, singleLine = true)
                    OutlinedTextField(localKey, { localKey = it }, Modifier.fillMaxWidth(), label = { Text("API Bearer Key (оставьте пустым, если сохранён)") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { val bytes = ByteArray(32); java.security.SecureRandom().nextBytes(bytes); localKey = android.util.Base64.encodeToString(bytes, android.util.Base64.URL_SAFE or android.util.Base64.NO_WRAP or android.util.Base64.NO_PADDING) }) { Text("Сгенерировать ключ") }
                        OutlinedButton(onClick = { secretStore.remove("local_api_token"); status = "Ключ локального API удалён"; addLog("Local API key removed") }) { Text("Удалить ключ") }
                    }
                    Text(if (serverKeySaved) "Ключ API сохранён в Android Keystore" else "Создайте ключ не короче 24 символов", color = Muted, fontSize = 11.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = lanEnabled, onCheckedChange = { lanEnabled = it })
                        Column {
                            Text("Доступ из локальной сети", color = Color.White, fontSize = 12.sp)
                            Text("Выключено: только 127.0.0.1. Включайте LAN только в доверенной сети.", color = Muted, fontSize = 10.sp)
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {
                            persistConfig()
                            val apiKey = secretStore.get("local_api_token")
                            val p = port.toIntOrNull()
                            if (apiKey.isNullOrBlank() || apiKey.length < 24 || p == null || p !in 1024..65535) { status = "Ключ должен содержать минимум 24 символа, порт — 1024–65535"; return@Button }
                            if (localControlServer?.isRunning == true) { status = "Сервер уже запущен"; return@Button }
                            val token = secretStore.get(selectedSecretName) ?: secretStore.get("telegram_bot_token")
                            val ids = chatIds.split(',', ';', '\n').map { it.trim() }.filter { it.isNotBlank() }
                            val server = com.niu.fxstudio.security.LocalControlServer(p, apiKey, lanEnabled, { message ->
                                if (token.isNullOrBlank() || ids.isEmpty()) addLog("Local API: notification accepted locally; Telegram not configured")
                                else ids.forEach { id -> runCatching { com.niu.fxstudio.security.TelegramBotClient(token).sendMessage(id, message) }.onFailure { addLog("Telegram notify ERROR: ${it.message}") } }
                            }, { event -> runOnUiThread { status = event; addLog("Local API: $event") } })
                            localControlServer = server; server.start(); status = "Запуск локального API…"
                        }, enabled = !isServerRunning) { Text("Запустить сервер") }
                        OutlinedButton(onClick = { localControlServer?.stop(); localControlServer = null; status = "Остановка сервера…" }, enabled = isServerRunning) { Text("Остановить") }
                    }
                    Text("GET /health · POST /notify · Authorization: Bearer <key> · JSON: {\"message\":\"текст\"}", color = Muted, fontSize = 10.sp)
                    if (lanEnabled) Text("Адрес в локальной сети: http://$lanIp:${port.ifBlank { "8765" }}", color = Muted, fontSize = 11.sp)
                    Text("Сервер работает в процессе приложения: при принудительном закрытии приложения он остановится. LAN использует HTTP — не открывайте порт в интернет и не используйте публичные/недоверенные сети.", color = Color(0xFFFFB74D), fontSize = 11.sp)
                }
            }
            item { CardBlock { Text("СОСТОЯНИЕ", color = Lime, fontWeight = FontWeight.Bold); Text(status, color = Color.White, fontSize = 12.sp); Text("Telegram: ${if (isPolling) "работает" else "остановлен"} · Local API: ${if (isServerRunning) "работает" else "остановлен"}", color = Muted, fontSize = 11.sp) } }
        }
    }

    @Composable private fun MaintenanceJournal(pad: PaddingValues) {
        val prefs = getSharedPreferences("niu_maintenance_${activeVehicleSerial.ifBlank { "local" }}", MODE_PRIVATE)
        var odometer by remember(activeVehicleSerial) { mutableStateOf(prefs.getString("odometer", "") ?: "") }
        var task by remember(activeVehicleSerial) { mutableStateOf("") }
        var tripDestination by remember(activeVehicleSerial) { mutableStateOf("") }
        var tripDistance by remember(activeVehicleSerial) { mutableStateOf("") }
        var nextDue by remember(activeVehicleSerial) { mutableStateOf(prefs.getString("next_due", "") ?: "") }
        var notes by remember(activeVehicleSerial) { mutableStateOf(prefs.getString("notes", "") ?: "") }
        var savedMessage by remember { mutableStateOf("Данные хранятся только на этом устройстве") }
        val history = remember(activeVehicleSerial) { mutableStateListOf<String>().apply {
            addAll(prefs.getString("history", "").orEmpty().split("\n").filter { it.isNotBlank() })
        } }
        LazyColumn(Modifier.fillMaxSize().padding(pad), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item { PageHeader("OWNER TOOLS", "Поездки и обслуживание") }
            item { Text("Профиль: ${savedVehicles.firstOrNull { it.serial == activeVehicleSerial }?.name ?: "Локальный NIU"}. Записи не отправляются в NIU Cloud.", color = Muted, fontSize = 12.sp) }
            item { CardBlock {
                Text("ТЕКУЩИЙ ПРОБЕГ · КМ", color = Lime, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                OutlinedTextField(odometer, { odometer = it.filter { c -> c.isDigit() }.take(8) }, label = { Text("Показание одометра") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(nextDue, { nextDue = it.filter { c -> c.isDigit() }.take(8) }, label = { Text("Следующее обслуживание, км") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(notes, { notes = it.take(500) }, label = { Text("Заметка о состоянии / расходниках") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                PrimaryButton("СОХРАНИТЬ ПОКАЗАНИЯ") {
                    prefs.edit().putString("odometer", odometer).putString("next_due", nextDue).putString("notes", notes).apply()
                    savedMessage = "Показания сохранены локально"
                    addLog("Maintenance: сохранены показания одометра")
                }
                Text(savedMessage, color = Muted, fontSize = 10.sp)
            } }
            item { CardBlock {
                Text("ДОБАВИТЬ РАБОТУ", color = Lime, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                OutlinedTextField(task, { task = it.take(160) }, label = { Text("Например: проверка тормозов") }, modifier = Modifier.fillMaxWidth())
                PrimaryButton("ДОБАВИТЬ В ИСТОРИЮ") {
                    if (task.isNotBlank()) {
                        val line = "${java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())} · ${odometer.ifBlank { "пробег не указан" }} км · ${task.trim()}"
                        history.add(0, line); while (history.size > 100) history.removeAt(history.lastIndex)
                        prefs.edit().putString("history", history.joinToString("\n")).apply()
                        addLog("Maintenance: добавлена запись в журнал работ"); task = ""; savedMessage = "Запись добавлена"
                    }
                }
            } }
            item { CardBlock {
                Text("ЗАПИСАТЬ ПОЕЗДКУ", color = Lime, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                OutlinedTextField(tripDestination, { tripDestination = it.take(100) }, label = { Text("Маршрут / назначение") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(tripDistance, { tripDistance = it.filter { c -> c.isDigit() || c == '.' || c == ',' }.take(8) }, label = { Text("Дистанция, км") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                PrimaryButton("СОХРАНИТЬ ПОЕЗДКУ") {
                    val distance = tripDistance.replace(',', '.').toDoubleOrNull()
                    if (distance != null && distance > 0.0 && distance <= 2000.0 && tripDestination.isNotBlank()) {
                        val line = "${java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.US).format(java.util.Date())} · поездка · ${"%.1f".format(java.util.Locale.US, distance)} км · ${tripDestination.trim()}"
                        history.add(0, line); while (history.size > 100) history.removeAt(history.lastIndex)
                        prefs.edit().putString("history", history.joinToString("\n")).apply()
                        addLog("Ride journal: сохранена поездка (${distance} km)")
                        tripDestination = ""; tripDistance = ""; savedMessage = "Поездка добавлена в локальную историю"
                    } else savedMessage = "Укажите маршрут и дистанцию от 0 до 2000 км"
                }
            } }
            item { CardBlock {
                Text("КОНТРОЛЬНЫЙ СПИСОК", color = Lime, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                listOf("Шины и давление", "Тормоза и свет", "Крепёж и рулевое управление", "Кабели и разъёмы", "Состояние аккумулятора и зарядного устройства").forEach { label ->
                    var checked by remember(label) { mutableStateOf(prefs.getBoolean("check_$label", false)) }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked, { checked = it; prefs.edit().putBoolean("check_$label", it).apply() })
                        Text(label, color = Color.White, fontSize = 12.sp)
                    }
                }
                Text("Проверки — пользовательские отметки, не автоматическая диагностика ECU.", color = Muted, fontSize = 10.sp)
            } }
            item { CardBlock {
                Text("ИСТОРИЯ ОБСЛУЖИВАНИЯ", color = Lime, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                if (history.isEmpty()) Text("Пока нет записей. Добавьте первую работу выше.", color = Muted, fontSize = 12.sp)
                history.forEach { Text(it, color = Color.White, fontSize = 12.sp); Divider(color = Panel2) }
                TextButton(onClick = { val report = buildString { appendLine("NIU Mobility Studio · Service history"); appendLine("Vehicle: ${activeVehicleSerial.ifBlank { "local profile" }}"); appendLine("Odometer: ${odometer.ifBlank { "—" }} km"); appendLine("Next service: ${nextDue.ifBlank { "—" }} km"); appendLine("Notes: $notes"); history.forEach { appendLine(it) } }; shareText(report, "NIU service history") }) { Text("ЭКСПОРТ ИСТОРИИ", color = Lime) }
            } }
        }
    }

    /** Builds a privacy-preserving handoff: no MAC, raw characteristic payloads, keys or tokens by default. */
    private fun buildAiHandoffReport(includeRawValues: Boolean): String = buildString {
        appendLine("NIU Mobility Studio · AI diagnostic handoff")
        appendLine("App version: ${BuildConfig.VERSION_NAME}")
        appendLine("Vehicle profile: $selectedNiuModel · family=$selectedNiuFamily")
        appendLine("Connection state: $connectionState")
        appendLine("Device name: ${connectedName ?: "not connected"}")
        appendLine("Device address: [REDACTED]")
        appendLine("GATT services discovered: ${serviceRows.size}")
        appendLine("Characteristics discovered: ${characteristicRows.size}")
        appendLine("Readable values captured: ${characteristicRows.count { it.properties and BluetoothGattCharacteristic.PROPERTY_READ != 0 && characteristicValues[it.uuid] != null }}")
        appendLine("Active notifications: ${notifyStates.count { it.value }}")
        appendLine("\nGATT STRUCTURE")
        characteristicRows.forEach { row ->
            appendLine("${row.serviceUuid} | ${row.uuid} | ${propertiesLabel(row.properties)}")
            if (includeRawValues) appendLine("  VALUE_HEX=${characteristicValues[row.uuid] ?: "(not read)"}")
            else appendLine("  VALUE_HEX=[OMITTED BY PRIVACY DEFAULT]")
        }
        appendLine("\nRECENT LOG (last 80 entries; addresses redacted)")
        logs.takeLast(80).forEach { line ->
            val withoutMac = line.replace(Regex("(?i)([0-9a-f]{2}:){5}[0-9a-f]{2}"), "[MAC REDACTED]")
            val withoutSecrets = withoutMac.replace(
                Regex("(?i)(token|access[_-]?token|authorization|pin|secret|private[_-]?key)\\s*[:=]\\s*[^\\s,;]+"),
                "$1=[REDACTED]"
            )
            appendLine(withoutSecrets)
        }
        appendLine("\nKNOWN RESEARCH CONTEXT")
        appendLine("Known NIU Link UUIDs are observations from a user-provided nRF report; command payload format and FX authentication are not verified.")
        appendLine("Do not infer command semantics from UUIDs or operation names. Do not recommend sending unknown WRITE/control payloads.")
        appendLine("Request: analyze evidence, identify likely transport/diagnostic issues, separate confirmed facts from hypotheses, and propose safe read-only next steps.")
    }

    private fun shareAiHandoff(includeRawValues: Boolean) {
        val prompt = "Ты помогаешь анализировать NIU Mobility Studio и профиль $selectedNiuModel. " +
            "Проанализируй приложенный диагностический контекст. Отделяй факты от гипотез, не придумывай BLE-команды и не предлагай неизвестные WRITE-пакеты. " +
            "Составь выводы, список недостающих доказательств и безопасные следующие шаги.\n\n" + buildAiHandoffReport(includeRawValues)
        shareText(prompt, "NIU Mobility Studio · AI diagnostic handoff")
    }

    @Composable private fun NiuAiAssistant(pad: PaddingValues) {
        var includeRawValues by remember { mutableStateOf(false) }
        val authFailures = logs.count { it.contains("AUTH FAIL", true) || it.contains("0x89", true) }
        val gattTimeouts = logs.count { it.contains("timeout", true) }
        LazyColumn(
            Modifier.fillMaxSize().padding(pad),
            contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 20.dp, bottom = 30.dp),
            verticalArrangement = Arrangement.spacedBy(13.dp)
        ) {
            item { PageHeader("NIU AI ASSISTANT", "Помощник диагностики") }
            item {
                CardBlock {
                    Text("АНАЛИЗ В ЭТОМ ЧАТЕ", color = Lime, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text("Подготовьте диагностический пакет и передайте его ChatGPT или другому выбранному приложению через системное меню Android. Передача происходит только после вашего нажатия.", color = Color.White, fontSize = 12.sp, lineHeight = 18.sp)
                    Text("Состояние: ${if (connectedName != null) "подключено · $connectedName" else connectionState}", color = Muted, fontSize = 11.sp)
                    Text("GATT: ${serviceRows.size} сервисов · ${characteristicRows.size} характеристик", color = Muted, fontSize = 11.sp)
                }
            }
            item {
                CardBlock {
                    Text("ЛОКАЛЬНЫЕ ИНДИКАТОРЫ", color = Lime, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column { Text("AUTH FAIL", color = Muted, fontSize = 10.sp); Text(authFailures.toString(), color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold) }
                        Column { Text("GATT TIMEOUT", color = Muted, fontSize = 10.sp); Text(gattTimeouts.toString(), color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold) }
                        Column { Text("NOTIFY", color = Muted, fontSize = 10.sp); Text(notifyStates.count { it.value }.toString(), color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold) }
                    }
                    Text("Это подсчёт совпадений в текущем журнале, а не автоматический диагноз неисправности.", color = Muted, fontSize = 10.sp)
                }
            }
            item {
                CardBlock {
                    Text("КОНФИДЕНЦИАЛЬНОСТЬ ОТЧЁТА", color = Lime, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = includeRawValues, onCheckedChange = { includeRawValues = it }, colors = CheckboxDefaults.colors(checkedColor = Lime))
                        Column(Modifier.weight(1f)) {
                            Text("Включить сырые HEX-значения", color = Color.White, fontSize = 12.sp)
                            Text("По умолчанию выключено. Включайте только если уверены, что значения не содержат секретов или ключевого материала.", color = Muted, fontSize = 10.sp, lineHeight = 15.sp)
                        }
                    }
                    Text("MAC-адрес автоматически скрывается. PIN, ключи, токены и данные авторизации не добавляются.", color = Muted, fontSize = 10.sp)
                    Button(onClick = { shareAiHandoff(includeRawValues) }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = Color.White)) {
                        Text("ПЕРЕДАТЬ ОТЧЁТ В CHATGPT", fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(onClick = { saveText(buildAiHandoffReport(includeRawValues), "NIU_FX_AI_Report_${System.currentTimeMillis()}.txt") }, modifier = Modifier.fillMaxWidth()) {
                        Text("СОХРАНИТЬ AI-ОТЧЁТ В TXT")
                    }
                }
            }
            item {
                CardBlock {
                    Text("ВСТРОЕННЫЙ AI-СЕРВЕР", color = Lime, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text("Сетевой AI-чат требует отдельного HTTPS backend. В этой версии не запрашивается API-ключ и не выполняется отправка данных на неизвестный сервер. Ключ OpenAI нельзя хранить в APK. Интерфейс передачи отчёта в ChatGPT уже доступен через системное меню Android.", color = Color.White, fontSize = 11.sp, lineHeight = 17.sp)
                    Text("Backend API и полноценный чат будут подключены после выбора и развёртывания контролируемого сервера.", color = Muted, fontSize = 10.sp)
                }
            }
        }
    }

    @Composable private fun AboutAndChangelog(pad: PaddingValues) {
        val context = LocalContext.current
        val appVersion = remember {
            runCatching {
                @Suppress("DEPRECATION")
                val packageInfo = context.packageManager.getPackageInfo(context.packageName, 0)
                packageInfo.versionName ?: "не определена"
            }.getOrDefault("не определена")
        }
        data class Release(val version: String, val title: String, val details: List<String>)
        val releases = listOf(
            Release("1.2.7", "Offline command test harness", listOf(
                "Версия повышена до 1.2.7 / versionCode 127.",
                "Добавлен автономный тест команд: проверка реестра, определения модели и preflight-блокировок.",
                "Добавлена кнопка ПРОГНАТЬ ТЕСТ КОМАНД (OFFLINE) на странице проверки команд.",
                "Тестовый режим гарантированно не отправляет BLE-пакеты и не выполняет облачные команды.",
                "Добавлены unit-тесты симулятора, включая проверку transmitted=false."
            )),
            Release("1.2.6", "Universal NIU capability core · multi-family profiles", listOf(
                "Версия повышена до 1.2.6 / versionCode 126; авторизация POST и резервный GET сохранены.",
                "Добавлено универсальное ядро профилей возможностей для NQi, MQi, UQi, GOVA, FX, RQi, FQi и KQi.",
                "Возможности облачного чтения отделены от команд удалённого управления; интерфейс может показывать поддержку по модели.",
                "LOCK/UNLOCK, поиск, режимы езды и сигнализация остаются заблокированными до подтверждения протокола для точной модели и прошивки.",
                "Добавлены unit-тесты определения семейств и безопасной матрицы возможностей."
            )),
            Release("1.0.4", "NIU Cloud · QR binding workflow · multi-vehicle profiles", listOf(
                "Добавлен вход в NIU Cloud для регионов GLOBAL/CHINA по исследованному NIU account API; OAuth NIU официально не заявлен.",
                "Session token хранится зашифрованно через Android Keystore; пароль не сохраняется.",
                "Добавлены отдельные карточки скутеров: SN, название, модель, VIN, BLE-адрес и локальный выбор устройства.",
                "Добавлен встроенный QR scanner для извлечения SN и ручной ввод в качестве резервного варианта.",
                "Добавлена повторная BLE-подключаемость к сохранённому адресу и опциональный Android BLE bond по явному действию.",
                "Импорт Cloud vehicles добавляет только уже привязанные к аккаунту скутеры; локальный QR/SN не выполняет передачу владения."
            )),
            Release("1.0.3", "Universal NIU · NQi / MQi / UQi / GOVA / FX / RQi / FQi / KQi", listOf(
                "Добавлен общий каталог линеек NIU и выбор варианта модели на экране скутера.",
                "Протокольный реестр отделяет облачные API от BLE и привязывает доказательства к точной модели и прошивке.",
                "UUID/чтение FX отключаются при выборе другой линейки; команды неизвестных моделей остаются заблокированными.",
                "Добавлены исследования NIU App API, ECU reverse engineering и KQi hardware hacking с ограничениями применимости.",
                "ИИ не может повышать UNKNOWN до VERIFIED; Ninebot/Xiaomi payload не используются для NIU."
            )),
            Release("1.0.2", "Scooter-first UI · command evidence preflight", listOf(
                "Экран скутера переработан: карточка FX, состояние BLE, быстрые действия, метрики и диагностика.",
                "LOCK/UNLOCK, BEEP, ALARM и RIDE MODE показывают доказательства и остаются заблокированными без подтверждённого FX payload.",
                "Реестр команд проверяет точную модель, доказательность, авторизацию владельца и неподвижность для опасных операций.",
                "GitHub Device Flow автоматически открывает официальный экран подтверждения после нажатия кнопки входа.",
                "AI handoff открывает ChatGPT и передаёт исходник/командный отчёт через Android chooser; встроенный OAuth/API не имитируется."
            )),
            Release("1.0.0", "NIU Mobility Studio · Adaptive Engineering IDE", listOf(
                "Первая продуктовая версия 1.0.0 / versionCode 100.",
                "Code Workspace: локальный multi-file проект, вкладки, создание и редактирование файлов.",
                "AI Code Agent в первоначальном 1.0.0; в 1.0.2 заменён на явный account handoff без API-ключей.",
                "GitHub Build Center: публикация исходников, запуск CI, получение APK и системная установка.",
                "Добавлен импорт исходного ZIP с защитой от Zip Slip и лимитами распаковки.",
                "Добавлен экспорт всего локального workspace в ZIP.",
                "Добавлен GitHub Actions workflow для Kotlin compile, unit tests и Debug APK build.",
                "Сохранены BLE/GATT, NFC, диагностика, медиа-профили и защищённое хранение credentials.",
                "On-device Gradle, multi-file autonomous AI agent, Git UI/Terminal, signed plugins и Release signing пока не реализованы."
            )),
            Release("0.11.0", "Adaptive Workspace Foundation", listOf(
                "Добавлена адаптивная навигация: нижняя панель на телефоне и боковая панель на планшетах/больших экранах.",
                "Последний открытый раздел восстанавливается после перезапуска приложения.",
                "Добавлены стабильные идентификаторы маршрутов и модель сессии Workspace.",
                "Исправлена обработка запоздалых BLE callback от предыдущего GATT-соединения.",
                "Добавлена поддержка новых callback Android 13+ для значений характеристик BLE.",
                "READ ALL пропускает известную защищённую характеристику 8ec94e33.",
                "Произвольная запись в известные proprietary NIU command/auth каналы заблокирована до подтверждения протокола.",
                "Сохранены существующие BLE, NFC, диагностика, AI handoff, дисплей и аудио функции."
            )),
            Release("0.10.1", "NIU AI Assistant и безопасная передача отчётов", listOf(
                "Добавлен раздел Настройки → NIU AI Assistant.",
                "Добавлена подготовка диагностического контекста и передача в выбранное приложение, включая ChatGPT, через системное меню Android.",
                "MAC-адрес скрывается; сырые HEX-значения исключены по умолчанию и добавляются только по явному согласию.",
                "Добавлены локальные счётчики AUTH FAIL, GATT timeout и активных Notify; они не объявляются автоматическим диагнозом.",
                "Сетевой AI backend не имитируется: подключение будет добавлено после выбора HTTPS-сервера; API-ключи не хранятся в APK."
            )),
            Release("0.9.1", "README и история обновлений", listOf(
                "Добавлено отдельное окно «О приложении» в настройках.",
                "В окне отображаются установленная версия, назначение приложения, основные функции и полная история релизов, описанных в README.",
                "README_RU.md обновлён: текущая версия исходников, структура функций и ограничения синхронизированы с релизом 0.9.1."
            )),
            Release("0.9.0", "Дисплей, музыка и звуковые эффекты FX", listOf(
                "Дисплей: выбор изображения, предпросмотр приборной панели, масштабирование, цвет акцента и локальное сохранение профиля.",
                "Музыка: локальный плейлист, воспроизведение, управление треками и проверка доступных Bluetooth-аудиовыходов Android.",
                "Звуки: импорт аудио/видео, извлечение аудиодорожки, предпрослушивание и локальное назначение POWER_ON / POWER_OFF / ALARM.",
                "Загрузка обоев и звуков в скутер не заявлена как работающая: формат передачи и подтверждения устройства пока не исследованы."
            )),
            Release("0.8.2", "Очередь BLE и системное сопряжение", listOf(
                "Все ATT-операции выполняются последовательно через общую GATT-очередь с тайм-аутом.",
                "Состояние Notify/Indicate подтверждается только после успешного callback записи CCCD.",
                "READ ALL пропускает HID service, недоступный обычному приложению без BLUETOOTH_PRIVILEGED.",
                "Добавлено стандартное системное BLE-сопряжение Android; оно не заменяет NIU binding и авторизацию.",
                "FIND распознаёт адреса NIU Link F8E1 и 8B2A."
            )),
            Release("0.8.0", "Интерфейс nRF Connect", listOf(
                "Разделы Scanner, Client, Logger и NIU Tools.",
                "Поиск BLE, фильтрация по имени/MAC, подключение, просмотр GATT, READ, Notify/Indicate и HEX-инспектор.",
                "Журнал BLE-операций, экспорт отчёта и инструменты GATT DISCOVER / READ ALL / FIND.",
                "Ручная запись доступна как универсальный BLE-инструмент; неизвестные NIU-команды автоматически не формируются."
            )),
            Release("0.7.4", "Прямые диагностические команды", listOf(
                "Добавлен последовательный READ ALL для характеристик, поддерживающих READ.",
                "Полученные значения отображаются в HEX-инспекторе и журнале; очередь сбрасывается при отключении.",
                "Пульт показывает прямые диагностические операции GATT DISCOVER, READ ALL, NOTIFY и BLE FIND.",
                "Инструкции, требующие доступа к оригинальному приложению NIU, исключены."
            )),
            Release("0.7.3", "Карта операций оригинального NIU-клиента", listOf(
                "Добавлена справочная карта найденных в APK имён методов сопряжения, проверки, шифрования и чтения настроек.",
                "UUID и имена методов рассматриваются как исследовательские подсказки, а не как готовый формат пакетов.",
                "Неизвестные управляющие payload не отправляются."
            )),
            Release("0.7.2", "Пробный BLE FIND", listOf(
                "Добавлено 20-секундное сканирование известных адресов и устройств NIU/LINK с отображением RSSI.",
                "Это поиск BLE-устройства, а не подтверждённая команда звукового поиска скутера."
            )),
            Release("0.7.1", "Безопасный экспериментальный пульт", listOf(
                "Добавлены чтение доступного Chip-to-App канала и включение/выключение Notify/Indicate.",
                "Показываются последние принятые значения и известные UUID.",
                "LOCK/UNLOCK, BEEP, ALARM и RIDE MODE остаются неактивными до подтверждения протокола.",
                "Улучшена обработка BLE callback и очистка состояния GATT при отключении."
            )),
            Release("0.7.0", "Панель управления скутером — подготовительный режим", listOf(
                "Добавлена отдельная вкладка пульта с карточками предполагаемых функций: замок, поиск, сигнализация, режим езды и запрос состояния.",
                "Карточки информируют о требуемых данных; команды не отправляются, пока payload и авторизация не подтверждены."
            )),
            Release("0.6.0 · NFC", "NFC Card Inspector", listOf(
                "Добавлено чтение NFC в режиме reader mode и определение поддерживаемых технологий.",
                "Для обычных NDEF-карт показываются записи, TNF/type, длина payload и доступность записи.",
                "Защищённые сектора, ключи и credential-данные не извлекаются и не эмулируются."
            )),
            Release("0.6.0 · BLE", "nRF Packet Inspector", listOf(
                "Добавлена побайтовая расшифровка READ/NOTIFY: индекс, HEX, DEC, ASCII и BIN.",
                "TXT-экспорт дополнен построчной расшифровкой байтов.",
                "Улучшена адаптация кнопок и компоновки для узких экранов."
            )),
            Release("0.4.0", "Сравнение BLE-отчётов", listOf(
                "Добавлен импорт TXT-эталона, извлечение UUID, свойств и VALUE, сравнение с текущим GATT.",
                "Добавлены статусы совпадения/отличия/отсутствия и экспорт результата.",
                "Сравнение структуры не доказывает эквивалентность команд или функций скутера."
            )),
            Release("0.3.0", "nRF Explorer и экспорт", listOf(
                "Добавлен BLE/GATT Explorer: сервисы, характеристики, свойства, READ и Notify/Indicate.",
                "Добавлен журнал событий и экспорт полного текстового отчёта, включая сохранение в TXT через системный диалог Android."
            ))
        )
        LazyColumn(
            Modifier.fillMaxSize().padding(pad),
            contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 20.dp, bottom = 30.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                PageHeader("ABOUT NIU MOBILITY STUDIO", "О приложении")
            }
            item {
                CardBlock {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        ComposeImage(
                            painter = painterResource(id = com.niu.fxstudio.R.drawable.niu_mobility_logo),
                            contentDescription = "Логотип приложения NIU Mobility Studio",
                            modifier = Modifier.size(64.dp),
                            contentScale = ContentScale.Fit
                        )
                        Text("NIU MOBILITY STUDIO", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("ВЕРСИЯ", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text(appVersion, color = Lime, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    }
                    Text("Android · FX Wind Strike research toolkit", color = Muted, fontSize = 12.sp)
                    Text("Самостоятельный инструмент для исследования BLE/GATT, диагностики и локальной персонализации. Приложение не требует входа в оригинальное NIU app.", color = Color.White, fontSize = 12.sp, lineHeight = 18.sp)
                }
            }
            item {
                CardBlock {
                    Text("ЧТО ВХОДИТ В ПРИЛОЖЕНИЕ", color = Lime, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    listOf(
                        "BLE Scanner и подключение к NIU Link",
                        "GATT Client: сервисы, характеристики, READ, Notify/Indicate",
                        "nRF Logger и экспорт диагностики в TXT",
                        "NFC Inspector для публичных NDEF-данных",
                        "Пульт с безопасными диагностическими операциями",
                        "Локальные редакторы обоев, музыки и звуковых профилей",
                        "Code Workspace: открыть и сохранить выбранный исходный файл",
                        "Вход в ChatGPT через официальный сайт и явная передача AI-отчётов через Android chooser",
                        "ZIP backup текущего открытого документа"
                    ).forEach { Text("• $it", color = Color.White, fontSize = 12.sp, lineHeight = 18.sp) }
                }
            }
            item {
                Text("ИСТОРИЯ ОБНОВЛЕНИЙ / README", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = .8.sp)
                Text("История содержит релизы, описанные в документации проекта. Нумерация 0.5.x и ранних прототипов в доступном README не документирована, поэтому такие версии здесь не выдумываются.", color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
            }
            items(releases) { release ->
                CardBlock {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("v${release.version}", color = Lime, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.width(9.dp))
                        Text(release.title, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                    release.details.forEach { detail ->
                        Text("• $detail", color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
                    }
                }
            }
            item {
                CardBlock {
                    Text("ВАЖНО: ГРАНИЦЫ РЕАЛИЗАЦИИ", color = Lime, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text("Управление замком, сиреной, режимом езды и загрузка обоев/звуков в приборную панель не считаются реализованными, пока не подтверждены BLE-протокол, авторизация, ответы устройства и фактический результат. Неизвестные команды не отправляются. Локальный предпросмотр и сохранение профиля не означают загрузку в скутер.", color = Color.White, fontSize = 11.sp, lineHeight = 17.sp)
                    Text("Полный файл документации проекта: README_RU.md в корне исходного архива.", color = Muted, fontSize = 10.sp)
                }
            }
        }
    }

    @Composable private fun SettingsEntry(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
        Card(
            modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
            colors = CardDefaults.cardColors(containerColor = Panel),
            shape = RoundedCornerShape(16.dp)
        ) {
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, null, tint = Lime, modifier = Modifier.size(25.dp))
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text(subtitle, color = Muted, fontSize = 10.sp)
                }
                TextButton(onClick = { activeHelp = HelpContent(title, subtitle) }, contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp)) {
                    Text("Подробнее", color = Lime, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }

    private fun pageHelpDescription(kicker: String, title: String): String = when (title) {
        "Дисплей и обои" -> "Выберите изображение, настройте масштаб и цвет акцента, затем сохраните локальный профиль. Важно: сейчас это локальный предпросмотр и сохранение на телефоне; загрузка обоев в приборную панель NIU не реализована, так как формат и подтверждение BLE-передачи ещё не установлены."
        "Музыка" -> "Выберите аудиофайлы или плейлист, используйте предыдущий/следующий трек, воспроизведение и громкость. Проверка аудиовыходов показывает маршруты Android. Воспроизведение выполняется телефоном и не загружает музыку в скутер."
        "Звуковые эффекты" -> "Выберите аудио- или видеофайл, прослушайте звук, задайте локальную тему, событие и способ срабатывания, затем сохраните профиль. Это локальные настройки приложения: передача звука в приборную панель или ECU не включена."
        "Редактор проекта" -> "Рабочая область для открытия и редактирования файлов проекта, импорта/экспорта ZIP, сохранения текущего файла и создания резервной копии. Перед изменениями используйте ZIP BACKUP. Сохранение файла не означает сборку или установку APK."
        "Инструменты" -> "Каталог разделов приложения. Нажмите карточку, чтобы открыть функцию. Значок информации у карточки объясняет назначение раздела; отдельные функции могут быть экспериментальными или работать только локально."
        "README и AI Agent Brief" -> "Просмотр документации проекта и краткого контекста для AI-агента. Кнопки экспорта создают файл в выбранном формате через системное окно Android. Экспорт не отправляет документ автоматически в интернет."
        "Telegram и локальный сервер" -> "Настройте профиль Telegram-бота, токен, разрешённые Chat ID и пользователей, проверьте токен и управляйте polling. Локальный API предоставляет GET /health и POST /notify. При включении LAN используется HTTP, поэтому не публикуйте порт в интернете и используйте длинный случайный ключ."
        "Поездки и обслуживание" -> "Локальный журнал пробега, следующего обслуживания, работ и поездок. Данные сохраняются на устройстве и привязаны к выбранному профилю транспорта. Экспорт истории запускает системное меню отправки Android. Отметки чек-листа не являются автоматической диагностикой ECU."
        "Помощник диагностики" -> "Подготовка диагностического отчёта для анализа AI. По умолчанию отчёт должен скрывать идентификаторы устройств, необработанные значения характеристик и секреты. Проверьте состав отчёта перед передачей внешнему сервису."
        "Связь со скутером" -> "Запустите BLE-сканирование, выберите устройство NIU и подключитесь. Кнопка «Отключить» завершает GATT-сессию, «Pair/Bond» вызывает системное сопряжение Android, а список устройств показывает имя, адрес и RSSI. Эти действия не заменяют привязку NIU Cloud."
        "Журнал событий" -> "Показывает диагностические сообщения приложения. Фильтры «Все», «Ошибки», «BLE» и «NIU Cloud» меняют только видимый список. TXT/MD/JSON/CSV сохраняют журнал в файл; mdpaste.ru копирует очищенный Markdown в буфер обмена и открывает сайт — публикация выполняется вручную после проверки текста. «Очистить» удаляет текущий список записей."
        "Диагностика" -> "Обновите список GATT-сервисов, просмотрите свойства характеристик, прочитайте доступные значения и сравните структуру с импортированным эталоном. Экспорт отчёта помогает диагностике. Наличие UUID или READ/WRITE-свойства само по себе не подтверждает назначение команды."
        "NFC-карта" -> "Считыватель работает в режиме чтения публичных NFC/NDEF-данных и показывает доступные технологии/записи. Защищённые сектора, ключи и платёжные или credential-данные не извлекаются и не эмулируются."
        "Профиль" -> "Справочная информация о профиле транспорта, поддерживаемых семействах и границах безопасной работы. Выбор семейства и модели влияет на применяемые описания и диагностические подсказки; он не доказывает совместимость неизвестных команд."
        "О приложении" -> "Версия установленной сборки, назначение проекта, список возможностей, журнал релизов и документированные ограничения. Если функция помечена как не подтверждённая, это означает, что она не должна считаться работающей на реальном скутере."
        else -> "$title\n\nРаздел: $kicker. Здесь собраны инструменты и настройки, относящиеся к этому разделу. Используйте значки информации рядом с действиями, чтобы увидеть назначение конкретной кнопки и ожидаемый результат. Не выполняйте неизвестные операции записи в BLE/GATT."
    }

    private fun actionHelpDescription(label: String): String {
        val key = label.uppercase(Locale.ROOT)
        return when {
            "НАЙТИ" in key || "СКАНИРОВАТЬ" in key || "BLE FIND" in key -> "Запускает BLE-поиск поблизости. Android может запросить разрешения Bluetooth/геолокации в зависимости от версии ОС. Поиск показывает обнаруженные устройства и не отправляет управляющие команды скутеру."
            "ОСТАНОВИТЬ" in key || "STOP" in key -> "Останавливает текущую операцию сканирования или воспроизведения. Текущее подключение BLE при этом не обязательно разрывается, если действие явно не называется «Отключить»."
            "ОТКЛЮЧИТЬ" in key || "DISCONNECT" in key -> "Завершает активное BLE-соединение и очищает текущую сессию GATT. Для повторной работы потребуется новое подключение."
            "ПОДКЛЮЧ" in key || "CONNECT" in key || "СОЕДИНЕНИ" in key -> "Открывает инструменты соединения или запускает подключение к выбранному устройству. Перед подключением проверьте имя и адрес устройства."
            "СОХРАНИТЬ TXT" in key || "ЭКСПОРТ" in key -> "Формирует файл или отчёт из текущих данных и открывает системный диалог Android для выбора места сохранения или приложения-получателя. Перед передачей проверьте наличие личных данных."
            "СОХРАНИТЬ" in key -> "Сохраняет текущие выбранные значения или данные в локальное хранилище/файл согласно подписи действия. Если не указано иное, данные не отправляются в NIU Cloud и не записываются в ECU."
            "ПОДЕЛИТЬСЯ" in key || "SHARE" in key || "ПЕРЕДАТЬ" in key -> "Формирует отчёт и передаёт его в системное меню «Поделиться» Android. Вы сами выбираете приложение-получатель. Проверьте конфиденциальность содержимого перед отправкой."
            "ВЫБРАТЬ" in key || "ИМПОРТ" in key || "ОТКРЫТЬ ФАЙЛ" in key -> "Открывает системный выбор файла Android. Выберите файл указанного типа; доступ предоставляется приложению только к выбранному документу/медиафайлу."
            "ПРОЧИТАТЬ" in key || "READ" in key -> "Запрашивает чтение выбранной GATT-характеристики или доступных для чтения характеристик. Результат отображается в интерфейсе и журнале. Чтение не гарантируется, если устройство отклоняет запрос."
            "PAIR" in key || "BOND" in key || "СОПРЯЖ" in key -> "Запускает системный процесс Bluetooth-сопряжения Android с выбранным устройством. Это не привязка к аккаунту NIU и не облачная авторизация."
            "ПРЕДЫДУЩ" in key || "NEXT" in key || "СЛЕДУЮЩ" in key -> "Переключает текущий элемент плейлиста на предыдущий или следующий. Действие доступно, когда в списке есть несколько файлов."
            "ОТКРЫТЬ НАСТРОЙКИ" in key || "BLUETOOTH SETTINGS" in key -> "Открывает системную страницу настроек Bluetooth Android, где можно включить Bluetooth и управлять сопряжёнными устройствами."
            "ПРОВЕРИТЬ АУДИОВЫХОД" in key -> "Запрашивает у Android список активных аудиомаршрутов, например встроенный динамик, проводную гарнитуру или Bluetooth A2DP."
            "MDPASTE" in key -> "Формирует очищенный Markdown-журнал и копирует его в буфер обмена, затем открывает mdpaste.ru. Вставку и публикацию на сайте нужно выполнить вручную; публикация может быть доступна другим людям."
            "ФИЛЬТР" in key || key in setOf("ВСЕ", "ОШИБКИ", "BLE", "NIU CLOUD") -> "Фильтрует отображаемые записи или варианты в текущем разделе. Исходные данные не удаляются."
            "ИЗМЕНИТЬ" in key || "EDIT" in key -> "Открывает форму изменения выбранной локальной записи. Изменения сохраняются только после подтверждения кнопкой сохранения."
            "УДАЛИТЬ" in key || "REMOVE" in key -> "Удаляет выбранную запись или секрет из локального хранилища приложения. Перед удалением убедитесь, что выбран нужный объект."
            "УВЕДОМЛ" in key || "NOTIFY" in key || "LIVE" in key -> "Включает или выключает подписку GATT Notify/Indicate для выбранной характеристики. Состояние меняется только после подтверждения операции устройством."
            "WRITE" in key || "ЗАПИСАТЬ" in key -> "Отправляет введённые байты в выбранную GATT-характеристику. Используйте только значения из подтверждённой документации именно вашей модели и прошивки: неизвестная запись может изменить состояние устройства."
            "ОБНОВИТЬ" in key || "REFRESH" in key -> "Повторно запрашивает данные или список элементов для текущего экрана. Операция не гарантирует обновление данных, если устройство/сервер недоступен."
            "ВХОД" in key || "ВОЙТИ" in key || "NIU CLOUD" in key -> "Открывает или запускает авторизацию NIU Cloud по выбранному региону. Вводите пароль только в штатное поле приложения. Ошибки сервера нужно проверять по журналу; успешная авторизация ещё не гарантирует загрузку списка транспорта."
            "ВЫЙТИ" in key || "LOG OUT" in key -> "Завершает текущую облачную сессию в приложении и удаляет сохранённые данные авторизации согласно настройкам безопасного хранилища."
            "ДОБАВИТЬ" in key -> "Добавляет новую запись в локальный список/историю после проверки введённых полей. Запись не отправляется в облако, если это отдельно не указано."
            "ОЧИСТИТЬ" in key || "CLEAR" in key -> "Удаляет записи из текущего локального списка или журнала. Это действие может быть необратимым; экспортируйте журнал заранее, если он нужен для диагностики."
            "PLAY" in key || "ПАУЗА" in key || "ВОСПРОИЗВ" in key -> "Управляет воспроизведением выбранного аудиофайла на Android-устройстве. Это не является командой скутеру."
            "ZIP" in key || "BACKUP" in key -> "Создаёт или экспортирует ZIP-архив выбранного проекта/Workspace для резервного копирования или переноса. Проверьте место сохранения и содержимое архива."
            "PULL" in key -> "Получает файлы проекта из выбранного GitHub-репозитория и ветки в локальный Workspace. Локальные файлы с совпадающими путями могут быть перезаписаны; перед загрузкой сделайте ZIP backup."
            "PUSH" in key -> "Публикует локальные файлы Workspace в выбранную ветку GitHub и запускает workflow сборки. Для работы требуется сохранённая авторизация GitHub. Проверьте diff и репозиторий перед отправкой."
            "ПРОВЕРИТЬ СБОРКУ" in key || "BUILD STATUS" in key -> "Запрашивает статус последнего GitHub Actions workflow для выбранного репозитория. Статус может быть queued, in progress, success или failure."
            "СКАЧАТЬ APK" in key || "DOWNLOAD APK" in key -> "Скачивает APK из артефактов последнего GitHub Actions workflow. Перед установкой проверьте, что выбран нужный репозиторий и сборка завершилась успешно."
            "СОЗДАТЬ РЕПОЗИТОРИЙ" in key -> "Создаёт новый private GitHub-репозиторий с указанным именем через сохранённую авторизацию. Проверьте название, так как повторно занять его может быть нельзя."
            "ПРОВЕРИТЬ ТОКЕН" in key || "GETME" in key -> "Проверяет Telegram bot token запросом getMe и отображает информацию о боте. Сам токен не показывается в журнале."
            "КОМАНДЫ БОТА" in key || "SETMYCOMMANDS" in key -> "Обновляет список команд, отображаемых в меню Telegram-бота. Настройки разрешённых пользователей и Chat ID применяются отдельно."
            "ЗАПУСТИТЬ СЕРВЕР" in key -> "Запускает локальный HTTP API в процессе приложения. Он может принимать запросы с устройства или локальной сети в зависимости от настройки LAN. Не открывайте этот порт в публичный интернет."
            "ОСТАНОВИТЬ СЕРВЕР" in key -> "Останавливает локальный HTTP API. Клиенты больше не смогут обращаться к его endpoint до следующего запуска."
            else -> "Выполняет действие «$label» в текущем разделе. Подробный статус и ошибки отображаются на экране или в журнале событий. Перед применением убедитесь, что выбрано правильное устройство и понимаете ожидаемый результат."
        }
    }

    // Inline help buttons were removed to keep action rows compact. Help is page-scoped.
    @Composable private fun InfoIconButton(title: String, description: String, modifier: Modifier = Modifier) { }

    @Composable private fun PageHelpButton(title: String, description: String, modifier: Modifier = Modifier) {
        IconButton(onClick = { activeHelp = HelpContent(title, description) }, modifier = modifier.size(40.dp)) {
            Icon(Icons.Default.Info, contentDescription = "Подсказка: $title", tint = Lime, modifier = Modifier.size(21.dp))
        }
    }

    @Composable private fun PageHeader(kicker: String, title: String, modifier: Modifier = Modifier) {
        Row(modifier.fillMaxWidth().padding(bottom = 20.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(kicker.uppercase(), color = Lime, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Text(title, color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            }
            PageHelpButton("О разделе: $title", pageHelpDescription(kicker, title))
        }
    }
    @Composable private fun Overview(pad: PaddingValues, openConnection: () -> Unit) {
        LazyColumn(Modifier.fillMaxSize().padding(pad), contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 22.dp, bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("NIU ELECTRIC MOBILITY", color = Lime, fontWeight = FontWeight.Black, letterSpacing = 2.5.sp, fontSize = 11.sp)
                        Text("Мой NIU", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 30.sp)
                    }
                    ComposeImage(
                        painter = painterResource(id = com.niu.fxstudio.R.drawable.niu_mobility_logo),
                        contentDescription = "Логотип NIU Mobility Studio",
                        modifier = Modifier.size(52.dp),
                        contentScale = ContentScale.Fit
                    )
                    PageHelpButton("Главная", pageHelpDescription("ОБЗОР", "Главная"))
                }
            }
            item {
                Box(Modifier.fillMaxWidth().height(238.dp).background(Brush.linearGradient(listOf(Color(0xFF303A2D), Color(0xFF171D18), Color(0xFF101210))), RoundedCornerShape(28.dp)).padding(22.dp)) {
                    Column(Modifier.align(Alignment.TopStart)) {
                        Text(selectedNiuModel.uppercase(), color = Color(0xFFB7C2B2), fontSize = 11.sp, letterSpacing = 3.sp, fontWeight = FontWeight.SemiBold)
                        Text(NiuModelCatalog.family(selectedNiuFamily)?.name ?: "NIU", color = Color.White, fontSize = 72.sp, fontWeight = FontWeight.Black, letterSpacing = (-7).sp, lineHeight = 88.sp)
                        Text("${NiuModelCatalog.family(selectedNiuFamily)?.name ?: "NIU"} · VEHICLE PROFILE", color = Lime, fontSize = 10.sp, letterSpacing = 2.5.sp)
                    }
                    Icon(Icons.Default.DirectionsBike, null, tint = Lime.copy(alpha = .20f), modifier = Modifier.align(Alignment.BottomEnd).size(150.dp))
                    Row(Modifier.align(Alignment.BottomStart), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        Box(Modifier.size(7.dp).background(if (connectedName != null) Lime else Muted, CircleShape))
                        Text(if (connectedName != null) "CONNECTED" else "READY TO CONNECT", color = Color.White, fontSize = 10.sp, letterSpacing = 1.5.sp)
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    MetricCard("BLUETOOTH", if (connectedName != null) "ONLINE" else "OFFLINE", Modifier.weight(1f), connectedName != null)
                    MetricCard("DATA LINK", if (serviceRows.isNotEmpty()) "DETECTED" else "STANDBY", Modifier.weight(1f), serviceRows.isNotEmpty())
                }
            }
            item {
                CardBlock {
                    Text("СОСТОЯНИЕ СИСТЕМЫ", color = Lime, fontSize = 10.sp, letterSpacing = 1.7.sp, fontWeight = FontWeight.Bold)
                    Text(connectionState, color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    Text(connectedName?.let { "$it · ${connectedAddress ?: "адрес скрыт"}" } ?: "Подключите скутер, чтобы определить BLE-сервисы и доступные характеристики.", color = Muted, fontSize = 12.sp)
                    PrimaryButton(if (connectedName != null) "УПРАВЛЕНИЕ СОЕДИНЕНИЕМ" else "НАЙТИ МОЙ NIU") { openConnection(); if (connectedName == null) ensurePermissions() }
                }
            }
            item {
                CardBlock {
                    Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Bluetooth, null, tint = Lime); Text("ЛОКАЛЬНАЯ СВЯЗЬ", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
                    Text("Штатная eSIM и заводские блоки не затрагиваются. До подтверждения протокола приложение работает в режиме чтения структуры BLE — без управляющих команд.", color = Muted, fontSize = 11.sp, lineHeight = 17.sp)
                }
            }
        }
    }
    @Composable private fun MetricCard(label: String, value: String, modifier: Modifier, good: Boolean) { Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(16.dp)) { Text(label, color = Muted, fontSize = 10.sp, letterSpacing = 1.sp); Spacer(Modifier.height(8.dp)); Text(value, color = if (good) Lime else Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp) } } }
    @Composable private fun CardBlock(content: @Composable ColumnScope.() -> Unit) { Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) { Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp), content = content) } }
    @Composable private fun PrimaryButton(label: String, onClick: () -> Unit) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = onClick, modifier = Modifier.weight(1f).heightIn(min = 48.dp), contentPadding = PaddingValues(horizontal = 18.dp, vertical = 10.dp), colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = Ink), shape = RoundedCornerShape(12.dp)) {
                Text(label, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
            }
            InfoIconButton(label, actionHelpDescription(label))
        }
    }
    @Composable private fun Connection(pad: PaddingValues) {
        Column(Modifier.fillMaxSize().padding(pad).padding(horizontal = 22.dp).padding(top = 26.dp)) {
            PageHeader("BLUETOOTH LOW ENERGY", "Связь со скутером")
            CardBlock { Row(verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("СОСТОЯНИЕ", color = Muted, fontSize = 10.sp); Text(connectionState, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold) }; Box(Modifier.size(10.dp).background(if (connectedName != null) Lime else Muted, CircleShape)) }; Text(connectedAddress ?: "Устройство не выбрано", color = Muted, fontSize = 12.sp) }
            Spacer(Modifier.height(12.dp)); Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Button(onClick = { if (scanning) stopScan() else ensurePermissions() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = Ink)) { Text(if (scanning) "ОСТАНОВИТЬ" else "СКАНИРОВАТЬ") }
                    InfoIconButton("BLE сканирование", actionHelpDescription("СКАНИРОВАТЬ"))
                }
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    OutlinedButton(onClick = { disconnect(); stopScan() }, modifier = Modifier.fillMaxWidth()) { Text("ОТКЛЮЧИТЬ") }
                    InfoIconButton("Отключить BLE", actionHelpDescription("ОТКЛЮЧИТЬ"))
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = { requestBleBond() }, enabled = connectedName != null, modifier = Modifier.weight(1f)) { Text("PAIR / BOND · СИСТЕМНОЕ СОПРЯЖЕНИЕ ANDROID") }
                InfoIconButton("Сопряжение Bluetooth", actionHelpDescription("PAIR / BOND"))
            }
            Spacer(Modifier.height(16.dp)); Text("НАЙДЕННЫЕ УСТРОЙСТВА · ${devices.size}", color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp)
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(devices) { d -> Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().clickable { connect(d) }) { Column(Modifier.padding(14.dp)) { Text(try { d.name ?: "Без имени" } catch (_: Exception) { "BLE устройство" }, color = Color.White, fontWeight = FontWeight.Bold); Text(try { d.address } catch (_: Exception) { "MAC недоступен" }, color = Muted, fontSize = 11.sp); Text("${signalByAddress[d.address] ?: "—"} dBm  ·  Нажмите для подключения", color = Lime, fontSize = 11.sp) } } }
            }
            if (devices.isEmpty()) Text("Нажмите «Сканировать». Включите Bluetooth и подойдите к скутеру.", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(vertical = 20.dp))
        }
    }
    @Composable private fun Diagnostics(pad: PaddingValues) {
        Column(Modifier.fillMaxSize().padding(pad).padding(horizontal = 22.dp).padding(top = 26.dp)) {
            PageHeader("SERVICE INSPECTOR", "Диагностика")
            CardBlock { Text("ОБНАРУЖЕННЫЕ GATT-СЕРВИСЫ", color = Muted, fontSize = 10.sp, letterSpacing = 1.sp); Text(if (serviceRows.isEmpty()) "Нет активной BLE-сессии" else "${serviceRows.size} сервис(а)", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold); Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        OutlinedButton(onClick = { refreshServices() }, modifier = Modifier.fillMaxWidth().heightIn(min = 44.dp)) { Text("ОБНОВИТЬ", maxLines = 1, fontSize = 10.sp) }
                        InfoIconButton("Обновить GATT-сервисы", actionHelpDescription("ОБНОВИТЬ"))
                    }
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        OutlinedButton(onClick = { shareDiagnostics() }, modifier = Modifier.fillMaxWidth().heightIn(min = 44.dp)) { Text("ПОДЕЛИТЬСЯ", maxLines = 1, fontSize = 10.sp) }
                        InfoIconButton("Поделиться диагностикой", actionHelpDescription("ПОДЕЛИТЬСЯ"))
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(onClick = { saveDiagnosticsTxt() }, modifier = Modifier.weight(1f).heightIn(min = 42.dp)) { Text("СОХРАНИТЬ TXT", maxLines = 1, fontSize = 10.sp) }
                    InfoIconButton("Сохранить TXT", actionHelpDescription("СОХРАНИТЬ TXT"))
                }
            } }
            Spacer(Modifier.height(10.dp)); LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(serviceRows) { row -> Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) { Text(row, color = Lime, fontSize = 10.sp, modifier = Modifier.padding(12.dp), lineHeight = 16.sp) } }
                item { Text("ЖУРНАЛ СОБЫТИЙ", color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp, modifier = Modifier.padding(top = 8.dp)) }
                items(logs) { line -> Text("›  $line", color = Muted, fontSize = 11.sp, modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(8.dp)).padding(9.dp)) }
            }
        }
    }
    @Composable private fun NrfExplorer(pad: PaddingValues) {
        var page by remember { mutableStateOf("Scanner") }
        var filter by remember { mutableStateOf("") }
        var selectedUuid by remember { mutableStateOf<String?>(null) }
        var writeHex by remember { mutableStateOf("01") }
        var showRaw by remember { mutableStateOf(true) }
        val expandedServices = remember { mutableStateMapOf<String, Boolean>() }
        val selected = characteristicRows.firstOrNull { it.uuid == selectedUuid }
        val serviceGroups = characteristicRows.groupBy { it.serviceUuid }
        val visibleDevices = devices.filter { d ->
            val name = runCatching { d.name.orEmpty() }.getOrDefault("")
            val address = runCatching { d.address }.getOrDefault("")
            filter.isBlank() || name.contains(filter, true) || address.contains(filter, true)
        }
        Column(Modifier.fillMaxSize().padding(pad).background(Ink)) {
            Row(Modifier.fillMaxWidth().background(Color(0xFF202124)).padding(horizontal = 16.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Bluetooth, null, tint = Color(0xFF8AB4F8), modifier = Modifier.size(25.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("nRF Connect", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
                    Text("NIU Mobility · BLE Explorer", color = Color(0xFF9AA0A6), fontSize = 10.sp)
                }
                Box(Modifier.size(8.dp).background(if (connectedName != null) Color(0xFF81C995) else Color(0xFF9AA0A6), CircleShape))
                Spacer(Modifier.width(6.dp))
                Text(if (connectedName != null) "CONNECTED" else "OFFLINE", color = Color(0xFFBDC1C6), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                InfoIconButton("nRF Connect / BLE Explorer", "Scanner ищет BLE-устройства; Client показывает GATT-сервисы и свойства; Logger отображает события и значения; NIU содержит дополнительные сведения о найденном устройстве. READ только считывает данные, Notify/Indicate подписывает на обновления, WRITE отправляет байты и требует подтверждённого протокола.")
            }
            Row(Modifier.fillMaxWidth().background(Color(0xFF202124)).horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                listOf("Scanner", "Client", "Logger", "NIU").forEach { label ->
                    val active = page == label
                    Column(Modifier.clickable { page = label }.padding(horizontal = 13.dp, vertical = 11.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(label, color = if (active) Color(0xFF8AB4F8) else Color(0xFFBDC1C6), fontSize = 12.sp, fontWeight = if (active) FontWeight.Bold else FontWeight.Medium)
                        Spacer(Modifier.height(7.dp))
                        Box(Modifier.width(42.dp).height(2.dp).background(if (active) Color(0xFF8AB4F8) else Color.Transparent, RoundedCornerShape(2.dp)))
                    }
                }
            }
            when (page) {
                "Scanner" -> {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("NEARBY DEVICES", color = Color(0xFF9AA0A6), fontSize = 10.sp, letterSpacing = 1.sp, modifier = Modifier.weight(1f))
                        Text("${devices.size} found", color = Color(0xFFBDC1C6), fontSize = 10.sp)
                    }
                    OutlinedTextField(value = filter, onValueChange = { filter = it }, modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp), singleLine = true, placeholder = { Text("Filter name or address…", color = Color(0xFF80868B), fontSize = 12.sp) }, textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 13.sp), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Color(0xFF8AB4F8), unfocusedBorderColor = Color(0xFF5F6368), cursorColor = Color(0xFF8AB4F8)))
                    Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                            Button(onClick = { if (scanning) stopScan() else ensurePermissions() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8AB4F8), contentColor = Color(0xFF202124))) { Text(if (scanning) "STOP SCAN" else "SCAN", fontWeight = FontWeight.Bold) }
                            InfoIconButton("BLE Scan", actionHelpDescription(if (scanning) "STOP SCAN" else "SCAN"))
                        }
                        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                            OutlinedButton(onClick = { disconnect() }, modifier = Modifier.fillMaxWidth(), enabled = connectedName != null) { Text("DISCONNECT", color = Color(0xFFBDC1C6)) }
                            InfoIconButton("BLE Disconnect", actionHelpDescription("DISCONNECT"))
                        }
                    }
                    LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 18.dp)) {
                        items(visibleDevices) { d ->
                            val name = runCatching { d.name ?: "Unknown device" }.getOrDefault("BLE device")
                            val address = runCatching { d.address }.getOrDefault("—")
                            Column(Modifier.fillMaxWidth().clickable { connect(d); page = "Client" }.padding(horizontal = 16.dp, vertical = 11.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Bluetooth, null, tint = if (address == connectedAddress) Color(0xFF81C995) else Color(0xFF8AB4F8), modifier = Modifier.size(20.dp))
                                    Spacer(Modifier.width(13.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(name, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                                        Text(address, color = Color(0xFF9AA0A6), fontSize = 11.sp)
                                    }
                                    Text("${signalByAddress[address] ?: "—"} dBm", color = Color(0xFFBDC1C6), fontSize = 11.sp)
                                }
                            }
                            Divider(color = Color(0xFF303134), thickness = .7.dp)
                        }
                        if (visibleDevices.isEmpty()) item { Text(if (scanning) "Scanning for BLE devices…" else "Нажмите SCAN для поиска устройств поблизости", color = Color(0xFF9AA0A6), fontSize = 12.sp, modifier = Modifier.padding(18.dp)) }
                    }
                }
                "Client" -> {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(connectedName ?: "No device connected", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                            Text(connectedAddress ?: connectionState, color = Color(0xFF9AA0A6), fontSize = 11.sp)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            TextButton(onClick = { refreshServices() }, enabled = connectedName != null) { Text("REFRESH", color = Color(0xFF8AB4F8)) }
                            InfoIconButton("Обновить GATT", actionHelpDescription("REFRESH GATT"))
                        }
                    }
                    if (selected != null) {
                        Column(Modifier.fillMaxWidth().background(Color(0xFF292A2D)).padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("CHARACTERISTIC", color = Color(0xFF8AB4F8), fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                TextButton(onClick = { selectedUuid = null }) { Text("CLOSE", color = Color(0xFFBDC1C6)) }
                            }
                            Text(selected.uuid, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                            Text("Properties: ${propertiesLabel(selected.properties)}", color = Color(0xFF9AA0A6), fontSize = 10.sp)
                            Spacer(Modifier.height(8.dp))
                            PacketValueView(characteristicValues[selected.uuid])
                            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                                if (selected.properties and BluetoothGattCharacteristic.PROPERTY_READ != 0) {
                                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                                        OutlinedButton(onClick = { readCharacteristic(selected.uuid) }, modifier = Modifier.fillMaxWidth()) { Text("READ") }
                                        InfoIconButton("GATT READ", actionHelpDescription("READ"))
                                    }
                                }
                                if (selected.properties and (BluetoothGattCharacteristic.PROPERTY_NOTIFY or BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0) {
                                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                                        OutlinedButton(onClick = { toggleNotifications(selected.uuid, notifyStates[selected.uuid] != true) }, modifier = Modifier.fillMaxWidth()) { Text(if (notifyStates[selected.uuid] == true) "STOP NOTIFY" else "NOTIFY") }
                                        InfoIconButton("GATT Notify / Indicate", actionHelpDescription("NOTIFY"))
                                    }
                                }
                            }
                            if (selected.properties and (BluetoothGattCharacteristic.PROPERTY_WRITE or BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0) {
                                Text("MANUAL WRITE · HEX", color = Color(0xFFFFC66D), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                OutlinedTextField(value = writeHex, onValueChange = { writeHex = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 12.sp), placeholder = { Text("01 0A FF") })
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Button(onClick = { writeCharacteristicHex(selected.uuid, writeHex) }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3C4043))) { Text("WRITE RAW HEX", color = Color.White) }
                                    OutlinedButton(onClick = { val uuid = lastBleWriteUuid; if (uuid != null && lastBleWriteHex.isNotBlank()) writeCharacteristicHex(uuid, lastBleWriteHex) else addLog("REPEAT: ещё нет предыдущей отправки") }, enabled = lastBleWriteUuid != null, modifier = Modifier.weight(1f)) { Text("REPEAT LAST") }
                                    InfoIconButton("GATT Write Raw HEX", actionHelpDescription("WRITE RAW HEX"))
                                }
                                Text(if (selected.uuid.equals("8ec94e33-f315-4f60-9fb8-838830daea52", true)) "Защищённый AUTH-канал: RAW WRITE отключён. Для 8ec94e32 и 99ea30e2 доступны экспериментальные записи вручную. Используйте только известные из собственных захватов пакеты; GATT_SUCCESS не подтверждает действие ECU." else "ЭКСПЕРИМЕНТАЛЬНЫЙ WRITE: отправляет ровно введённые HEX-байты. Не отправляйте пакеты при движении; неизвестные команды могут изменить состояние скутера. GATT_SUCCESS не означает подтверждение ECU.", color = Color(0xFFFFC66D), fontSize = 9.sp)
                            }
                        }
                    }
                    if (bleCommandResults.isNotEmpty()) {
                        Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp).background(Color(0xFF202124), RoundedCornerShape(10.dp)).padding(10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("РЕЗУЛЬТАТЫ КОМАНД", color = Color(0xFF8AB4F8), fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                Text("${bleCommandResults.size}", color = Color(0xFF9AA0A6), fontSize = 10.sp)
                            }
                            bleCommandResults.take(6).forEach { result ->
                                val (statusLabel, statusColor) = when (result.state) {
                                    "ERROR", "TIMEOUT" -> (if (result.state == "TIMEOUT") "ОШИБКА · НЕТ ОТВЕТА" else "ОШИБКА ОТПРАВКИ") to Color(0xFFF28B82)
                                    "RX_RECEIVED" -> "ОТВЕТ ПОЛУЧЕН · ACK НЕ ПРОВЕРЕН" to Color(0xFF81C995)
                                    "SENT_WAITING" -> "ОТПРАВЛЕНО · ОЖИДАНИЕ ОТВЕТА" to Color(0xFFFFC66D)
                                    "INTERRUPTED" -> "ПРЕРВАНО" to Color(0xFF9AA0A6)
                                    else -> "ОТПРАВКА" to Color(0xFF8AB4F8)
                                }
                                Column(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("#${result.id}  $statusLabel", color = statusColor, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                        Text(result.uuid.take(8), color = Color(0xFF9AA0A6), fontSize = 9.sp)
                                    }
                                    Text(result.detail, color = Color(0xFFBDC1C6), fontSize = 10.sp)
                                    Text("TX: ${result.payload}", color = Color(0xFF9AA0A6), fontSize = 9.sp, maxLines = 2)
                                }
                            }
                        }
                    }
                    LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 16.dp)) {
                        if (serviceGroups.isEmpty()) item { Text("Подключитесь к NIU Link или другому BLE-устройству через Scanner.", color = Color(0xFF9AA0A6), fontSize = 12.sp, modifier = Modifier.padding(18.dp)) }
                        serviceGroups.forEach { (serviceUuid, chars) ->
                            item(key = serviceUuid) {
                                val expanded = expandedServices[serviceUuid] ?: true
                                Column(Modifier.fillMaxWidth().clickable { expandedServices[serviceUuid] = !expanded }.padding(horizontal = 14.dp, vertical = 12.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(if (expanded) "▾" else "▸", color = Color(0xFF8AB4F8), fontSize = 17.sp)
                                        Spacer(Modifier.width(10.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(if (serviceUuid == "8ec94e30-f315-4f60-9fb8-838830daea52") "NIU LINK DATA CHANNEL" else if (serviceUuid == "61751276-fdd6-11ed-be56-0242ac120002") "NIU LINK CONTROL SERVICE" else "PRIMARY SERVICE", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                            Text(serviceUuid, color = Color(0xFF9AA0A6), fontSize = 9.sp)
                                        }
                                        Text("${chars.size} chars", color = Color(0xFF9AA0A6), fontSize = 9.sp)
                                    }
                                }
                                Divider(color = Color(0xFF3C4043))
                            }
                            if (expandedServices[serviceUuid] != false) items(chars) { ch ->
                                val props = propertiesLabel(ch.properties)
                                Column(Modifier.fillMaxWidth().clickable { selectedUuid = ch.uuid }.background(if (selectedUuid == ch.uuid) Color(0xFF292A2D) else Color.Transparent).padding(start = 48.dp, end = 14.dp, top = 10.dp, bottom = 10.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f)) {
                                            Text(ch.uuid, color = if (selectedUuid == ch.uuid) Color(0xFF8AB4F8) else Color.White, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                                            Text(props, color = Color(0xFF9AA0A6), fontSize = 9.sp)
                                        }
                                        Text(when { notifyStates[ch.uuid] == true -> "NOTIFY"; ch.properties and BluetoothGattCharacteristic.PROPERTY_READ != 0 -> "READ"; else -> "GATT" }, color = Color(0xFF9AA0A6), fontSize = 9.sp)
                                    }
                                    characteristicValues[ch.uuid]?.let { Text(it.take(100), color = Color(0xFFBDC1C6), fontSize = 9.sp, maxLines = 2, overflow = TextOverflow.Ellipsis) }
                                }
                                Divider(color = Color(0xFF303134), thickness = .6.dp)
                            }
                        }
                    }
                }
                "Logger" -> {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("BLE EVENT LOG", color = Color(0xFF9AA0A6), fontSize = 10.sp, letterSpacing = 1.sp, modifier = Modifier.weight(1f))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            TextButton(onClick = { shareDiagnostics() }) { Text("SHARE", color = Color(0xFF8AB4F8)) }
                            InfoIconButton("Поделиться журналом BLE", actionHelpDescription("SHARE"))
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            TextButton(onClick = { saveText(buildExportReport(), "NIU_nRF_LOG_${System.currentTimeMillis()}.txt") }) { Text("SAVE TXT", color = Color(0xFF8AB4F8)) }
                            InfoIconButton("Сохранить BLE TXT", actionHelpDescription("SAVE TXT"))
                        }
                    }
                    LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)) {
                        items(logs) { line -> Text(line, color = Color(0xFFBDC1C6), fontSize = 10.sp, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) ; Divider(color = Color(0xFF303134), thickness = .5.dp) }
                    }
                }
                else -> {
                    LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        item {
                            Text("NIU MOBILITY TOOLS", color = Color(0xFF8AB4F8), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                            Text("Специализированные функции для NIU Link", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                            Text("Оригинальное приложение NIU не требуется. Здесь используются только обнаруженные GATT-сервисы и доступные свойства.", color = Color(0xFF9AA0A6), fontSize = 11.sp)
                        }
                        item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { if (scanning) stopScan() else ensurePermissions() }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8AB4F8), contentColor = Color(0xFF202124))) { Text(if (scanning) "STOP" else "BLE FIND") }
                            OutlinedButton(onClick = { refreshServices() }, modifier = Modifier.weight(1f), enabled = connectedName != null) { Text("GATT DISCOVER") }
                        } }
                        item { Button(onClick = { runProtocolSurvey() }, modifier = Modifier.fillMaxWidth(), enabled = connectedName != null, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF246B55))) { Text("ПОЛНОЕ ИССЛЕДОВАНИЕ ПРОТОКОЛА", color = Color.White) } }
                        item { Text("Пассивный сбор: GATT UUID/свойства/дескрипторы, MTU, RSSI, READ и входящие NOTIFY. Неизвестные управляющие payload не отправляются.", color = Color(0xFF9AA0A6), fontSize = 10.sp) }
                        item { Button(onClick = { readAllAvailable() }, modifier = Modifier.fillMaxWidth(), enabled = connectedName != null, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3C4043))) { Text("READ ALL · SEQUENTIAL", color = Color.White) } }
                        item { Text("NIU UUID MAP", color = Color(0xFF8AB4F8), fontSize = 10.sp, fontWeight = FontWeight.Bold) }
                        item { Text("8ec94e31 — Chip → App · Read/Notify\n8ec94e32 — App → Chip candidate · Read/Write\n8ec94e33 — protected characteristic\n99ea30e2 — Write Without Response", color = Color(0xFFBDC1C6), fontSize = 10.sp, lineHeight = 17.sp) }
                        item { Text("Неизвестные команды LOCK / UNLOCK / BEEP / ALARM / RIDE MODE не отправляются: их payload не подтверждён.", color = Color(0xFFFFC66D), fontSize = 10.sp) }
                    }
                }
            }
        }
    }

    @Composable private fun PacketValueView(hexValue: String?) {
        val tokens = remember(hexValue) { hexValue.orEmpty().trim().split(Regex("\\s+")).filter { it.matches(Regex("[0-9A-Fa-f]{2}")) } }
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("ДАННЫЕ ПАКЕТА", color = Muted, fontSize = 9.sp, letterSpacing = 1.sp)
                Spacer(Modifier.weight(1f))
                Text("${tokens.size} BYTE", color = Lime, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }
            if (tokens.isEmpty()) {
                Text("Значение ещё не получено · нажмите READ или включите NOTIFY", color = Muted, fontSize = 10.sp)
            } else {
                Text(tokens.joinToString(" "), color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Medium, modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()))
                Text("Каждый байт отдельно · HEX / DEC / ASCII / BIN", color = Muted, fontSize = 9.sp)
                tokens.chunked(4).forEachIndexed { rowIndex, chunk ->
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                        chunk.forEachIndexed { colIndex, token ->
                            val value = token.toIntOrNull(16) ?: 0
                            val ascii = if (value in 32..126) value.toChar().toString() else "·"
                            Column(Modifier.weight(1f).background(Panel2, RoundedCornerShape(9.dp)).padding(vertical = 7.dp, horizontal = 5.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("#${rowIndex * 4 + colIndex}", color = Muted, fontSize = 8.sp)
                                Text(token.uppercase(), color = Lime, fontSize = 15.sp, fontWeight = FontWeight.Black)
                                Text("DEC $value", color = Color.White, fontSize = 8.sp)
                                Text("ASCII $ascii", color = Muted, fontSize = 8.sp)
                                Text(value.toString(2).padStart(8, '0'), color = Muted, fontSize = 7.sp, maxLines = 1)
                            }
                        }
                        repeat(4 - chunk.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
        }
    }

    @Composable private fun NfcInspector(pad: PaddingValues) {
        LazyColumn(
            Modifier.fillMaxSize().padding(pad),
            contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 20.dp, bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { PageHeader("CARD READER · READ ONLY", "NFC-карта") }
            item {
                CardBlock {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("СОСТОЯНИЕ СЧИТЫВАТЕЛЯ", color = Lime, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                            Text(if (nfcAdapter == null) "NFC недоступен" else nfcStatus, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            Text("Поднесите карту доступа к задней панели телефона", color = Muted, fontSize = 11.sp)
                        }
                        Icon(Icons.Default.Bluetooth, null, tint = Lime, modifier = Modifier.size(30.dp))
                    }
                    Text("Последнее обнаружение: ${nfcLastReadAt ?: "—"}", color = Muted, fontSize = 10.sp)
                }
            }
            item {
                CardBlock {
                    Text("ЧТО МОЖНО ПРОВЕРИТЬ", color = Lime, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    Text("• Поддерживаемые NFC-технологии карты\n• Наличие NDEF и число записей\n• Тип, формат и длину публичных NDEF-записей\n• Доступную ёмкость и признак записи", color = Color.White, fontSize = 12.sp, lineHeight = 19.sp)
                }
            }
            item {
                CardBlock {
                    Text("ОТЧЁТ КАРТЫ", color = Lime, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    Text(nfcReport, color = Color.White, fontSize = 10.sp, lineHeight = 16.sp)
                    OutlinedButton(
                        onClick = { shareText(nfcReport, "NIU FX NFC card inspection") },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 44.dp)
                    ) { Text("ПОДЕЛИТЬСЯ ОТЧЁТОМ", maxLines = 1, fontSize = 10.sp) }
                    Button(
                        onClick = { saveText(nfcReport, "NIU_FX_NFC_${System.currentTimeMillis()}.txt") },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 46.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = Ink)
                    ) { Text("СОХРАНИТЬ TXT", maxLines = 1, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                }
            }
            item {
                CardBlock {
                    Text("ВАЖНО О КАРТАХ ДОСТУПА", color = Color(0xFFFFC66D), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    Text("Многие карты скутеров используют защищённые сектора и криптографическую аутентификацию, а не обычный NDEF. В таком случае Android может определить тип карты, но не прочитать данные доступа. Приложение не извлекает UID, секретные ключи или защищённые данные, не копирует карту и не эмулирует её. Для добавления нового ключа используйте штатную процедуру NIU.", color = Muted, fontSize = 11.sp, lineHeight = 17.sp)
                }
            }
        }
    }

    private fun shareFxCommandEvidence() {
        val report = buildString {
            appendLine("NIU Mobility Studio ${BuildConfig.VERSION_NAME} · FX Wind Strike")
            appendLine("Задача: независимо оценить доказательства команд и предложить безопасный план проверки. Не генерировать BLE payload из догадок.")
            appendLine("GATT: 8ec94e31 Chip→App candidate; 8ec94e32 App→Chip WRITE candidate; 8ec94e33 protected/auth fail 0x89; 99ea30e2 WNR unknown.")
            appendLine("Команды: LOCK/UNLOCK, FIND/BEEP, ALARM, RIDE MODE, STATUS/BATTERY — нет подтверждённых FX payload/ACK.")
            appendLine("Текущий статус связи: $connectionState")
            appendLine("Последнее значение status: ${characteristicValues["8ec94e31-f315-4f60-9fb8-838830daea52"] ?: "not captured"}")
            appendLine("Правило: не рекомендовать запись, обход pairing/owner binding, OTA, factory reset или speed-limit modification без точной модельной спецификации и штатной авторизации.")
            appendLine("Источники/ограничения: protocol-docs/OPEN_SOURCE_PROTOCOL_RESEARCH_RU.md; открытые Ninebot/Xiaomi проекты не являются FX протоколом.")
        }
        val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_SUBJECT, "NIU FX — анализ доказательств BLE-команд"); putExtra(Intent.EXTRA_TEXT, report) }
        runCatching { startActivity(Intent.createChooser(send, "Передать доказательства в AI")) }
            .onFailure { addLog("AI handoff command evidence failed: ${it.message}") }
    }

    @Composable private fun ScooterControl(pad: PaddingValues) {
        val statusUuid = "8ec94e31-f315-4f60-9fb8-838830daea52"
        val statusRow = characteristicRows.firstOrNull { it.uuid.equals(statusUuid, true) }
        val canReadStatus = statusRow?.let { it.properties and BluetoothGattCharacteristic.PROPERTY_READ != 0 } == true
        val canNotifyStatus = statusRow?.let { it.properties and (BluetoothGattCharacteristic.PROPERTY_NOTIFY or BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0 } == true
        val latestStatus = characteristicValues[statusUuid]
        val linked = connectedName != null
        val selectedCloudVehicle = niuCloudVehicles.firstOrNull { it.serial.equals(activeVehicleSerial, true) }
        val cloudDataForDetails = niuCloudTelemetry?.takeIf { it.serial.equals(activeVehicleSerial, true) }
        val selectedLocalVehicle = savedVehicles.firstOrNull { it.serial.equals(activeVehicleSerial, true) }
        val bridgeReport = remember(activeVehicleSerial, selectedCloudVehicle, connectedName, characteristicValues.size) {
            CloudEcuBridge.correlate(
                selectedCloudVehicle?.let { CloudVehicleIdentity(it.serial, it.name, it.serverIdentityText(), it.vin) },
                if (linked) BleVehicleIdentity(
                    advertisedName = connectedName.orEmpty(),
                    firmware = characteristicValues.entries.firstOrNull { it.key.contains("firmware", true) }?.value.orEmpty()
                ) else null
            )
        }
        val cloudSessionPresent = SecureSecretStore(getSharedPreferences("niu_secure_secrets", MODE_PRIVATE)).contains("niu_cloud_session_token")
        val commandRegistry = remember { NiuCommandRegistry() }
        val commandTestSimulator = remember { NiuCommandTestSimulator(commandRegistry) }
        val selectedFamily = NiuModelCatalog.family(selectedNiuFamily) ?: NiuModelCatalog.family("other")!!
        var cloudPickerExpanded by remember { mutableStateOf(false) }
        var cloudDetailsExpanded by remember { mutableStateOf(false) }
        var cloudVehicleDetailsExpanded by remember { mutableStateOf(false) }
        var vehicleActionMenuSerial by remember { mutableStateOf("") }
        LazyColumn(
            Modifier.fillMaxSize().padding(pad),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("МОЙ NIU · ${selectedFamily.name.uppercase()}", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                        Text(if (selectedNiuFamily == "fx") "FX Wind Strike" else selectedFamily.name, color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    }
                    InfoIconButton("Управление скутером", "Пульт NIU показывает профиль модели и состояние BLE. Подключение и чтение доступны при подтверждении со стороны устройства. LOCK/UNLOCK, сигнал, режим езды и сигнализация сейчас неактивны: подтверждённые payload и ответы ECU отсутствуют.")
                    Surface(color = if (linked) Color(0xFF173B2B) else Panel2, shape = RoundedCornerShape(30.dp)) {
                        Row(Modifier.padding(horizontal = 11.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(7.dp).background(if (linked) Color(0xFF48D597) else Muted, CircleShape))
                            Spacer(Modifier.width(7.dp))
                            Text(if (linked) "ПОДКЛЮЧЁН" else "НЕ В СЕТИ", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("NIU CLOUD", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Text(selectedCloudVehicle?.name ?: "Скутер не выбран", color = Muted, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            Box {
                                OutlinedButton(onClick = { cloudPickerExpanded = true }, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp), shape = RoundedCornerShape(10.dp)) { Text("ВЫБРАТЬ ▾", fontSize = 9.sp) }
                                DropdownMenu(expanded = cloudPickerExpanded, onDismissRequest = { cloudPickerExpanded = false }) {
                                    if (niuCloudVehicles.isEmpty()) {
                                        DropdownMenuItem(text = { Text("Список Cloud пуст") }, onClick = { cloudPickerExpanded = false }, enabled = false)
                                    }
                                    niuCloudVehicles.forEach { cloudVehicle ->
                                        DropdownMenuItem(
                                            text = { Column { Text(cloudVehicle.name.ifBlank { "NIU Scooter" }); Text("${cloudVehicle.model.ifBlank { "Модель не указана" }} · ${cloudVehicle.serial}", fontSize = 10.sp, color = Muted) } },
                                            onClick = {
                                                activeVehicleSerial = cloudVehicle.serial
                                                val local = savedVehicles.firstOrNull { it.serial.equals(cloudVehicle.serial, true) }
                                                if (local != null) { selectedNiuFamily = local.familyId; selectedNiuModel = local.model }
                                                persistSavedVehicles()
                                                cloudPickerExpanded = false
                                                addLog("CLOUD vehicle selected · SN=${cloudVehicle.serial.take(3)}•••")
                                            }
                                        )
                                    }
                                }
                            }
                            Surface(color = if (selectedCloudVehicle != null) Color(0xFF173B2B) else Panel2, shape = RoundedCornerShape(20.dp)) {
                                Text(if (selectedCloudVehicle != null) "СОВПАДЕНИЕ" else if (cloudSessionPresent) "НЕ СВЯЗАНО" else "OFFLINE", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp))
                            }
                        }
                        if (activeVehicleSerial.isBlank()) {
                            Text("Сначала выберите скутер в списке устройств.", color = Muted, fontSize = 10.sp)
                        } else if (selectedCloudVehicle != null) {
                            Text("Cloud: ${selectedCloudVehicle.name}", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            Text("SN: ${selectedCloudVehicle.serial} · модель: ${selectedCloudVehicle.model.ifBlank { "не указана" }}", color = Muted, fontSize = 9.sp)
                            if (selectedCloudVehicle.vin.isNotBlank()) Text("VIN: ${selectedCloudVehicle.vin}", color = Muted, fontSize = 9.sp)
                            val modelMismatch = selectedLocalVehicle != null && selectedCloudVehicle.model.isNotBlank() && selectedLocalVehicle.model.isNotBlank() && !selectedCloudVehicle.model.equals(selectedLocalVehicle.model, true)
                            if (modelMismatch) Text("Модель Cloud и локальный профиль различаются", color = Color(0xFFFFC66D), fontSize = 9.sp)
                            TextButton(onClick = { cloudVehicleDetailsExpanded = true }, contentPadding = PaddingValues(0.dp)) { Text("ПОДРОБНЕЕ О МОДЕЛИ И VIN", fontSize = 9.sp) }
                        } else {
                            Text(if (cloudSessionPresent) "Скутер не найден в последнем списке Cloud. Выполните синхронизацию." else "Войдите в NIU Cloud, чтобы связать локальный профиль с облачной записью." , color = Muted, fontSize = 10.sp)
                        }
                        Text(
                            "ECU ENGINE · ${bridgeReport.match.name.replace('_', ' ')}",
                            color = if (bridgeReport.match.name.startsWith("EXACT")) Color(0xFF48D597) else Color(0xFFFFC66D),
                            fontSize = 9.sp, fontWeight = FontWeight.Bold
                        )
                        Text("${bridgeReport.detectedFamilyId ?: "Модель не определена"} · ${if (linked) "BLE подключён" else "BLE не подключён"}", color = Muted, fontSize = 9.sp)
                        TextButton(onClick = { cloudDetailsExpanded = true }, contentPadding = PaddingValues(0.dp)) { Text("ПОДРОБНЕЕ О СВЯЗИ CLOUD ↔ ECU", fontSize = 9.sp) }
                        Divider(color = Panel2)
                        Text("ТЕЛЕМЕТРИЯ NIU CLOUD", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                        Text(niuCloudTelemetryStatus.take(100), color = Muted, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        val cloudData = niuCloudTelemetry?.takeIf { it.serial.equals(activeVehicleSerial, true) }
                        if (cloudData != null) {
                            val ageSeconds = ((System.currentTimeMillis() - cloudData.fetchedAtEpochMs) / 1000L).coerceAtLeast(0)
                            Text("Обновлено ${ageSeconds} сек. назад · источник: NIU Cloud", color = Muted, fontSize = 8.sp)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Column(Modifier.weight(1f)) {
                                    Text("ПРОБЕГ", color = Muted, fontSize = 8.sp)
                                    Text(cloudData.totalMileageKm?.let { "${it.toInt()} км" } ?: "—", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                                }
                                Column(Modifier.weight(1f)) {
                                    Text("ЗАПАС ХОДА", color = Muted, fontSize = 8.sp)
                                    Text(cloudData.estimatedRangeKm?.let { "${it.toInt()} км" } ?: "—", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                                }
                                Column(Modifier.weight(1f)) {
                                    Text("СКОРОСТЬ", color = Muted, fontSize = 8.sp)
                                    Text(cloudData.speedKmh?.let { "${"%.1f".format(Locale.US, it)} км/ч" } ?: "—", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            Text("${when (cloudData.vehicleConnected) { true -> "На связи"; false -> "Не в сети"; null -> "Статус неизвестен" }} · контроллер ${cloudData.controllerBatteryPercent?.let { "${it.toInt()}%" } ?: "—"} · батарей: ${cloudData.batteries.size}", color = Muted, fontSize = 9.sp)
                            cloudData.batteries.firstOrNull()?.let { pack ->
                                Text("БАТАРЕЯ ${pack.compartment} · ${pack.chargePercent?.let { "${it.toInt()}%" } ?: "—"}", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 10.sp)
                            }
                            TextButton(onClick = { cloudDetailsExpanded = true }, contentPadding = PaddingValues(0.dp)) { Text("ПОДРОБНЕЕ · ТЕЛЕМЕТРИЯ И BMS", fontSize = 9.sp) }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            OutlinedButton(onClick = { if (cloudSessionPresent) refreshNiuCloudVehicles() else showNiuCloudLogin = true }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(10.dp)) {
                                Text(if (cloudSessionPresent) "СИНХРОНИЗИРОВАТЬ" else "ПОДКЛЮЧИТЬ CLOUD", fontSize = 9.sp)
                            }
                            OutlinedButton(onClick = { refreshNiuCloudTelemetry() }, enabled = cloudSessionPresent && activeVehicleSerial.isNotBlank() && !niuCloudTelemetryLoading, modifier = Modifier.weight(1f), shape = RoundedCornerShape(10.dp)) {
                                Text(if (niuCloudTelemetryLoading) "ЗАГРУЗКА…" else "ДАННЫЕ / БАТАРЕЯ", fontSize = 9.sp)
                            }
                            InfoIconButton("Связка Cloud и ECU", "Использует уже сохранённую зашифрованную NIU Cloud-сессию и существующий список motoinfo/list. Сопоставляет скутер по точному SN. Cloud подтверждает принадлежность записи аккаунту, но не доказывает BLE-соединение и не отправляет команды в ECU.")
                        }
                    }
                }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("МОИ УСТРОЙСТВА NIU", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("Выберите профиль из меню действий", color = Muted, fontSize = 10.sp)
                            }
                            Text("${savedVehicles.size}", color = Lime, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
                            Button(onClick = { editingVehicleSerial = ""; vehicleSerialInput = ""; vehicleNameInput = ""; vehicleVinInput = ""; vehicleEditorMessage = ""; showVehicleEditor = true }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Lime), shape = RoundedCornerShape(11.dp)) { Text("ДОБАВИТЬ", fontSize = 10.sp) }
                            InfoIconButton("Добавить NIU", "Открывает форму нового локального профиля скутера. Можно указать серийный номер, имя, семейство и модель; это не регистрирует транспорт в аккаунте NIU.")
                            OutlinedButton(onClick = { showNiuCloudLogin = true }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(11.dp)) { Text("NIU CLOUD", fontSize = 10.sp) }
                            InfoIconButton("NIU Cloud", "Открывает форму входа в NIU Cloud по email/телефону и паролю с выбором региона. Ошибка авторизации или списка транспорта отдельно отображается в статусе и журнале.")
                        }
                        Text("NIU Cloud: $niuCloudStatus", color = Muted, fontSize = 10.sp)
                        if (savedVehicles.isEmpty()) Text("Пока нет сохранённых скутеров. Добавьте по QR-коду из руководства или введите SN вручную.", color = Muted, fontSize = 11.sp, lineHeight = 15.sp)
                        if (savedVehicles.isNotEmpty()) {
                            val selectedVehicle = savedVehicles.firstOrNull { it.serial.equals(activeVehicleSerial, true) }
                            var vehiclePickerExpanded by remember { mutableStateOf(false) }
                            Box(Modifier.fillMaxWidth()) {
                                OutlinedButton(onClick = { vehiclePickerExpanded = true }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(11.dp)) {
                                    Text(selectedVehicle?.let { "${it.name} · ${it.model}" } ?: "Выберите скутер", modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text("▾")
                                }
                                DropdownMenu(expanded = vehiclePickerExpanded, onDismissRequest = { vehiclePickerExpanded = false }) {
                                    savedVehicles.forEach { vehicle ->
                                        DropdownMenuItem(
                                            text = { Column { Text(vehicle.name); Text("${vehicle.model} · SN ${vehicle.serial}", color = Muted, fontSize = 10.sp) } },
                                            trailingIcon = { if (activeVehicleSerial.equals(vehicle.serial, true)) Text("✓", color = Lime) },
                                            onClick = { activeVehicleSerial = vehicle.serial; selectedNiuFamily = vehicle.familyId; selectedNiuModel = vehicle.model; persistSavedVehicles(); vehiclePickerExpanded = false; vehicleActionMenuSerial = "" }
                                        )
                                    }
                                }
                            }
                            selectedVehicle?.let { vehicle ->
                                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                        Text("${vehicle.model} · SN ${vehicle.serial}", color = Color.White, fontSize = 11.sp)
                                        Text("BLE: ${vehicle.bleAddress.ifBlank { "не привязан" }} · Cloud: ${if (vehicle.cloudLinked) "да" else "нет"}", color = Muted, fontSize = 9.sp)
                                    }
                                    Box {
                                        TextButton(onClick = { vehicleActionMenuSerial = if (vehicleActionMenuSerial == vehicle.serial) "" else vehicle.serial }) { Text("⋮", fontSize = 18.sp) }
                                        DropdownMenu(expanded = vehicleActionMenuSerial == vehicle.serial, onDismissRequest = { vehicleActionMenuSerial = "" }) {
                                            DropdownMenuItem(text = { Text("Подключить BLE") }, onClick = { vehicleActionMenuSerial = ""; if (vehicle.bleAddress.isNotBlank()) runCatching { connect(adapter?.getRemoteDevice(vehicle.bleAddress) ?: error("Bluetooth недоступен")) }.onFailure { addLog("Saved BLE connect failed: ${it.message}") } })
                                            DropdownMenuItem(text = { Text("Изменить профиль") }, onClick = { editingVehicleSerial = vehicle.serial; vehicleSerialInput = vehicle.serial; vehicleNameInput = vehicle.name; vehicleVinInput = vehicle.vin; selectedNiuFamily = vehicle.familyId; selectedNiuModel = vehicle.model; vehicleEditorMessage = ""; showVehicleEditor = true; vehicleActionMenuSerial = "" })
                                            if (vehicle.bleAddress.isNotBlank()) DropdownMenuItem(text = { Text("Bluetooth Pair") }, onClick = { runCatching { connect(adapter?.getRemoteDevice(vehicle.bleAddress) ?: error("Bluetooth недоступен")); mainHandler.postDelayed({ requestBleBond() }, 1200L) }.onFailure { addLog("Android bond request failed: ${it.message}") }; vehicleActionMenuSerial = "" })
                                        }
                                    }
                                }
                            }
                        }
                        if (devices.isNotEmpty()) {
                            Text("НАЙДЕННЫЕ BLE-УСТРОЙСТВА", color = Lime, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            devices.take(8).forEach { device ->
                                val deviceName = runCatching { device.name }.getOrNull().orEmpty().ifBlank { "NIU / BLE device" }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(deviceName, color = Color.White, fontSize = 10.sp)
                                        Text("${device.address} · RSSI ${signalByAddress[device.address] ?: "—"}", color = Muted, fontSize = 8.sp)
                                    }
                                    TextButton(onClick = {
                                        val serial = activeVehicleSerial
                                        val index = savedVehicles.indexOfFirst { it.serial.equals(serial, true) }
                                        if (index >= 0) { savedVehicles[index] = savedVehicles[index].copy(bleAddress = device.address); persistSavedVehicles(); addLog("BLE address saved for SN ${serial.take(3)}•••") }
                                        else { vehicleEditorMessage = "Сначала добавьте устройство по SN, затем сохраните BLE-адрес"; showVehicleEditor = true }
                                    }) { Text("ПРИВЯЗАТЬ", fontSize = 8.sp) }
                                }
                            }
                        }
                        OutlinedButton(onClick = { ensurePermissions() }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(10.dp)) { Text(if (scanning) "ПОИСК BLE…" else "НАЙТИ УСТРОЙСТВО ПО BLUETOOTH", fontSize = 9.sp) }
                        Text("Важно: BLE-соединение сохраняется в списке NIU Mobility Studio. Системное Bluetooth-сопряжение Android — отдельная операция и поддерживается не каждым NIU ECU; оно не запускается автоматически.", color = Muted, fontSize = 9.sp, lineHeight = 13.sp)
                    }
                }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("ЛИНЕЙКА И МОДЕЛЬ", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            NiuModelCatalog.families.filter { it.id != "other" }.forEach { family ->
                                FilterChip(selected = selectedNiuFamily == family.id, onClick = {
                                    selectedNiuFamily = family.id
                                    selectedNiuModel = family.examples.firstOrNull() ?: family.name
                                    addLog("Выбрана линейка NIU ${family.name}. Уточните вариант и прошивку перед командами.")
                                }, label = { Text(family.name, fontSize = 10.sp) })
                            }
                        }
                        Text("Вариант: $selectedNiuModel", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        if (selectedFamily.examples.isNotEmpty()) {
                            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                selectedFamily.examples.forEach { modelName ->
                                    FilterChip(selected = selectedNiuModel == modelName, onClick = { selectedNiuModel = modelName }, label = { Text(modelName, fontSize = 9.sp) })
                                }
                            }
                        }
                        Text(selectedFamily.note, color = Muted, fontSize = 10.sp, lineHeight = 14.sp)
                        Text("Покрытие: ${when (selectedFamily.coverage) { com.niu.sdk.profile.NiuProtocolCoverage.CLOUD_API_DOCUMENTED -> "облачный API"; com.niu.sdk.profile.NiuProtocolCoverage.BLE_OBSERVED_ONLY -> "наблюдения BLE"; com.niu.sdk.profile.NiuProtocolCoverage.MODEL_SPECIFIC_RESEARCH -> "исследования отдельных моделей"; else -> "не установлено" }}", color = Color(0xFFFFC66D), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(24.dp)) {
                    Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(if (linked) connectedName ?: "NIU Link" else "Ваш скутер", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                Text(if (linked) "Bluetooth Low Energy · связь установлена" else "Подключите скутер для получения телеметрии", color = Muted, fontSize = 11.sp)
                            }
                            Icon(Icons.Default.DirectionsBike, contentDescription = null, tint = Lime, modifier = Modifier.size(42.dp))
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                                Button(onClick = { if (linked) disconnect() else ensurePermissions() }, modifier = Modifier.fillMaxWidth().height(48.dp), colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = Color.White), shape = RoundedCornerShape(14.dp)) {
                                    Text(if (linked) "ОТКЛЮЧИТЬ" else "ПОДКЛЮЧИТЬ", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                }
                                InfoIconButton(if (linked) "Отключить BLE" else "Подключить BLE", actionHelpDescription(if (linked) "ОТКЛЮЧИТЬ" else "ПОДКЛЮЧИТЬ"))
                            }
                            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                                OutlinedButton(onClick = { runCatching { startActivity(Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS)) }.onFailure { addLog("Не удалось открыть настройки Bluetooth") } }, modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(14.dp)) {
                                    Text("BLUETOOTH", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                }
                                InfoIconButton("Системные настройки Bluetooth", actionHelpDescription("ОТКРЫТЬ НАСТРОЙКИ BLUETOOTH"))
                            }
                        }
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    FxMetricCard("СКОРОСТЬ", "—", "км/ч", Modifier.weight(1f))
                    FxMetricCard("БАТАРЕЯ", "—", "%", Modifier.weight(1f))
                    FxMetricCard("ПРОБЕГ", "—", "км", Modifier.weight(1f))
                }
            }
            item {
                CardBlock {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("БЫСТРЫЕ ДЕЙСТВИЯ", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("Команды включаются только после проверки для ${selectedFamily.name} и конкретной прошивки", color = Muted, fontSize = 10.sp)
                        }
                        Text("SAFE MODE", color = Lime, fontWeight = FontWeight.Bold, fontSize = 9.sp)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FxActionButton("ЗАБЛОКИРОВАТЬ", "Протокол не подтверждён", false, Modifier.weight(1f)) {}
                        FxActionButton("РАЗБЛОКИРОВАТЬ", "Протокол не подтверждён", false, Modifier.weight(1f)) {}
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FxActionButton("НАЙТИ", "BLE-поиск доступен", !scanning, Modifier.weight(1f)) { requestFind() }
                        FxActionButton("СИГНАЛ", "Нет подтверждённого payload", false, Modifier.weight(1f)) {}
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FxActionButton("РЕЖИМ ЕЗДЫ", "Нет подтверждённых значений ECU", false, Modifier.weight(1f)) {}
                        FxActionButton("СИГНАЛИЗАЦИЯ", "Нет подтверждённой команды", false, Modifier.weight(1f)) {}
                    }
                }
            }
            item {
                CardBlock {
                    Text("ДИАГНОСТИКА И ТЕЛЕМЕТРИЯ", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(if (selectedNiuFamily == "fx") "FX: наблюдаемый канал Chip → App · 8ec94e31" else "GATT-профиль ${selectedFamily.name} ещё не установлен", color = Muted, fontSize = 10.sp)
                    Text("READ: ${if (canReadStatus) "доступен" else "не подтверждён"}   ·   NOTIFY: ${if (canNotifyStatus) "доступен" else "не подтверждён"}", color = Color.White, fontSize = 11.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { safeStatusProbe() }, enabled = selectedNiuFamily == "fx" && linked && (canReadStatus || canNotifyStatus), modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = Color.White), shape = RoundedCornerShape(12.dp)) { Text("ОБНОВИТЬ ДАННЫЕ", fontSize = 10.sp) }
                        OutlinedButton(onClick = { listenTelemetry() }, enabled = selectedNiuFamily == "fx" && linked && canNotifyStatus, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp)) { Text(if (notifyStates[statusUuid] == true) "ОТКЛЮЧИТЬ LIVE" else "LIVE ДАННЫЕ", fontSize = 10.sp) }
                    }
                    OutlinedButton(onClick = { readAllAvailable() }, enabled = selectedNiuFamily == "fx" && linked && !readAllRunning, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) { Text(if (readAllRunning) "ЧТЕНИЕ GATT…" else "ПРОЧИТАТЬ ДОСТУПНЫЕ ХАРАКТЕРИСТИКИ") }
                    Text(if (selectedNiuFamily == "fx") "Последний пакет: ${latestStatus ?: "ожидается"}" else "Чтение отключено: нельзя применять UUID FX к другой линейке.", color = Muted, fontSize = 10.sp)
                }
            }
            item {
                CardBlock {
                    Text("ПРОВЕРКА КОМАНД", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("Проверка привязана к выбранной линейке ${selectedFamily.name} (${selectedNiuModel}) и версии прошивки. ИИ анализирует источники и дампы, но не может повышать UNKNOWN до VERIFIED и не разрешает неизвестный пакет.", color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
                    OutlinedButton(onClick = { shareFxCommandEvidence() }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) { Text("ПЕРЕДАТЬ ДОКАЗАТЕЛЬСТВА В AI") }
                    OutlinedButton(
                        onClick = {
                            val results = commandTestSimulator.runAll(selectedNiuModel)
                            val passed = results.count { it.passed }
                            addLog("COMMAND TEST SIMULATION · model=$selectedNiuModel · passed=$passed/${results.size} · transmitted=0 · mode=OFFLINE")
                            results.forEach { result ->
                                addLog("COMMAND TEST ${if (result.passed) "PASS" else "FAIL"} · ${result.commandId} · ${result.message} · transmitted=${result.transmitted}")
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) { Text("ПРОГНАТЬ ТЕСТ КОМАНД (OFFLINE)") }
                    Text("Тест проверяет регистрацию команд и защитные блокировки. Он не отправляет BLE-пакеты и не вызывает NIU Cloud.", color = Color(0xFFFFC66D), fontSize = 10.sp, lineHeight = 14.sp)
                    commandRegistry.forModel(selectedNiuModel).forEach { spec ->
                        val preflight = commandRegistry.preflight(spec.id, model = selectedNiuModel)
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(spec.id.replace('.', ' ').uppercase(), color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                                Text(preflight.reason, color = Muted, fontSize = 10.sp, lineHeight = 14.sp)
                            }
                            Text(if (preflight.allowed) "РАЗРЕШЕНО" else "ЗАБЛОКИРОВАНО", color = if (preflight.allowed) Lime else Color(0xFFFFC66D), fontSize = 8.sp, fontWeight = FontWeight.Bold)
                        }
                        HorizontalDivider(color = Panel2)
                    }
                    Text("Источники: публичные исследования NIU cloud API, ECU reverse engineering и отдельные аппаратные исследования KQi. Протоколы Ninebot/Xiaomi не переносятся на NIU. Каталог не означает, что команды всех линеек уже расшифрованы.", color = Muted, fontSize = 10.sp, lineHeight = 15.sp)
                }
            }
            item {
                CardBlock {
                    Text("ИЗВЕСТНЫЕ BLE-КАНАЛЫ", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("""8ec94e31 · Chip → App · READ/NOTIFY кандидат\n8ec94e32 · App → Chip · WRITE кандидат\n8ec94e33 · защищённый канал · ранее AUTH FAIL 0x89\n99ea30e2 · WRITE WITHOUT RESPONSE · назначение не доказано""", color = Muted, fontSize = 10.sp, lineHeight = 16.sp)
                    Text("Ни один proprietary WRITE не выполняется из общего HEX-инструмента до подтверждения протокола и штатной авторизации владельца.", color = Color(0xFFFFC66D), fontSize = 10.sp, lineHeight = 15.sp)
                }
            }
        }
        if (cloudVehicleDetailsExpanded && selectedCloudVehicle != null) {
            AlertDialog(
                onDismissRequest = { cloudVehicleDetailsExpanded = false },
                title = { Text("Модель и идентификаторы NIU") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("${selectedCloudVehicle.name} · ${selectedCloudVehicle.model.ifBlank { "модель не указана" }}", color = Color.White)
                        Text("SN: ${selectedCloudVehicle.serial}", color = Muted, fontSize = 12.sp)
                        Text("VIN: ${selectedCloudVehicle.vin.ifBlank { "не предоставлен Cloud" }}", color = Muted, fontSize = 12.sp)
                        Text("Данные сервера: ${selectedCloudVehicle.serverIdentityText()}", color = Muted, fontSize = 11.sp)
                        Text("Cloud-идентификация подтверждает облачную запись. Для точного семейства FX дополнительно нужны однозначные серверные product/vehicle type поля или подтверждение по VIN.", color = Color(0xFFFFC66D), fontSize = 11.sp)
                    }
                },
                confirmButton = { TextButton(onClick = { cloudVehicleDetailsExpanded = false }) { Text("ЗАКРЫТЬ") } }
            )
        }
        if (cloudDetailsExpanded) {
            AlertDialog(
                onDismissRequest = { cloudDetailsExpanded = false },
                title = { Text("Подробности Cloud ↔ ECU") },
                text = {
                    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Text("ECU: ${bridgeReport.match.name.replace('_', ' ')} · семейство ${bridgeReport.detectedFamilyId ?: "не определено"}", color = Color.White, fontSize = 12.sp)
                        Text("BLE: ${if (linked) connectedName ?: "подключён" else "не подключён"}. BLE SN пока не подтверждён.", color = Muted, fontSize = 11.sp)
                        Text("Передача команд не подтверждена одним фактом Cloud-синхронизации.", color = Color(0xFFFFC66D), fontSize = 11.sp)
                        cloudDataForDetails?.let { data ->
                            Text("Телеметрия · ${((System.currentTimeMillis() - data.fetchedAtEpochMs) / 1000L).coerceAtLeast(0)} сек. назад", color = Color.White, fontWeight = FontWeight.Bold)
                            Text("Пробег: ${data.totalMileageKm ?: "—"} км · запас: ${data.estimatedRangeKm ?: "—"} км · скорость: ${data.speedKmh ?: "—"} км/ч", color = Muted, fontSize = 11.sp)
                            Text("Контроллер: ${data.controllerBatteryPercent ?: "—"}% · зарядка: ${data.charging?.toString() ?: "—"} · замок: ${data.lockStatus ?: "—"}", color = Muted, fontSize = 11.sp)
                            if (data.batteries.isEmpty()) Text("BMS: Cloud не вернул расшифрованные данные батарей.", color = Color(0xFFFFC66D), fontSize = 11.sp)
                            data.batteries.forEach { pack ->
                                Text("Батарея ${pack.compartment}: ${pack.chargePercent ?: "—"}% · ${pack.temperatureC ?: "—"} °C · циклы ${pack.chargeCycles.ifBlank { "—"}} · здоровье ${pack.healthGrade.ifBlank { "—"}} · ошибки ${pack.faultCount ?: "—"}", color = Muted, fontSize = 11.sp)
                            }
                            if (data.sourceStates.isNotEmpty()) Text("Источники: ${data.sourceStates.entries.joinToString { "${it.key}=${it.value}" }}", color = Muted, fontSize = 10.sp)
                            data.warnings.forEach { Text("• $it", color = Color(0xFFFFC66D), fontSize = 10.sp) }
                        } ?: Text("Телеметрия ещё не загружена для выбранного SN.", color = Muted, fontSize = 11.sp)
                    }
                },
                confirmButton = { TextButton(onClick = { cloudDetailsExpanded = false }) { Text("ЗАКРЫТЬ") } }
            )
        }
        if (showVehicleEditor) {
            AlertDialog(
                onDismissRequest = { showVehicleEditor = false },
                title = { Text(if (editingVehicleSerial.isBlank()) "Добавить NIU" else "Изменить устройство") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedButton(onClick = { scanVehicleQr() }, modifier = Modifier.weight(1f)) { Text("СКАНИРОВАТЬ QR-КОД SN") }
                            InfoIconButton("Сканировать QR серийного номера", "Запускает системный сканер Google ML Kit, чтобы распознать серийный номер с QR-кода. После распознавания проверьте значение перед сохранением профиля.")
                        }
                        OutlinedTextField(value = vehicleSerialInput, onValueChange = { vehicleSerialInput = it.uppercase().take(32) }, label = { Text("Серийный номер SN") }, singleLine = true)
                        OutlinedTextField(value = vehicleNameInput, onValueChange = { vehicleNameInput = it.take(48) }, label = { Text("Название устройства") }, singleLine = true)
                        OutlinedTextField(value = vehicleVinInput, onValueChange = { vehicleVinInput = it.uppercase().take(32) }, label = { Text("VIN (необязательно)") }, singleLine = true)
                        if (vehicleEditorMessage.isNotBlank()) Text(vehicleEditorMessage, color = Color(0xFFFFC66D), fontSize = 10.sp)
                        Text("QR-код считывается на телефоне. Из него извлекается SN; привязка к аккаунту NIU выполняется отдельно через NIU Cloud.", color = Muted, fontSize = 10.sp, lineHeight = 14.sp)
                    }
                },
                confirmButton = { TextButton(onClick = {
                    val oldSerial = editingVehicleSerial
                    val oldVehicle = savedVehicles.firstOrNull { it.serial.equals(oldSerial, true) }
                    runCatching { saveVehicle(vehicleSerialInput, vehicleNameInput, vehicleVinInput,
                        address = oldVehicle?.bleAddress.orEmpty(), family = oldVehicle?.familyId ?: selectedNiuFamily,
                        model = oldVehicle?.model ?: selectedNiuModel, cloud = oldVehicle?.cloudLinked == true) }
                        .onSuccess {
                            if (oldSerial.isNotBlank() && !oldSerial.equals(vehicleSerialInput.trim(), true)) {
                                savedVehicles.removeAll { it.serial.equals(oldSerial, true) }
                                persistSavedVehicles()
                            }
                            showVehicleEditor = false; vehicleEditorMessage = ""; editingVehicleSerial = ""
                        }
                        .onFailure { vehicleEditorMessage = it.message ?: "Не удалось сохранить" }
                }) { Text("СОХРАНИТЬ") } },
                dismissButton = { TextButton(onClick = { showVehicleEditor = false }) { Text("ОТМЕНА") } }
            )
        }
        if (showNiuCloudLogin) {
            AlertDialog(
                onDismissRequest = { showNiuCloudLogin = false },
                title = { Text("Авторизация NIU Cloud") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Классический вход NIU Cloud: электронная почта или логин и пароль. Учётные данные отправляются только по HTTPS; пароль не сохраняется. Сессионный ключ, который NIU выдаёт после успешного входа, хранится зашифрованно в Android Keystore.", color = Muted, fontSize = 10.sp, lineHeight = 14.sp)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = niuCloudVerboseTrace, onCheckedChange = {
                                niuCloudVerboseTrace = it
                                getSharedPreferences("niu_cloud", MODE_PRIVATE).edit().putBoolean("verbose_trace", it).apply()
                                addLog("NIU CLOUD · verbose trace ${if (it) "enabled" else "disabled"}; JSON structure and request metadata only; credentials, digests and tokens are excluded")
                            })
                            Column(Modifier.weight(1f)) {
                                Text("Подробная диагностика NIU Cloud", color = Color.White, fontSize = 11.sp)
                                Text("Структура JSON, HTTP-коды, время ответа, TLS и безопасные заголовки. Значения секретных полей не записываются.", color = Muted, fontSize = 9.sp, lineHeight = 12.sp)
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { exportNiuCloudTrace() }, modifier = Modifier.weight(1f)) { Text("СОХРАНИТЬ CLOUD-ЛОГ", fontSize = 9.sp) }
                            OutlinedButton(onClick = { logFilter = "NIU Cloud"; cloudJournalNavigationRequest = true; showNiuCloudLogin = false }, modifier = Modifier.weight(1f)) { Text("ОТКРЫТЬ ЖУРНАЛ", fontSize = 9.sp) }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(selected = niuCloudRegion == "GLOBAL", onClick = { niuCloudRegion = "GLOBAL" }, label = { Text("GLOBAL") })
                            FilterChip(selected = niuCloudRegion == "CHINA", onClick = { niuCloudRegion = "CHINA" }, label = { Text("FK · NIU app") })
                        }
                        OutlinedTextField(value = niuCloudAccount, onValueChange = { niuCloudAccount = it }, label = { Text("Email / телефон / аккаунт NIU") }, singleLine = true)
                        OutlinedTextField(value = niuCloudPassword, onValueChange = { niuCloudPassword = it }, label = { Text("Пароль NIU") }, singleLine = true, visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation())
                        Text("Вход выполняется через NIU OAuth v3. Пароль хешируется MD5 на устройстве; ручной ввод NIU Token не требуется.", color = Muted, fontSize = 10.sp, lineHeight = 14.sp)
                        Text(niuCloudStatus, color = if (niuCloudStatus.contains("ошиб", true) || niuCloudStatus.contains("отклон", true) || niuCloudStatus.contains("не подтвержд", true)) Color(0xFFFFC66D) else Lime, fontSize = 10.sp)
                    }
                },
                confirmButton = { TextButton(onClick = { loginNiuCloud(); showNiuCloudLogin = false }) { Text("ВОЙТИ ПО ЛОГИНУ И ПАРОЛЮ") } },
                dismissButton = { Row {
                    TextButton(onClick = { refreshNiuCloudVehicles(); showNiuCloudLogin = false }) { Text("ОБНОВИТЬ") }
                    TextButton(onClick = { logoutNiuCloud(); showNiuCloudLogin = false }) { Text("ВЫЙТИ") }
                } }
            )
        }
    }

    @Composable private fun FxMetricCard(label: String, value: String, unit: String, modifier: Modifier = Modifier) {
        Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(label, color = Muted, fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = .6.sp)
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(value, color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    Text(" $unit", color = Muted, fontSize = 9.sp, modifier = Modifier.padding(bottom = 4.dp))
                }
            }
        }
    }

    @Composable private fun FxActionButton(label: String, hint: String, enabled: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
        Row(modifier, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(1.dp)) {
            OutlinedButton(
                onClick = onClick,
                enabled = enabled,
                modifier = Modifier.weight(1f).heightIn(min = 58.dp),
                shape = RoundedCornerShape(13.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White, disabledContentColor = Muted),
                border = androidx.compose.foundation.BorderStroke(1.dp, if (enabled) Lime.copy(alpha = .7f) else Panel2),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 8.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(label, fontSize = 9.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                    Text(hint, fontSize = 7.sp, color = Muted, maxLines = 2, lineHeight = 9.sp)
                }
            }
            InfoIconButton(label, "${actionHelpDescription(label)}\n\nТекущий статус: $hint. ${if (enabled) "Кнопка доступна." else "Кнопка сейчас отключена: действие не выполняется."}")
        }
    }

    @Composable private fun Profile(pad: PaddingValues) {
        Column(Modifier.fillMaxSize().padding(pad).padding(22.dp)) {
            PageHeader("SETTINGS & PROJECT", "Профиль")
            CardBlock { Text("NIU UNIVERSAL · MULTI-LINEUP", color = Lime, fontWeight = FontWeight.Bold); Text("Поддержка семейств NQi / MQi / UQi / GOVA / FX / RQi / FQi / KQi", color = Color.White); Text("Облачная совместимость использует региональные NIU API. BLE-профиль и команды проверяются отдельно для конкретной модели и прошивки.", color = Muted, fontSize = 12.sp) }
            Spacer(Modifier.height(12.dp)); CardBlock { Text("БЕЗОПАСНОСТЬ", color = Lime, fontWeight = FontWeight.Bold); Text("Штатная eSIM, TCU и ECU не изменяются. Запись в характеристики, разблокировка и команды движения отключены до подтверждения протокола.", color = Muted, fontSize = 12.sp) }
            Spacer(Modifier.height(12.dp)); CardBlock { Text("ВЕРСИЯ", color = Muted, fontSize = 10.sp); Text("NIU Mobility Studio ${BuildConfig.VERSION_NAME} · Universal NIU", color = Color.White); Text("Независимый интерфейс. Неофициальное приложение, не связано с NIU.", color = Muted, fontSize = 11.sp) }
        }
    }

    override fun onDestroy() { mainHandler.removeCallbacks(scanTimeout); stopScan(); telegramPollingFlag?.set(false); telegramPollingThread?.interrupt(); localControlServer?.stop(); runCatching { mediaPlayer?.release() }; mediaPlayer = null; try { gatt?.close() } catch (_: Exception) {}; super.onDestroy() }
}
