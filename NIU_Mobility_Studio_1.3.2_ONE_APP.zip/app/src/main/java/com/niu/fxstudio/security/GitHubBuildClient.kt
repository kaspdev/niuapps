package com.niu.fxstudio.security

import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import android.util.Base64
import java.util.zip.ZipInputStream

object GitHubBuildClient {
    data class Run(val id: Long, val status: String, val conclusion: String?, val htmlUrl: String)
    private fun request(url: String, token: String, method: String = "GET", body: String? = null, accept: String = "application/vnd.github+json"): Pair<Int, ByteArray> {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = 20_000; c.readTimeout = 90_000
            c.setRequestProperty("Authorization", "Bearer $token")
            c.setRequestProperty("User-Agent", "NIU-Mobility-Studio-Android")
            c.setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
            c.setRequestProperty("Accept", accept)
            if (body != null) { c.doOutput = true; c.setRequestProperty("Content-Type", "application/json"); c.outputStream.use { it.write(body.toByteArray()) } }
            val code = c.responseCode
            val bytes = (if (code in 200..299) c.inputStream else c.errorStream)?.use { it.readBytes() } ?: byteArrayOf()
            return code to bytes
        } finally { c.disconnect() }
    }
    private fun api(repo: String, path: String) = "https://api.github.com/repos/$repo/$path"

    data class Repository(val fullName: String, val defaultBranch: String, val private: Boolean, val htmlUrl: String)

    fun authenticatedUser(token: String): String {
        val (code, bytes) = request("https://api.github.com/user", token)
        if (code !in 200..299) error("GitHub profile HTTP $code: ${bytes.toString(Charsets.UTF_8).take(400)}")
        return JSONObject(bytes.toString(Charsets.UTF_8)).optString("login")
    }

    fun listRepositories(token: String): List<Repository> {
        val result = mutableListOf<Repository>()
        for (page in 1..10) {
            val (code, bytes) = request("https://api.github.com/user/repos?per_page=100&page=$page&sort=updated&affiliation=owner,collaborator,organization_member", token)
            if (code !in 200..299) error("GitHub repositories HTTP $code: ${bytes.toString(Charsets.UTF_8).take(400)}")
            val array = org.json.JSONArray(bytes.toString(Charsets.UTF_8))
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                result += Repository(item.getString("full_name"), item.optString("default_branch", "main"), item.optBoolean("private"), item.optString("html_url"))
            }
            if (array.length() < 100) break
        }
        return result
    }

    fun listBranches(repo: String, token: String): List<String> {
        require(repo.matches(Regex("[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+")))
        val (code, bytes) = request("https://api.github.com/repos/$repo/branches?per_page=100", token)
        if (code !in 200..299) error("GitHub branches HTTP $code: ${bytes.toString(Charsets.UTF_8).take(400)}")
        val array = org.json.JSONArray(bytes.toString(Charsets.UTF_8))
        return (0 until array.length()).map { array.getJSONObject(it).getString("name") }
    }

    fun createRepository(token: String, name: String, privateRepo: Boolean = true): String {
        require(name.matches(Regex("[A-Za-z0-9_.-]{1,100}"))) { "Недопустимое имя репозитория" }
        val body = JSONObject().put("name", name).put("private", privateRepo).put("auto_init", true)
        val (code, bytes) = request("https://api.github.com/user/repos", token, "POST", body.toString())
        if (code !in 200..299) error("Не удалось создать репозиторий HTTP $code: ${bytes.toString(Charsets.UTF_8).take(500)}")
        return JSONObject(bytes.toString(Charsets.UTF_8)).getString("full_name")
    }

    /** Downloads repository blobs into a dedicated workspace. Symlinks/submodules are skipped. */
    fun pullWorkspace(repo: String, token: String, branch: String, destination: File): Int {
        require(repo.matches(Regex("[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+")))
        val ref = URLEncoder.encode(branch, "UTF-8").replace("+", "%20")
        val (code, bytes) = request(api(repo, "git/trees/$ref?recursive=1"), token)
        if (code !in 200..299) error("GitHub tree HTTP $code: ${bytes.toString(Charsets.UTF_8).take(500)}")
        val tree = JSONObject(bytes.toString(Charsets.UTF_8)).getJSONArray("tree")
        require(tree.length() <= 2000) { "В репозитории больше 2000 объектов; импорт ограничен для безопасности" }
        var total = 0L
        var written = 0
        val root = destination.canonicalFile
        for (i in 0 until tree.length()) {
            val item = tree.getJSONObject(i)
            if (item.optString("type") != "blob" || item.optString("mode") != "100644") continue
            val path = item.getString("path").replace('\\', '/')
            if (path.startsWith("/") || path.split('/').any { it == ".." || it.isBlank() }) continue
            if (path.split('/').any { it in setOf(".git", ".gradle", "build") }) continue
            val size = item.optLong("size", 0L)
            if (size < 0 || size > 5L * 1024 * 1024) continue
            total += size
            require(total <= 40L * 1024 * 1024) { "Репозиторий превышает лимит импорта 40 МБ" }
            val blob = jsonRequest(repo, "git/blobs/${item.getString("sha")}", token)
            if (blob.optString("encoding") != "base64") continue
            val raw = android.util.Base64.decode(blob.getString("content").replace("\n", ""), android.util.Base64.DEFAULT)
            val output = File(root, path).canonicalFile
            require(output.path.startsWith(root.path + File.separator)) { "Небезопасный путь в Git tree" }
            output.parentFile?.mkdirs()
            output.writeBytes(raw)
            written++
        }
        return written
    }

    private fun jsonRequest(repo: String, path: String, token: String, method: String = "GET", body: JSONObject? = null): JSONObject {
        val (code, bytes) = request(api(repo, path), token, method, body?.toString())
        if (code !in 200..299) error("GitHub API HTTP $code: ${bytes.toString(Charsets.UTF_8).take(700)}")
        return if (bytes.isEmpty()) JSONObject() else JSONObject(bytes.toString(Charsets.UTF_8))
    }

    /** Publishes a bounded source snapshot as one Git commit. Local secrets/build outputs are excluded. */
    fun publishWorkspace(repo: String, token: String, root: File, branch: String = "main"): String {
        require(repo.matches(Regex("[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+"))) { "Укажите репозиторий в формате owner/name" }
        val branchPath = URLEncoder.encode(branch, "UTF-8").replace("+", "%20")
        val head = jsonRequest(repo, "git/ref/heads/$branchPath", token).getJSONObject("object").getString("sha")
        val baseTree = jsonRequest(repo, "git/commits/$head", token).getJSONObject("tree").getString("sha")
        val excluded = setOf(".git", ".gradle", "build", "local.properties", "keystore", "signing")
        val files = root.walkTopDown().filter { f ->
            f.isFile && runCatching { f.canonicalPath.startsWith(root.canonicalPath + File.separator) }.getOrDefault(false) &&
                f.relativeTo(root).invariantSeparatorsPath.split('/').none { it in excluded } &&
                f.name != ".niu-github-manifest" && !f.name.startsWith(".env", true) && !f.name.endsWith(".jks", true) && !f.name.endsWith(".keystore", true) &&
                !f.name.endsWith(".p12", true) && !f.name.endsWith(".pfx", true) && !f.name.endsWith(".pem", true) &&
                !f.name.endsWith(".key", true) && !f.name.contains("secret", true) && !f.name.endsWith(".apk", true)
        }.toList()
        require(files.isNotEmpty() && files.size <= 2000) { "Недопустимое количество файлов (максимум 2000)" }
        val total = files.sumOf { it.length() }
        require(total <= 40L * 1024L * 1024L) { "Размер проекта превышает лимит публикации 40 МБ" }
        val entries = org.json.JSONArray()
        val localPaths = files.map { it.relativeTo(root).invariantSeparatorsPath }.toSet()
        // Remove tracked files deleted locally; GitHub's Git Trees API uses sha=null for deletion.
        val (treeCode, treeBytes) = request(api(repo, "git/trees/$head?recursive=1"), token)
        if (treeCode !in 200..299) error("GitHub tree HTTP $treeCode: ${treeBytes.toString(Charsets.UTF_8).take(400)}")
        val remoteTree = JSONObject(treeBytes.toString(Charsets.UTF_8)).getJSONArray("tree")
        require(remoteTree.length() <= 100_000) { "Слишком большое дерево репозитория" }
        for (i in 0 until remoteTree.length()) {
            val remote = remoteTree.getJSONObject(i)
            val path = remote.optString("path")
            if (remote.optString("type") == "blob" && path.isNotBlank() && path !in localPaths &&
                path.split('/').none { it in excluded } && !path.endsWith(".jks", true) &&
                !path.endsWith(".keystore", true) && !path.endsWith(".apk", true) && !path.startsWith(".env")) {
                entries.put(JSONObject().put("path", path).put("mode", "100644").put("type", "blob").put("sha", JSONObject.NULL))
            }
        }
        files.forEach { file ->
            require(file.length() <= 5L * 1024L * 1024L) { "Файл слишком большой для безопасной публикации: ${file.name}" }
            val relative = file.relativeTo(root).invariantSeparatorsPath
            require(!relative.startsWith("/") && relative.split('/').none { it == ".." })
            val fileBytes = file.readBytes()
            val textForSecretScan = fileBytes.toString(Charsets.UTF_8)
            val secretAssignment = Regex("(?i)(api[_-]?key|access[_-]?token|password|secret|storepass|keypass)\\s*[:=]\\s*[\"']([^\"']{8,})[\"']")
            val tokenPattern = Regex("(?i)(gh[pousr]_[A-Za-z0-9_]{20,}|github_pat_[A-Za-z0-9_]{20,}|AIza[0-9A-Za-z_-]{30,}|-----BEGIN (RSA|EC|OPENSSH|PRIVATE) KEY-----)")
            require(!secretAssignment.containsMatchIn(textForSecretScan) && !tokenPattern.containsMatchIn(textForSecretScan)) {
                "В файле $relative обнаружено значение, похожее на секрет. Удалите его перед публикацией."
            }
            val content = Base64.encodeToString(fileBytes, Base64.NO_WRAP)
            val blob = jsonRequest(repo, "git/blobs", token, "POST", JSONObject().put("content", content).put("encoding", "base64"))
            entries.put(JSONObject().put("path", relative).put("mode", "100644").put("type", "blob").put("sha", blob.getString("sha")))
        }
        val tree = jsonRequest(repo, "git/trees", token, "POST", JSONObject().put("base_tree", baseTree).put("tree", entries)).getString("sha")
        val commit = jsonRequest(repo, "git/commits", token, "POST", JSONObject()
            .put("message", "NIU Mobility Studio: publish workspace snapshot")
            .put("tree", tree).put("parents", org.json.JSONArray().put(head))).getString("sha")
        jsonRequest(repo, "git/refs/heads/$branchPath", token, "PATCH", JSONObject().put("sha", commit).put("force", false))
        return commit
    }

    fun dispatch(repo: String, token: String, branch: String = "main") {
        require(repo.matches(Regex("[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+"))) { "Укажите репозиторий в формате owner/name" }
        val (code, bytes) = request(api(repo, "actions/workflows/android-build.yml/dispatches"), token, "POST", JSONObject().put("ref", branch).toString())
        if (code != 204) error("GitHub dispatch HTTP $code: ${bytes.toString(Charsets.UTF_8).take(600)}")
    }

    fun latestRun(repo: String, token: String): Run? {
        val (code, bytes) = request(api(repo, "actions/workflows/android-build.yml/runs?per_page=10"), token)
        if (code !in 200..299) error("GitHub status HTTP $code: ${bytes.toString(Charsets.UTF_8).take(600)}")
        val runs = JSONObject(bytes.toString(Charsets.UTF_8)).getJSONArray("workflow_runs")
        for (i in 0 until runs.length()) {
            val r = runs.getJSONObject(i)
            if (r.optString("event") == "workflow_dispatch" || r.optString("event") == "push")
                return Run(r.getLong("id"), r.optString("status"), r.optString("conclusion").takeIf { it != "null" && it.isNotBlank() }, r.optString("html_url"))
        }
        return null
    }

    fun downloadLatestApk(repo: String, token: String, destination: File, artifactName: String = "niu-user-debug-apk"): File {
        val run = latestRun(repo, token) ?: error("Сборка ещё не найдена")
        require(run.status == "completed" && run.conclusion == "success") { "Последняя сборка ещё не завершена успешно: ${run.status} · ${run.conclusion ?: "выполняется"}" }
        val (code, bytes) = request(api(repo, "actions/runs/${run.id}/artifacts"), token)
        if (code !in 200..299) error("GitHub artifacts HTTP $code: ${bytes.toString(Charsets.UTF_8).take(500)}")
        val artifacts = JSONObject(bytes.toString(Charsets.UTF_8)).getJSONArray("artifacts")
        require(artifacts.length() > 0) { "Артефакты сборки отсутствуют" }
        val selected = (0 until artifacts.length()).map { artifacts.getJSONObject(it) }
            .firstOrNull { it.optString("name") == artifactName }
            ?: error("Артефакт '$artifactName' не найден. Доступные: ${(0 until artifacts.length()).joinToString { artifacts.getJSONObject(it).optString("name") }}")
        require(!selected.optBoolean("expired", false)) { "Артефакт сборки истёк" }
        val artifactId = selected.getLong("id")
        val apiConnection = URL(api(repo, "actions/artifacts/$artifactId/zip")).openConnection() as HttpURLConnection
        apiConnection.instanceFollowRedirects = false
        apiConnection.setRequestProperty("Authorization", "Bearer $token")
        apiConnection.setRequestProperty("Accept", "application/vnd.github+json")
        apiConnection.setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
        val archiveBytes = try {
            val response = apiConnection.responseCode
            if (response == 302 || response == 301 || response == 303) {
                val location = apiConnection.getHeaderField("Location") ?: error("GitHub не вернул ссылку на артефакт")
                apiConnection.disconnect()
                val signed = URL(location).openConnection() as HttpURLConnection
                signed.connectTimeout = 20_000; signed.readTimeout = 90_000
                try {
                    val signedCode = signed.responseCode
                    if (signedCode !in 200..299) error("Хранилище артефактов HTTP $signedCode")
                    signed.inputStream.use { it.readBytes() }
                } finally { signed.disconnect() }
            } else {
                if (response !in 200..299) error("Не удалось скачать артефакт: HTTP $response")
                apiConnection.inputStream.use { it.readBytes() }
            }
        } finally { apiConnection.disconnect() }
        val archive = archiveBytes
        destination.parentFile?.mkdirs()
        var apk: File? = null
        ZipInputStream(archive.inputStream()).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                val name = entry.name.replace('\\', '/')
                if (!entry.isDirectory && name.endsWith(".apk", true) && !name.startsWith("/") && name.split('/').none { it == ".." }) {
                    val out = destination
                    out.outputStream().use { zip.copyTo(it) }
                    apk = out
                }
                zip.closeEntry()
            }
        }
        return apk ?: error("В артефакте не найден APK")
    }
}
