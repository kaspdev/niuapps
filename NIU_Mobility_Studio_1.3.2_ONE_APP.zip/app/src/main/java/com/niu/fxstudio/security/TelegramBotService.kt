package com.niu.fxstudio.security

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.niu.fxstudio.BuildConfig
import com.niu.fxstudio.MainActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

/** User-started foreground service: Telegram polling continues while the Activity is minimized. */
class TelegramBotService : Service() {
    companion object {
        const val ACTION_START = "com.niu.fxstudio.telegram.START"
        const val ACTION_STOP = "com.niu.fxstudio.telegram.STOP"
        private const val CHANNEL_ID = "niu_telegram_service"
        private const val NOTIFICATION_ID = 7312
        private const val PREFS = "niu_telegram_config"
        private const val MAX_LOG_LINES = 250
    }

    private val running = AtomicBoolean(false)
    private var worker: Thread? = null
    private var client: TelegramBotClient? = null
    private lateinit var prefs: SharedPreferences

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "NIU Telegram bot", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Показывает состояние фонового Telegram-бота"
                setShowBadge(false)
            })
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopBot(); stopSelf(); return START_NOT_STICKY }
            ACTION_START, null -> startBot()
        }
        return START_STICKY
    }

    private fun notification(text: String): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle("NIU Mobility Studio · Telegram")
            .setContentText(text.take(120))
            .setContentIntent(open)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    private fun log(level: String, message: String) {
        val stamp = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        val safe = message.replace(Regex("(?i)(bot)[0-9]{6,}:[A-Za-z0-9_-]+"), "\$1[СКРЫТО]")
            .replace(Regex("(?i)bearer\\s+\\S+"), "Bearer [СКРЫТО]")
            .replace(Regex("https://api\\.telegram\\.org/bot[^/\\s]+"), "https://api.telegram.org/bot[СКРЫТО]")
            .replace(Regex("[\\r\\n]+"), " ").take(500)
        val line = "$stamp  [$level] $safe"
        synchronized(prefs) {
            val lines = prefs.getString("telegram_console_lines", "").orEmpty().lines().filter { it.isNotBlank() }.takeLast(MAX_LOG_LINES - 1).toMutableList()
            lines.add(line)
            prefs.edit().putString("telegram_console_lines", lines.joinToString("\n")).apply()
        }
        when (level) {
            "ERROR" -> android.util.Log.e("NIU-Telegram", safe)
            "WARN" -> android.util.Log.w("NIU-Telegram", safe)
            else -> android.util.Log.i("NIU-Telegram", safe)
        }
        if (::prefs.isInitialized) {
            getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification("$level · $safe"))
        }
    }

    private fun startBot() {
        if (running.get()) return
        startForeground(NOTIFICATION_ID, notification("Запуск Telegram Long Polling…"))
        val profile = prefs.getString("active_bot_profile", "Основной") ?: "Основной"
        val secretName = "telegram_bot_" + Integer.toHexString(profile.trim().ifBlank { "Основной" }.lowercase().hashCode())
        val store = SecureSecretStore(getSharedPreferences("niu_secure_secrets", MODE_PRIVATE))
        val token = runCatching { store.getOrThrow(secretName) ?: store.getOrThrow("telegram_bot_token") }.getOrNull()
        val allowedChats = prefs.getString("allowed_chat_ids", "").orEmpty()
            .split(',', ';', '\n').map { it.trim() }.filter { it.isNotBlank() }.toSet()
        if (token.isNullOrBlank() || allowedChats.isEmpty()) {
            prefs.edit().putBoolean("telegram_service_running", false).apply()
            log("ERROR", if (token.isNullOrBlank()) "Токен не найден: откройте настройки бота" else "Не заданы разрешённые Chat ID")
            stopSelf()
            return
        }
        running.set(true)
        prefs.edit().putBoolean("telegram_service_running", true).apply()
        log("INFO", "Фоновый сервис запущен · профиль=$profile · разрешённых чатов=${allowedChats.size}")
        client = TelegramBotClient(token) { event -> log(if (event.contains("ERROR", true)) "ERROR" else "INFO", event) }
        worker = Thread({
            val bot = client ?: return@Thread
            val auth = runCatching { bot.getMe() }
            auth.onSuccess {
                prefs.edit().putString("bot_info", "@${it.username} · ${it.firstName} · ID ${it.id}").apply()
                log("INFO", "Авторизация подтверждена · @${it.username}")
            }.onFailure { error -> log("ERROR", "Проверка Telegram getMe: ${error.message ?: error.javaClass.simpleName}") }
            val authError = auth.exceptionOrNull()
            if (authError is TelegramBotClient.TelegramApiException && authError.httpCode in setOf(401, 404)) {
                log("ERROR", "Telegram отклонил токен (HTTP ${authError.httpCode}); фоновый запуск остановлен")
                running.set(false)
                stopSelf()
                return@Thread
            }
            runCatching { bot.setCommands() }.onSuccess { log("INFO", "Список команд Telegram обновлён") }
                .onFailure { log("WARN", "setMyCommands: ${it.message ?: it.javaClass.simpleName}") }
            runCatching {
                bot.poll(
                    allowedChats, running,
                    onEvent = { event -> log(if (event.contains("ERROR", true) || event.contains("SECURITY", true)) "WARN" else "INFO", event) },
                    callbacks = TelegramBotClient.PollCallbacks(
                        onMessage = { _, _ -> null },
                        onButton = { _, _ -> null },
                        onMessageWithUser = { chatId, userId, text -> handleUpdate(bot, chatId, userId, text) },
                        onButtonWithUser = { chatId, userId, data -> handleUpdate(bot, chatId, userId, data) }
                    )
                )
            }.onFailure { if (running.get()) log("ERROR", "Polling остановлен: ${it.message ?: it.javaClass.simpleName}") }
            if (running.get()) stopSelf()
        }, "niu-telegram-foreground").apply { isDaemon = true; start() }
    }

    private fun handleUpdate(bot: TelegramBotClient, chatId: String, userId: String, incoming: String): String? {
        val admins = prefs.getStringSet("telegram_admin_user_ids", emptySet()).orEmpty()
        val users = prefs.getStringSet("telegram_allowed_user_ids", emptySet()).orEmpty()
        val isAdmin = userId.isNotBlank() && userId in admins
        val isKnownUser = users.isEmpty() || userId in users || isAdmin
        val trimmed = incoming.trim()
        val command = trimmed.substringBefore(' ').substringBefore('@').lowercase(Locale.ROOT)
        val argument = trimmed.substringAfter(' ', "").trim()
        log("INFO", "Входящая команда $command · роль=${if (isAdmin) "администратор" else if (isKnownUser) "пользователь" else "гость"}")
        if (!isKnownUser && command !in setOf("/start", "/help", "/ping")) {
            log("WARN", "Отказ в доступе · user_id=${maskId(userId)}")
            return "Доступ не предоставлен. Обратитесь к администратору бота. Ваш ID: $userId"
        }
        val adminCommands = setOf("/admin", "/users", "/grantadmin", "/revokeadmin", "/grantuser", "/revokeuser", "/logs", "/errors", "/analyze", "/fix")
        if (command in adminCommands && !isAdmin) return "Команда доступна только администраторам."
        return when (command) {
            "/start", "/help" -> helpText(isAdmin)
            "/menu" -> {
                val defaults = "Статус|/status\nМодели NIU|/models\nТранспорт|/vehicle\nДиагностика|/diagnostics\nBluetooth|/ble\nNIU Cloud|/cloud\nЖурнал|/logs"
                val lines = prefs.getString("menu_buttons", defaults).orEmpty()
                val buttons = lines.lines().mapNotNull { line ->
                    val parts = line.split("|", limit = 2).map(String::trim)
                    if (parts.size == 2 && parts[0].isNotBlank() && parts[1].matches(Regex("/[a-zA-Z0-9_]{1,32}"))) parts[0] to parts[1] else null
                }.take(12)
                bot.sendMenu(chatId, buttons); log("INFO", "Пользователь запросил кнопочное меню · кнопок=${buttons.size}"); null
            }
            "/role" -> "Ваш Telegram ID: $userId\nРоль: ${if (isAdmin) "Администратор" else if (isKnownUser) "Пользователь" else "Гость"}"
            "/status" -> "NIU MOBILITY STUDIO · СТАТУС\nБот: работает в фоновом режиме\nРоль: ${if (isAdmin) "администратор" else "пользователь"}\nРазрешённые чаты: ${prefs.getString("allowed_chat_ids", "").orEmpty().split(',', ';', '\n').count { it.isNotBlank() }}"
            "/models" -> "Линейки NIU: NQi · MQi · UQi · GOVA · FX · RQi · FQi · KQi. Поддержка BLE-команд зависит от модели и версии прошивки."
            "/vehicle" -> "Профили транспорта и активный скутер доступны в приложении NIU Mobility Studio."
            "/ble" -> "Bluetooth LE управляется телефоном. Для сканирования включите Bluetooth и выдайте приложению необходимые разрешения Android."
            "/nfc" -> "NFC: проверка доступности и чтение поддерживаемых меток выполняются на телефоне."
            "/diagnostics" -> "Диагностика NIU\nСобытий бота: ${consoleLines().size}\nОшибок бота: ${consoleLines().count { it.contains("ERROR", true) }}\nПодробности: /errors (администратор)"
            "/cloud" -> "NIU Cloud: состояние аккаунта и подключения проверяется в приложении. Доступность API зависит от региона и версии сервиса."
            "/service" -> "Обслуживание и поездки хранятся локально в приложении NIU Mobility Studio."
            "/ping" -> "Связь с ботом подтверждена."
            "/version" -> "NIU Mobility Studio ${BuildConfig.VERSION_NAME} · Android API ${Build.VERSION.SDK_INT}"
            "/users", "/admin" -> ("УПРАВЛЕНИЕ ДОСТУПОМ\nАдминистраторы (${admins.size}): ${admins.sorted().joinToString(", ").ifBlank { "нет" }}\nОбычные пользователи (${users.size}): ${users.sorted().joinToString(", ").ifBlank { "нет" }}\n\n/grantadmin ID — назначить администратора\n/revokeadmin ID — снять права\n/grantuser ID — разрешить пользователя\n/revokeuser ID — удалить пользователя").take(3900)
            "/grantadmin", "/revokeadmin", "/grantuser", "/revokeuser" -> {
                if (!argument.matches(Regex("[0-9]{3,24}"))) return "Укажите числовой Telegram ID: $command 123456789"
                val key = if (command.endsWith("admin")) "telegram_admin_user_ids" else "telegram_allowed_user_ids"
                val mutable = prefs.getStringSet(key, emptySet())?.toMutableSet() ?: mutableSetOf()
                if (command.startsWith("/grant")) mutable.add(argument) else mutable.remove(argument)
                prefs.edit().putStringSet(key, mutable).apply()
                log("INFO", "Администратор ${if (command.startsWith("/grant")) "изменил" else "удалил"} роль для user_id=${maskId(argument)}")
                "${if (command.startsWith("/grant")) "Добавлен" else "Удалён"} пользователь $argument ${if (command.endsWith("admin")) "в списке администраторов" else "в списке обычных пользователей"}."
            }
            "/logs" -> formatLogReply("ПОСЛЕДНИЕ СОБЫТИЯ TELEGRAM", consoleLines().takeLast(15))
            "/errors" -> formatLogReply("ОШИБКИ TELEGRAM", consoleLines().filter { it.contains("ERROR", true) || it.contains("WARN", true) }.takeLast(15))
            "/analyze", "/ai", "/fix" -> runAi(command, argument)
            else -> if (trimmed.startsWith("/")) "Неизвестная команда. Используйте /help." else "Отправьте команду /help или задайте вопрос через /ai <текст>."
        }
    }

    private fun helpText(isAdmin: Boolean): String = buildString {
        append("NIU MOBILITY STUDIO BOT\n\n")
        append("ОСНОВНЫЕ КОМАНДЫ\n/role — моя роль и ID\n/status — состояние бота\n/vehicle — активный транспорт\n/models — линейки NIU\n/ble — Bluetooth LE\n/nfc — NFC\n/diagnostics — диагностика\n/cloud — NIU Cloud\n/service — обслуживание\n/menu — кнопочное меню\n/ping — проверка связи\n/version — версия\n")
        append("\nAI-ПОМОЩНИК\n/ai <текст> — вопрос AI\n")
        if (isAdmin) append("\nАДМИНИСТРАТОР\n/logs — последние логи\n/errors — ошибки\n/analyze — AI-анализ\n/fix <описание> — предложение исправления\n/users — список ролей\n/grantadmin ID /revokeadmin ID\n/grantuser ID /revokeuser ID\n")
        append("\nИзменения в приложении автоматически не применяются.")
    }

    private fun runAi(command: String, argument: String): String {
        val endpoint = prefs.getString("ai_backend_url", "").orEmpty()
        if (!endpoint.startsWith("https://")) return "AI backend не настроен. Укажите HTTPS URL в приложении."
        if (command != "/analyze" && argument.isBlank()) return when (command) {
            "/fix" -> "Укажите описание: /fix описание проблемы"
            else -> "Укажите вопрос: /ai ваш вопрос"
        }
        val store = SecureSecretStore(getSharedPreferences("niu_secure_secrets", MODE_PRIVATE))
        val backendToken = runCatching { store.getOrThrow("telegram_ai_backend_token") }.getOrNull()
        val prompt = when (command) {
            "/analyze" -> "Проанализируй последние события Telegram и ошибки NIU Mobility Studio. Выдели причины и безопасные проверки."
            "/fix" -> "Подготовь предложение исправления, не применяй изменения автоматически: $argument"
            else -> argument
        }
        return runCatching { TelegramAiAssistant.respond(endpoint, backendToken, prompt, consoleLines().takeLast(80)) }
            .onFailure { log("ERROR", "AI request failed: ${it.javaClass.simpleName}: ${it.message}") }
            .getOrElse { "Ошибка AI: ${it.message?.take(220) ?: it.javaClass.simpleName}" }
    }

    private fun consoleLines(): List<String> = prefs.getString("telegram_console_lines", "").orEmpty().lines().filter { it.isNotBlank() }

    private fun formatLogReply(title: String, lines: List<String>): String {
        if (lines.isEmpty()) return "$title\n\nЗаписей пока нет."
        val pretty = lines.map { line ->
            val match = Regex("^(\\d{2}:\\d{2}:\\d{2})\\s+\\[(INFO|WARN|ERROR)\\]\\s*(.*)$").matchEntire(line)
            if (match != null) "${match.groupValues[1]}  ${match.groupValues[2]}  ${match.groupValues[3].take(220)}" else line.take(240)
        }
        return (listOf(title, "") + pretty).joinToString("\n").take(3900)
    }

    private fun maskId(value: String): String = if (value.length <= 3) "***" else value.take(3) + "***"

    private fun stopBot() {
        val wasRunning = running.getAndSet(false)
        worker?.interrupt()
        worker = null
        client = null
        if (::prefs.isInitialized) prefs.edit().putBoolean("telegram_service_running", false).apply()
        if (wasRunning) log("INFO", "Фоновый сервис остановлен")
    }

    override fun onDestroy() {
        stopBot()
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else @Suppress("DEPRECATION") stopForeground(true)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
