package com.niu.fxstudio.admin

import android.content.Context

/** No administrator console is packaged in the User distribution. */
object AdminConsoleEntry {
    fun open(context: Context) = Unit
}
