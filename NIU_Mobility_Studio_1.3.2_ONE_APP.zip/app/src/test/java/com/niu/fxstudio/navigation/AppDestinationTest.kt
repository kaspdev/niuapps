package com.niu.fxstudio.navigation

import org.junit.Assert.assertEquals
import org.junit.Test

class AppDestinationTest {
    @Test fun legacyRoutesRemainStable() {
        assertEquals(AppDestination.WORKSPACE, AppDestination.fromLegacyTab(0))
        assertEquals(AppDestination.BLE, AppDestination.fromLegacyTab(4))
        assertEquals(AppDestination.AI, AppDestination.fromLegacyTab(12))
        assertEquals(AppDestination.CODE_WORKSPACE, AppDestination.fromLegacyTab(13))
        assertEquals(AppDestination.TELEGRAM, AppDestination.fromLegacyTab(16))
    }

    @Test fun unknownRouteFallsBackToWorkspace() {
        assertEquals(AppDestination.WORKSPACE, AppDestination.fromLegacyTab(99))
    }
}
