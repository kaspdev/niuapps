package com.niu.fxstudio.feature.workspace.domain

import org.junit.Assert.assertEquals
import org.junit.Test

class WorkspaceSessionTest {
    @Test fun routeIsClampedToSupportedLegacyRange() {
        assertEquals(0, WorkspaceSession(lastRoute = -1).normalized().lastRoute)
        assertEquals(13, WorkspaceSession(lastRoute = 99).normalized().lastRoute)
    }

    @Test fun sessionMetadataIsPreserved() {
        val session = WorkspaceSession(4, "content://projects/demo", true, true).normalized()
        assertEquals(4, session.lastRoute)
        assertEquals("content://projects/demo", session.lastProjectUri)
        assertEquals(true, session.editorSplitEnabled)
        assertEquals(true, session.terminalExpanded)
    }
}
