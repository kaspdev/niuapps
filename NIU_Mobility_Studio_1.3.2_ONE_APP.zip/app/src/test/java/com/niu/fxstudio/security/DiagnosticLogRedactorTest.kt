package com.niu.fxstudio.security

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DiagnosticLogRedactorTest {
    @Test
    fun redactsCredentialsInJsonAndKeyValueLogs() {
        val input = """{"access_token":"access-secret-123", password=plain-secret, Authorization: Bearer abc.def.ghi}"""
        val safe = DiagnosticLogRedactor.redact(input)

        assertFalse(safe.contains("access-secret-123"))
        assertFalse(safe.contains("plain-secret"))
        assertFalse(safe.contains("abc.def.ghi"))
        assertTrue(safe.contains("[REDACTED]"))
        assertFalse(safe.contains("[REDACTED] [REDACTED]"))
    }

    @Test
    fun redactsCookiesAndVendorApiKeys() {
        val input = """Cookie: session=private-cookie; refresh=private-refresh
x-api-key=private-api-key x-auth-token=private-auth-token"""
        val safe = DiagnosticLogRedactor.redact(input)

        assertFalse(safe.contains("private-cookie"))
        assertFalse(safe.contains("private-refresh"))
        assertFalse(safe.contains("private-api-key"))
        assertFalse(safe.contains("private-auth-token"))
    }

    @Test
    fun redactsQueryTokensJwtEmailAndDeviceAddress() {
        val input = """GET /v1?access_token=query-secret user=test@example.com jwt=eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.signature 12:34:56:78:9A:BC"""
        val safe = DiagnosticLogRedactor.redact(input)

        assertFalse(safe.contains("query-secret"))
        assertFalse(safe.contains("test@example.com"))
        assertFalse(safe.contains("eyJhbGci"))
        assertFalse(safe.contains("12:34:56:78:9A:BC"))
        assertTrue(safe.contains("REDACTED_EMAIL"))
        assertTrue(safe.contains("REDACTED_DEVICE_ADDRESS"))
    }
}
