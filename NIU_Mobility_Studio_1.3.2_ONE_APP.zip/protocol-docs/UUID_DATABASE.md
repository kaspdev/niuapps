# UUID database — NIU FX 风速版

Evidence means the UUID/properties were reported in the user's nRF Connect capture. It does **not** mean packet semantics or write payloads are known.

| Service UUID | Characteristic UUID | Reported properties / label | Current interpretation | Status |
|---|---|---|---|---|
| `8ec94e30-f315-4f60-9fb8-838830daea52` | `8ec94e31-f315-4f60-9fb8-838830daea52` | Notify / Read; Chip to App | Device-to-phone notification candidate | Observed; payload undecoded |
| same | `8ec94e32-f315-4f60-9fb8-838830daea52` | Read / Write / Write Without Response | App-to-chip candidate | Observed; do not write unknown bytes |
| same | `8ec94e33-f315-4f60-9fb8-838830daea52` | Read / Write / Write Without Response; read returned GATT AUTH FAIL (0x89) | Protected characteristic candidate | Auth failure observed; no bypass attempted |
| `61751276-fdd6-11ed-be56-0242ac120002` | `99ea30e2-fdda-11ed-be56-0242ac120002` | Write Without Response | Additional write-channel candidate | Observed; purpose/payload unknown |

The BLE peer previously reported by the user was `NIU Link F8E1`, MAC `54:88:FE:54:F8:E1`. Do not treat a MAC address as a permanent device identity; it is included only as historical capture metadata.
