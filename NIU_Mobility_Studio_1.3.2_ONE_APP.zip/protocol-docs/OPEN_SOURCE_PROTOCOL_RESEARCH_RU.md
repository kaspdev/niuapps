# Открытые исследования протоколов NIU

Обновлено: 2026-11-05.

Главный вывод: NIU — набор разных поколений ECU/VCU, dashboard и телематических блоков. Одной команды/UUID-карты на все NQi, MQi, UQi, GOVA, FX, RQi, FQi и KQi открытые источники не подтверждают.

## Найденные проекты и границы применимости

- `Bonnee/niu-app-api`: reverse-engineered облачный API официального приложения (историческая спецификация 2019). В ней описаны login, список привязанных mopeds, данные по SN, поездки, battery health и статистика. Это не BLE-пакеты и не гарантия доступности endpoint сегодня. Не запрашивать пароль NIU внутри NIU Mobility Studio до отдельного безопасного OAuth/официального способа.
- `MyNIU / Hacking the NIU`: исследование обмена NIU с серверами, обновлений, приложения и прошивок.
- `MyNIU / Reverse engineering the ECU`: конкретные наблюдения относятся к N1S и некоторым NQi примерно до 2023; статья прямо говорит о других ECU у N1, NQi GT, MQi и иных моделей.
- `belveder79/NIUScooterHacking`: KQi3 Pro, ESP32/BMS emulator и аппаратная часть; не универсальный протокол команд для всего NIU.
- `scooter-tuning-db`: NIU прямо находится в not-covered; Xiaomi/Ninebot карты не переносить на NIU.
- `CamiAlfa/M365-BLE-PROTOCOL` и `ub4raf/Ninebot-PROTOCOL`: LGPL-2.1-or-later, но это Xiaomi/Ninebot, не NIU.

## FX GATT observations already present in this project

- `8ec94e31-f315-4f60-9fb8-838830daea52` — Chip → App candidate.
- `8ec94e32-f315-4f60-9fb8-838830daea52` — App → Chip candidate.
- `8ec94e33-f315-4f60-9fb8-838830daea52` — protected characteristic; prior AUTH FAIL 0x89.
- `99ea30e2-fdda-11ed-be56-0242ac120002` — write-without-response candidate.

Эти UUID относятся только к наблюдению FX и не должны применяться к другим линейкам.

## Интеграция

SDK содержит универсальный каталог семейств и реестр операций. Сейчас ни одна неизвестная BLE-команда не имеет payload, поэтому реестр блокирует отправку. Следующий путь к реальной реализации: capture официального приложения + точный модельный/firmware ID + сопоставление запроса и ACK + повторяемые испытания на безопасно зафиксированном скутере. ИИ помогает декодировать и документировать, но не является источником истины.
