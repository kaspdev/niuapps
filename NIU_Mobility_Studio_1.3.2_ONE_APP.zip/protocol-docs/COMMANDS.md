# Command registry — evidence policy

No byte-level command is currently enabled for the factory FX 风速版.

| Evidence state | Meaning | Can transmit? |
|---|---|---|
| `VERIFIED_ON_FX` | Exact payload and safe expected behavior confirmed on this FX | Only according to an explicit per-command policy |
| `FOUND_IN_APK_NOT_DECODED` | A symbolic operation name is visible in an APK resource/code analysis | No |
| `VERIFIED_ON_OTHER_MODEL_ONLY` | Evidence belongs to a different NIU model | No |
| `UNKNOWN` | Insufficient evidence | No |

The current APK's DEX is a NetEase wrapper shell; earlier reported symbolic names such as `read.batteryInfo` and `write.drivingMode` have not been independently re-established from this file. They must not be treated as verified SDK exports.

High-risk operations (unlock/lock, ride mode, speed limits, ECU settings, alarm, restart, OTA and factory reset) remain blocked until exact FX compatibility and payload semantics are demonstrated. No authentication bypass or ownership-binding bypass is implemented.
