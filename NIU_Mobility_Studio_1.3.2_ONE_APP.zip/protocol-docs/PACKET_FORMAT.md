# Packet format — status

**Not yet recovered.** No byte-level frame format is currently verified for the factory NIU FX 风速版.

| Field | Status | Notes |
|---|---|---|
| Start/header bytes | Unknown | Do not assume common NIU formats |
| Length field | Unknown | Width, endianness and whether it includes header/checksum are unknown |
| Command identifier | Unknown | No verified command IDs |
| Sequence/request ID | Unknown | Unknown whether present |
| Payload encoding | Unknown | Do not infer integer scaling or field meanings |
| Checksum/CRC | Unknown | Polynomial, init, reflection and byte order unknown |
| Encryption/authentication | Unknown | GATT AUTH FAIL was reported on one characteristic; exact mechanism unknown |
| Fragmentation | Unknown | ATT MTU and application-layer fragmentation not established |

The SDK currently stores raw bytes and returns `NOT_IMPLEMENTED` from its codec. This is intentional: a decoder that guesses incorrectly could turn arbitrary bytes into unsafe control operations.

## Required evidence to implement a codec

- Multiple complete passive captures on the same characteristic.
- Direction and operation context for each capture (READ response vs notification vs write completion).
- Repeated captures showing stable fields and changing fields.
- A verified request/response pair before assigning command IDs.
- Independent tests for length and checksum on captured frames.
