package com.niu.sdk.bridge

import com.niu.sdk.profile.NiuModelCatalog
import java.util.Locale

/** Read-only Cloud ↔ BLE correlation. It never authorizes ECU writes. */
data class CloudVehicleIdentity(
    val serial: String,
    val name: String,
    val model: String,
    val vin: String = ""
)

data class BleVehicleIdentity(
    val advertisedName: String = "",
    val serial: String = "",
    val vin: String = "",
    val firmware: String = "",
    val gattServiceUuids: Set<String> = emptySet(),
    val observedAtEpochMs: Long = System.currentTimeMillis()
)

enum class IdentityMatch { EXACT_SERIAL, EXACT_VIN, NO_MATCH, INSUFFICIENT_DATA }
enum class DataAgreement { SAME, DIFFERENT, CLOUD_ONLY, BLE_ONLY, NOT_COMPARABLE }

data class CloudEcuBridgeReport(
    val match: IdentityMatch,
    val modelAgreement: DataAgreement,
    val cloud: CloudVehicleIdentity?,
    val ble: BleVehicleIdentity?,
    val detectedFamilyId: String?,
    val ecuProtocolReady: Boolean,
    val notes: List<String>
)

object CloudEcuBridge {
    fun correlate(cloud: CloudVehicleIdentity?, ble: BleVehicleIdentity?): CloudEcuBridgeReport {
        val match = when {
            cloud == null || ble == null -> IdentityMatch.INSUFFICIENT_DATA
            cloud.serial.isNotBlank() && ble.serial.isNotBlank() &&
                cloud.serial.trim().equals(ble.serial.trim(), true) -> IdentityMatch.EXACT_SERIAL
            cloud.vin.isNotBlank() && ble.vin.isNotBlank() &&
                cloud.vin.trim().equals(ble.vin.trim(), true) -> IdentityMatch.EXACT_VIN
            cloud.serial.isNotBlank() && ble.serial.isNotBlank() -> IdentityMatch.NO_MATCH
            else -> IdentityMatch.INSUFFICIENT_DATA
        }
        val cloudFamily = cloud?.model?.takeIf { it.isNotBlank() }?.let(NiuModelCatalog::detect)
        val bleModelText = listOfNotNull(ble?.advertisedName, ble?.firmware).joinToString(" ")
        val bleFamily = bleModelText.takeIf { it.isNotBlank() }?.let(NiuModelCatalog::detect)
        val agreement = when {
            cloudFamily == null && bleFamily == null -> DataAgreement.NOT_COMPARABLE
            cloudFamily != null && bleFamily == null -> DataAgreement.CLOUD_ONLY
            cloudFamily == null && bleFamily != null -> DataAgreement.BLE_ONLY
            cloudFamily?.id == bleFamily?.id -> DataAgreement.SAME
            else -> DataAgreement.DIFFERENT
        }
        val notes = buildList {
            when (match) {
                IdentityMatch.EXACT_SERIAL -> add("Cloud и BLE совпали по точному серийному номеру.")
                IdentityMatch.EXACT_VIN -> add("Cloud и BLE совпали по точному VIN.")
                IdentityMatch.NO_MATCH -> add("Серийные номера Cloud и BLE различаются; профили не объединены.")
                IdentityMatch.INSUFFICIENT_DATA -> add("Недостаточно идентификаторов для доказанного сопоставления.")
            }
            if (agreement == DataAgreement.DIFFERENT) add("Семейства моделей различаются; управляющие операции должны оставаться заблокированными.")
            if (ble?.firmware.isNullOrBlank()) add("Версия BLE-прошивки пока не получена.")
            add("Совпадение Cloud identity не подтверждает формат BLE-команд или ECU ACK.")
        }
        return CloudEcuBridgeReport(
            match, agreement, cloud, ble,
            (cloudFamily ?: bleFamily)?.id,
            ecuProtocolReady = false,
            notes = notes
        )
    }
}

/** Honest per-operation lifecycle: transport acceptance is not ECU execution. */
enum class EcuOperationState {
    QUEUED, SENDING, GATT_ACCEPTED, WAITING_FOR_ECU, RESPONSE_RECEIVED,
    ECU_ACKNOWLEDGED, GATT_ERROR, TIMEOUT, BLOCKED, RESPONSE_UNPARSED
}

data class EcuOperationRecord(
    val id: String,
    val commandId: String,
    val characteristicUuid: String,
    val txHex: String,
    val state: EcuOperationState,
    val detail: String,
    val timestampEpochMs: Long = System.currentTimeMillis()
)

object EcuOperationClassifier {
    fun afterGattWrite(success: Boolean): EcuOperationState =
        if (success) EcuOperationState.WAITING_FOR_ECU else EcuOperationState.GATT_ERROR

    fun afterResponse(parsedAsKnownAck: Boolean): EcuOperationState =
        if (parsedAsKnownAck) EcuOperationState.ECU_ACKNOWLEDGED else EcuOperationState.RESPONSE_UNPARSED
}
