package com.niu.sdk.profile

import java.util.UUID

/** GATT identifiers observed in the user's NIU Link nRF report. */
data class NiuGattCharacteristic(
    val uuid: UUID,
    val role: String,
    val evidence: EvidenceLevel,
    val note: String = ""
)

enum class EvidenceLevel { OBSERVED_IN_GATT_REPORT, INFERRED, UNKNOWN }

data class NiuGattService(val uuid: UUID, val characteristics: List<NiuGattCharacteristic>)

data class NiuGattProfile(
    val id: String,
    val displayName: String,
    val services: List<NiuGattService>
)

object FxFengsuProfile {
    private fun uuid(value: String) = UUID.fromString(value)

    val profile = NiuGattProfile(
        id = "fx-fengsu-niu-link",
        displayName = "NIU FX 风速版 · NIU Link",
        services = listOf(
            NiuGattService(
                uuid("8ec94e30-f315-4f60-9fb8-838830daea52"),
                listOf(
                    NiuGattCharacteristic(uuid("8ec94e31-f315-4f60-9fb8-838830daea52"), "Chip-to-App", EvidenceLevel.OBSERVED_IN_GATT_REPORT, "Notify/Read reported"),
                    NiuGattCharacteristic(uuid("8ec94e32-f315-4f60-9fb8-838830daea52"), "App-to-Chip candidate", EvidenceLevel.OBSERVED_IN_GATT_REPORT, "Read/Write/Write Without Response reported; payload unknown"),
                    NiuGattCharacteristic(uuid("8ec94e33-f315-4f60-9fb8-838830daea52"), "Protected characteristic", EvidenceLevel.OBSERVED_IN_GATT_REPORT, "GATT AUTH FAIL (0x89) reported; do not probe with writes")
                )
            ),
            NiuGattService(
                uuid("61751276-fdd6-11ed-be56-0242ac120002"),
                listOf(
                    NiuGattCharacteristic(uuid("99ea30e2-fdda-11ed-be56-0242ac120002"), "Write channel candidate", EvidenceLevel.OBSERVED_IN_GATT_REPORT, "Write Without Response reported; command format unknown")
                )
            )
        )
    )
}
