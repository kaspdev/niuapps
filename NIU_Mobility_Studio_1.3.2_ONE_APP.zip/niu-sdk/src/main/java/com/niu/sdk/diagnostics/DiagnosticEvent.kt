package com.niu.sdk.diagnostics

data class DiagnosticEvent(
    val timestampEpochMillis: Long,
    val category: String,
    val message: String,
    val details: Map<String, String> = emptyMap()
)
