package com.niu.sdk.commands

/** Evidence is scoped to a precise model/firmware; AI analysis cannot upgrade it. */
enum class CommandEvidence { VERIFIED_ON_EXACT_MODEL, FOUND_IN_APP_NOT_DECODED, VERIFIED_ON_OTHER_MODEL_ONLY, UNKNOWN }
enum class CommandKind { READ, WRITE, CONTROL, OTA, FACTORY_RESET }

data class NiuCommandSpec(
    val id: String,
    val kind: CommandKind,
    val evidence: CommandEvidence,
    val description: String,
    val payloadTemplate: ByteArray? = null,
    val source: String = "",
    val model: String = "*",
    val firmware: String? = null,
    val requiresOwnerAuthorization: Boolean = true,
    val requiresStationaryVehicle: Boolean = true
)

data class CommandPreflight(val allowed: Boolean, val reason: String, val evidence: CommandEvidence)

/** Safe registry shared by all NIU families. No guessed payloads are ever transmitted. */
class NiuCommandRegistry(specs: List<NiuCommandSpec> = NIU_COMMAND_CATALOG) {
    private val entries = specs.associateBy { it.id }
    fun all(): List<NiuCommandSpec> = entries.values.toList()
    fun forModel(modelId: String): List<NiuCommandSpec> = entries.values.filter { it.model == "*" || it.model.equals(modelId, true) }
    fun find(id: String): NiuCommandSpec? = entries[id]

    fun preflight(
        id: String,
        model: String = "fx",
        firmware: String? = null,
        ownerAuthorized: Boolean = false,
        vehicleStationary: Boolean = false
    ): CommandPreflight {
        val spec = find(id) ?: return CommandPreflight(false, "Команда отсутствует в реестре", CommandEvidence.UNKNOWN)
        if (spec.model != "*" && !spec.model.equals(model, true))
            return CommandPreflight(false, "Команда не предназначена для семейства $model", spec.evidence)
        if (spec.firmware != null && !spec.firmware.equals(firmware, true))
            return CommandPreflight(false, "Нужна точная версия прошивки ${spec.firmware}", spec.evidence)
        if (spec.evidence != CommandEvidence.VERIFIED_ON_EXACT_MODEL || spec.payloadTemplate == null)
            return CommandPreflight(false, "Нет проверенного payload для точной модели и прошивки", spec.evidence)
        if (spec.requiresOwnerAuthorization && !ownerAuthorized)
            return CommandPreflight(false, "Требуется штатная авторизация владельца", spec.evidence)
        if (spec.requiresStationaryVehicle && !vehicleStationary)
            return CommandPreflight(false, "Сначала подтвердите неподвижность скутера", spec.evidence)
        return CommandPreflight(true, "Проверка пройдена; требуется проверка ACK устройства", spec.evidence)
    }

    fun mayTransmit(spec: NiuCommandSpec, model: String, firmware: String?, ownerAuthorized: Boolean, stationary: Boolean): Boolean =
        preflight(spec.id, model, firmware, ownerAuthorized, stationary).allowed

    companion object {
        /** Deliberately empty of executable packets until exact-model captures are validated. */
        val NIU_COMMAND_CATALOG = listOf(
            NiuCommandSpec("telemetry.status", CommandKind.READ, CommandEvidence.UNKNOWN, "Статус и телеметрия: формат зависит от ECU/прошивки", source = "NIU cloud API research; BLE payload not established"),
            NiuCommandSpec("vehicle.lock", CommandKind.CONTROL, CommandEvidence.UNKNOWN, "Блокировка: требуется подтверждённый штатный handshake и ACK", source = "NIU app/API reverse engineering; not a BLE packet"),
            NiuCommandSpec("vehicle.unlock", CommandKind.CONTROL, CommandEvidence.UNKNOWN, "Разблокировка: только штатная авторизация владельца", source = "NIU app/API reverse engineering; not a BLE packet"),
            NiuCommandSpec("vehicle.find", CommandKind.CONTROL, CommandEvidence.UNKNOWN, "Поиск/звуковой сигнал: точная команда зависит от модели", source = "Not verified across model families"),
            NiuCommandSpec("vehicle.ride_mode", CommandKind.WRITE, CommandEvidence.UNKNOWN, "Режим езды: значения и диапазоны зависят от ECU", source = "Not verified across model families"),
            NiuCommandSpec("vehicle.alarm", CommandKind.CONTROL, CommandEvidence.UNKNOWN, "Сигнализация: требуется подтверждение состояния от ECU", source = "Not verified across model families"),
            NiuCommandSpec("firmware.ota", CommandKind.OTA, CommandEvidence.UNKNOWN, "OTA отключено до проверки штатного обновляющего механизма", source = "Official app flow required"),
            NiuCommandSpec("vehicle.factory_reset", CommandKind.FACTORY_RESET, CommandEvidence.UNKNOWN, "Сброс недоступен без доказанного протокола и отдельного подтверждения", source = "Safety policy")
        )
        /** Backward-compatible name for the first project release. */
        val FX_COMMAND_CATALOG: List<NiuCommandSpec> get() = NIU_COMMAND_CATALOG
    }
}
