package com.niu.sdk.profile

/** Cross-lineup NIU catalogue. A family entry is not a claim of protocol compatibility. */
enum class NiuVehicleCategory { MOPED, SCOOTER, MOTORCYCLE, UNKNOWN }
enum class NiuProtocolCoverage { CLOUD_API_DOCUMENTED, BLE_OBSERVED_ONLY, MODEL_SPECIFIC_RESEARCH, NOT_ESTABLISHED }

data class NiuModelFamily(
    val id: String,
    val name: String,
    val category: NiuVehicleCategory,
    val examples: List<String>,
    val coverage: NiuProtocolCoverage,
    val note: String
)

object NiuModelCatalog {
    val families = listOf(
        NiuModelFamily("nqi", "NQi", NiuVehicleCategory.MOPED, listOf("NQi", "NQi Sport", "NQi GT", "NQi GTS", "NQiX", "NQiX 1000", "NQiX 1500", "NQi Cargo"), NiuProtocolCoverage.MODEL_SPECIFIC_RESEARCH, "Разные поколения ECU; совместимость подтверждать по точной модели, году и прошивке."),
        NiuModelFamily("mqi", "MQi", NiuVehicleCategory.MOPED, listOf("MQi", "MQi+", "MQi GT", "MQi EVO", "MQi+ Sport", "MQiL"), NiuProtocolCoverage.MODEL_SPECIFIC_RESEARCH, "Семейство с несколькими поколениями приборок и контроллеров."),
        NiuModelFamily("uqi", "UQi", NiuVehicleCategory.MOPED, listOf("UQi", "UQi+", "UQi GT", "UQi Pro", "UQi Sport", "UQi Cargo"), NiuProtocolCoverage.MODEL_SPECIFIC_RESEARCH, "Компактная линейка; не считать протокол NQi автоматически совместимым."),
        NiuModelFamily("gova", "GOVA", NiuVehicleCategory.MOPED, listOf("GOVA", "GOVA G1", "GOVA F0", "GOVA C0", "GOVA F2"), NiuProtocolCoverage.NOT_ESTABLISHED, "Комплектация Cloud ECU и smart-функций зависит от варианта и рынка."),
        NiuModelFamily("fx", "FX", NiuVehicleCategory.MOTORCYCLE, listOf("FX", "FX 风速版", "FX Pro", "FX 150", "FX 300"), NiuProtocolCoverage.BLE_OBSERVED_ONLY, "Есть пользовательские наблюдения GATT; формат команд и handshake не подтверждены."),
        NiuModelFamily("rqi", "RQi", NiuVehicleCategory.MOTORCYCLE, listOf("RQi Sport", "RQi", "RQi Pro"), NiuProtocolCoverage.NOT_ESTABLISHED, "Отдельная архитектура; профиль создаётся после сбора GATT и версии ПО."),
        NiuModelFamily("fqi", "FQi", NiuVehicleCategory.SCOOTER, listOf("FQi", "FQi 300", "FQi 500", "FQi 100", "FQi Air"), NiuProtocolCoverage.NOT_ESTABLISHED, "Электросамокатная линейка; не переносить команды KQi без подтверждения."),
        NiuModelFamily("kqi", "KQi", NiuVehicleCategory.SCOOTER, listOf("KQi1", "KQi2", "KQi3", "KQi Air", "KQi 100", "KQi 200", "KQi 300", "KQi  Air"), NiuProtocolCoverage.MODEL_SPECIFIC_RESEARCH, "Есть сторонние аппаратные исследования отдельных KQi, но не полная универсальная BLE-карта."),
        NiuModelFamily("other", "Другая модель NIU", NiuVehicleCategory.UNKNOWN, emptyList(), NiuProtocolCoverage.NOT_ESTABLISHED, "Неизвестная модель остаётся в режиме обнаружения и пассивной диагностики.")
    )

    fun family(id: String): NiuModelFamily? = families.firstOrNull { it.id == id }
    fun detect(text: String): NiuModelFamily? {
        val value = text.trim().lowercase()
        return families.firstOrNull { f -> f.id != "other" && (value.contains(f.id) || f.examples.any { value.contains(it.lowercase()) }) }
    }
}
