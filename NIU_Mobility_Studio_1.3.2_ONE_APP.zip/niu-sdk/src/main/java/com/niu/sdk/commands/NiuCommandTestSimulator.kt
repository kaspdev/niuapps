package com.niu.sdk.commands

/**
 * Offline-only command test harness.
 *
 * It exercises command registration, model matching and preflight gates.
 * It never opens BLE, sends cloud requests, or writes to a vehicle.
 */
data class NiuCommandSimulationResult(
    val commandId: String,
    val modelId: String,
    val passed: Boolean,
    val transmitted: Boolean,
    val message: String
)

class NiuCommandTestSimulator(
    private val registry: NiuCommandRegistry = NiuCommandRegistry()
) {
    fun runAll(modelId: String, firmware: String? = null): List<NiuCommandSimulationResult> =
        registry.forModel(modelId).map { spec ->
            val preflight = registry.preflight(
                id = spec.id,
                model = modelId,
                firmware = firmware,
                ownerAuthorized = true,
                vehicleStationary = true
            )
            // A simulation succeeds when the safety gate behaves as expected:
            // unknown or unverified control commands must remain blocked.
            val expectedBlocked = spec.kind != CommandKind.READ &&
                spec.evidence != CommandEvidence.VERIFIED_ON_EXACT_MODEL
            val passed = if (expectedBlocked) !preflight.allowed else preflight.allowed
            NiuCommandSimulationResult(
                commandId = spec.id,
                modelId = modelId,
                passed = passed,
                transmitted = false,
                message = when {
                    preflight.allowed -> "Проверка допуска пройдена; реальная отправка отключена в тестовом режиме."
                    passed -> "PASS: опасная/неподтверждённая команда корректно заблокирована (${preflight.reason})."
                    else -> "FAIL: неожиданное состояние допуска (${preflight.reason})."
                }
            )
        }
}
