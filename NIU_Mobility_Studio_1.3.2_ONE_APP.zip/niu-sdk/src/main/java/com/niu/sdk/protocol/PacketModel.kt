package com.niu.sdk.protocol

/** Raw BLE payload. No semantic interpretation is implied. */
data class RawBlePacket(
    val characteristicUuid: String,
    val direction: Direction,
    val payload: ByteArray,
    val capturedAtEpochMillis: Long
) {
    override fun equals(other: Any?): Boolean = other is RawBlePacket &&
        characteristicUuid == other.characteristicUuid && direction == other.direction &&
        payload.contentEquals(other.payload) && capturedAtEpochMillis == other.capturedAtEpochMillis

    override fun hashCode(): Int = 31 * (31 * characteristicUuid.hashCode() + payload.contentHashCode()) + direction.hashCode()
}

enum class Direction { PHONE_TO_DEVICE, DEVICE_TO_PHONE, UNKNOWN }

enum class ParseStatus { NOT_IMPLEMENTED, INCOMPLETE, INVALID, PARSED }

data class PacketParseResult<T>(val status: ParseStatus, val value: T? = null, val explanation: String)

/** Intentionally unimplemented until the actual frame format is recovered and verified. */
interface NiuPacketCodec {
    fun decode(payload: ByteArray): PacketParseResult<DecodedFrame>
    fun encode(frame: DecodedFrame): Result<ByteArray>
}

data class DecodedFrame(
    val raw: ByteArray,
    val header: ByteArray? = null,
    val commandId: Int? = null,
    val data: ByteArray? = null,
    val checksum: ByteArray? = null
)

object UnknownPacketCodec : NiuPacketCodec {
    override fun decode(payload: ByteArray) = PacketParseResult<DecodedFrame>(
        ParseStatus.NOT_IMPLEMENTED,
        explanation = "NIU frame layout, length fields, command IDs and checksum are not verified. Payload retained as raw bytes."
    )

    override fun encode(frame: DecodedFrame): Result<ByteArray> = Result.failure(
        UnsupportedOperationException("Encoding is disabled until the FX packet format is verified.")
    )
}
