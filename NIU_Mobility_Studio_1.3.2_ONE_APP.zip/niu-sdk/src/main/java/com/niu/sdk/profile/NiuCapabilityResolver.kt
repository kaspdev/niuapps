package com.niu.sdk.profile

/**
 * Universal capability matrix.
 *
 * A capability can be visible in the UI without being executable. Remote control is
 * enabled only after the exact model/firmware protocol has been independently verified.
 */
enum class NiuCapabilityState {
    AVAILABLE_CLOUD_READ,
    MODEL_DEPENDENT,
    REQUIRES_PROTOCOL_VALIDATION,
    NOT_ESTABLISHED
}

data class NiuCapability(
    val id: String,
    val title: String,
    val state: NiuCapabilityState,
    val description: String
)

data class NiuVehicleProfile(
    val family: NiuModelFamily,
    val detectedFrom: String,
    val capabilities: List<NiuCapability>
) {
    fun capability(id: String): NiuCapability? = capabilities.firstOrNull { it.id == id }
}

object NiuCapabilityResolver {
    private val commonCapabilities = listOf(
        NiuCapability(
            "cloud.vehicle_list",
            "Список скутеров NIU Cloud",
            NiuCapabilityState.AVAILABLE_CLOUD_READ,
            "Список устройств, уже привязанных к облачному аккаунту."
        ),
        NiuCapability(
            "cloud.vehicle_status",
            "Состояние скутера",
            NiuCapabilityState.MODEL_DEPENDENT,
            "Доступность полей зависит от модели, ECU, региона и облачного API."
        ),
        NiuCapability(
            "cloud.battery",
            "Батарея и заряд",
            NiuCapabilityState.MODEL_DEPENDENT,
            "Показывать только поля, реально возвращённые облаком для этого устройства."
        ),
        NiuCapability(
            "cloud.mileage",
            "Пробег",
            NiuCapabilityState.MODEL_DEPENDENT,
            "Общий и поездочный пробег могут иметь разные источники и единицы."
        ),
        NiuCapability(
            "cloud.trip_history",
            "История поездок",
            NiuCapabilityState.MODEL_DEPENDENT,
            "Зависит от доступности истории для модели и региона."
        ),
        NiuCapability(
            "control.lock",
            "Блокировка",
            NiuCapabilityState.REQUIRES_PROTOCOL_VALIDATION,
            "Нужны подтверждённые endpoint/handshake, ответ устройства и проверка владельца."
        ),
        NiuCapability(
            "control.unlock",
            "Разблокировка",
            NiuCapabilityState.REQUIRES_PROTOCOL_VALIDATION,
            "Не отправлять команду без точной проверки модели, прошивки и подтверждения владельца."
        ),
        NiuCapability(
            "control.find",
            "Поиск скутера",
            NiuCapabilityState.REQUIRES_PROTOCOL_VALIDATION,
            "Сигнал/поиск требует подтверждённого облачного или BLE-механизма."
        ),
        NiuCapability(
            "control.ride_mode",
            "Режим езды",
            NiuCapabilityState.REQUIRES_PROTOCOL_VALIDATION,
            "Значения режимов и допустимые переходы зависят от ECU."
        ),
        NiuCapability(
            "control.alarm",
            "Сигнализация",
            NiuCapabilityState.REQUIRES_PROTOCOL_VALIDATION,
            "Требуется подтверждение фактического состояния после команды."
        )
    )

    fun resolve(modelText: String, firmware: String? = null): NiuVehicleProfile? {
        val family = NiuModelCatalog.detect(modelText) ?: return null
        val capabilities = commonCapabilities.map { capability ->
            when (capability.id) {
                "cloud.vehicle_list" -> capability
                "cloud.vehicle_status", "cloud.battery", "cloud.mileage", "cloud.trip_history" ->
                    capability.copy(
                        state = if (family.coverage == NiuProtocolCoverage.CLOUD_API_DOCUMENTED)
                            NiuCapabilityState.AVAILABLE_CLOUD_READ
                        else NiuCapabilityState.MODEL_DEPENDENT
                    )
                else -> capability
            }
        }
        return NiuVehicleProfile(
            family = family,
            detectedFrom = modelText.trim(),
            capabilities = capabilities
        )
    }

    fun allFamilies(): List<NiuModelFamily> = NiuModelCatalog.families
}
