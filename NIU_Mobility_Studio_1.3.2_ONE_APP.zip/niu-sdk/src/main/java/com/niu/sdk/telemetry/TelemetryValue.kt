package com.niu.sdk.telemetry

/** Raw-first telemetry record; decoded values must carry an explicit evidence note. */
data class TelemetryValue(
    val key: String,
    val raw: ByteArray,
    val decodedText: String? = null,
    val evidenceNote: String = "Raw value only; semantic mapping not verified"
)
