package com.niu.sdk.profile

import org.junit.Assert.*
import org.junit.Test

class NiuModelCatalogTest {
    @Test fun expandedFamilyCatalogKeepsModelsWithinTheirFamily() {
        assertEquals("nqi", NiuModelCatalog.detect("NIU NQiX 1500")?.id)
        assertEquals("mqi", NiuModelCatalog.detect("MQi EVO")?.id)
        assertEquals("kqi", NiuModelCatalog.detect("KQi Air")?.id)
        assertEquals("rqi", NiuModelCatalog.detect("RQi Sport")?.id)
    }

    @Test fun unknownModelDoesNotReceiveAnInventedFamily() {
        assertNull(NiuModelCatalog.detect("unknown electric vehicle"))
    }
}
