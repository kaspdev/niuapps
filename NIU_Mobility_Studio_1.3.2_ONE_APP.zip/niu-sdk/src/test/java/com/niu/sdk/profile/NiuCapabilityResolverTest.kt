package com.niu.sdk.profile

import org.junit.Assert.*
import org.junit.Test

class NiuCapabilityResolverTest {
    @Test fun resolvesKnownFamiliesAcrossTheLineup() {
        listOf(
            "NIU NQiX 1500" to "nqi",
            "MQi EVO" to "mqi",
            "UQi GT" to "uqi",
            "GOVA G1" to "gova",
            "FX 风速版" to "fx",
            "RQi Sport" to "rqi",
            "FQi 500" to "fqi",
            "KQi Air" to "kqi"
        ).forEach { (label, expected) ->
            assertEquals(label, expected, NiuCapabilityResolver.resolve(label)?.family?.id)
        }
    }

    @Test fun everyFamilyGetsTheSameUniversalCapabilityContract() {
        NiuModelCatalog.families.filter { it.id != "other" }.forEach { family ->
            val profile = NiuCapabilityResolver.resolve(family.examples.first())
            assertNotNull(profile)
            listOf(
                "cloud.vehicle_list", "cloud.vehicle_status", "cloud.battery",
                "cloud.mileage", "cloud.trip_history", "control.lock",
                "control.unlock", "control.find", "control.ride_mode", "control.alarm"
            ).forEach { assertNotNull("family=${family.id}, capability=$it", profile!!.capability(it)) }
        }
    }

    @Test fun unknownModelDoesNotReceiveAnAssumedProtocol() {
        assertNull(NiuCapabilityResolver.resolve("Unknown electric vehicle"))
    }

    @Test fun remoteControlsRemainGatedUntilProtocolIsValidated() {
        val profile = NiuCapabilityResolver.resolve("NQi GT")!!
        listOf("control.lock", "control.unlock", "control.find", "control.ride_mode", "control.alarm")
            .forEach { id ->
                assertEquals(
                    NiuCapabilityState.REQUIRES_PROTOCOL_VALIDATION,
                    profile.capability(id)?.state
                )
            }
    }
}
