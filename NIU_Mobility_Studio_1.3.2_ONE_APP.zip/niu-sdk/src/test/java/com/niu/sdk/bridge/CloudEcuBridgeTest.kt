package com.niu.sdk.bridge

import org.junit.Assert.*
import org.junit.Test

class CloudEcuBridgeTest {
    @Test fun exactSerialMatchesButDoesNotAuthorizeProtocol() {
        val report = CloudEcuBridge.correlate(
            CloudVehicleIdentity("SN-123", "NIU", "FX"),
            BleVehicleIdentity(advertisedName = "NIU Link", serial = "sn-123")
        )
        assertEquals(IdentityMatch.EXACT_SERIAL, report.match)
        assertFalse(report.ecuProtocolReady)
    }

    @Test fun differentSerialsNeverMerge() {
        val report = CloudEcuBridge.correlate(
            CloudVehicleIdentity("SN-A", "NIU", "FX"),
            BleVehicleIdentity(advertisedName = "NIU Link", serial = "SN-B")
        )
        assertEquals(IdentityMatch.NO_MATCH, report.match)
    }

    @Test fun gattSuccessIsOnlyWaitingForEcu() {
        assertEquals(EcuOperationState.WAITING_FOR_ECU, EcuOperationClassifier.afterGattWrite(true))
        assertEquals(EcuOperationState.GATT_ERROR, EcuOperationClassifier.afterGattWrite(false))
        assertEquals(EcuOperationState.RESPONSE_UNPARSED, EcuOperationClassifier.afterResponse(false))
    }
}
