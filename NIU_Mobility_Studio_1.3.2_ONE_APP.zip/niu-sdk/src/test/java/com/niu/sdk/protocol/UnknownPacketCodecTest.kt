package com.niu.sdk.protocol

import org.junit.Assert.*
import org.junit.Test

class UnknownPacketCodecTest {
    @Test fun decoderDoesNotInventPacketStructure() {
        val result = UnknownPacketCodec.decode(byteArrayOf(0x01, 0x02, 0x03))
        assertEquals(ParseStatus.NOT_IMPLEMENTED, result.status)
        assertNull(result.value)
    }

    @Test fun encoderIsDisabledUntilProtocolIsVerified() {
        val result = UnknownPacketCodec.encode(DecodedFrame(byteArrayOf(0x01)))
        assertTrue(result.isFailure)
    }
}
