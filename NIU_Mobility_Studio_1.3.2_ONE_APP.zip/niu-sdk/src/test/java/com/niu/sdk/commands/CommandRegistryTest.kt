package com.niu.sdk.commands

import org.junit.Assert.*
import org.junit.Test

class CommandRegistryTest {
    @Test fun catalogContainsCrossFamilyOperationsButNoGuessedPayloads() {
        val registry = NiuCommandRegistry()
        listOf("telemetry.status", "vehicle.lock", "vehicle.unlock", "vehicle.find", "vehicle.ride_mode", "vehicle.alarm").forEach { id ->
            val command = registry.find(id)
            assertNotNull(command)
            assertFalse(registry.preflight(id, model = "nqi", ownerAuthorized = true, vehicleStationary = true).allowed)
            assertNull(command!!.payloadTemplate)
        }
    }

    @Test fun evidenceForOneModelCannotAuthorizeAnotherModel() {
        val read = NiuCommandSpec("read.test", CommandKind.READ, CommandEvidence.VERIFIED_ON_EXACT_MODEL, "test", byteArrayOf(0x01), model = "nqi", requiresOwnerAuthorization = false, requiresStationaryVehicle = false)
        val registry = NiuCommandRegistry(listOf(read))
        assertTrue(registry.preflight("read.test", model = "nqi").allowed)
        assertFalse(registry.preflight("read.test", model = "mqi").allowed)
    }

    @Test fun exactFirmwareAndSafetyPreconditionsAreRequired() {
        val control = NiuCommandSpec("control.test", CommandKind.CONTROL, CommandEvidence.VERIFIED_ON_EXACT_MODEL, "test", byteArrayOf(0x01), model = "fx", firmware = "1.2.3")
        val registry = NiuCommandRegistry(listOf(control))
        assertFalse(registry.preflight("control.test", model = "fx", firmware = "1.2.2", ownerAuthorized = true, vehicleStationary = true).allowed)
        assertFalse(registry.preflight("control.test", model = "fx", firmware = "1.2.3", ownerAuthorized = false, vehicleStationary = true).allowed)
        assertFalse(registry.preflight("control.test", model = "fx", firmware = "1.2.3", ownerAuthorized = true, vehicleStationary = false).allowed)
        assertTrue(registry.preflight("control.test", model = "fx", firmware = "1.2.3", ownerAuthorized = true, vehicleStationary = true).allowed)
    }
}
