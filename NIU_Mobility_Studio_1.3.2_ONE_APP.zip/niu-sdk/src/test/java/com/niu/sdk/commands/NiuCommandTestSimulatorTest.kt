package com.niu.sdk.commands

import org.junit.Assert.*
import org.junit.Test

class NiuCommandTestSimulatorTest {
    @Test fun allDefaultControlCommandsStayBlockedAndNothingIsTransmitted() {
        val results = NiuCommandTestSimulator().runAll("nqi")
        assertTrue(results.isNotEmpty())
        results.filter { it.commandId.startsWith("vehicle.") }.forEach {
            assertTrue("Expected safe gate to pass for ${it.commandId}", it.passed)
            assertFalse("Simulator must never transmit ${it.commandId}", it.transmitted)
        }
    }

    @Test fun unknownModelCannotTransmitAnyCommand() {
        val results = NiuCommandTestSimulator().runAll("unknown")
        assertTrue(results.isNotEmpty())
        results.forEach { assertFalse(it.transmitted) }
        results.filter { it.commandId.startsWith("vehicle.") }.forEach { assertTrue(it.passed) }
    }

    @Test fun verifiedExactModelCommandCanPassPreflightButStillIsNotSent() {
        val verified = NiuCommandSpec(
            id = "vehicle.test",
            kind = CommandKind.CONTROL,
            evidence = CommandEvidence.VERIFIED_ON_EXACT_MODEL,
            description = "test fixture",
            payloadTemplate = byteArrayOf(0x01),
            model = "nqi"
        )
        val simulator = NiuCommandTestSimulator(NiuCommandRegistry(listOf(verified)))
        val result = simulator.runAll("nqi").single()
        assertTrue(result.passed)
        assertFalse(result.transmitted)
    }
}
